export const currency = {
  symbol: "₹",
  name: "INR",
};
