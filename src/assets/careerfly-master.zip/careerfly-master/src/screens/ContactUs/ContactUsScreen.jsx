import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { Card, Container } from "react-bootstrap";
import { themeColors } from "../../themes/colors";

const ContactUsScreen = () => {
  const data = {
    content: `A rigorous online in house corporate training 
    and placement platform called Careerfly, offers programmes 
    that are relevant to industry that 
    have been developed and are being taught in partnership 
    with top-notch academics, MNC's and business leaders.
    By fusing the most recent pedagogy, technology, 
    and services, careerfly is able to provide students 
    an immersive practical learning environment and to meet 
    corporate hiring standards.`,
    details: [
      {
        image: "/assets/contact/phone.jpeg",
        text1: "For Program Related Queries",
        text2: "+91-8273466595",
        text3: "blogcareerfly.in",
        link: "tel:+91-8273466595",
      },
      {
        image: "/assets/contact/whatsapp.png",
        text1: "For Business related Queries",
        text2: "WhatsApp Us",
        text3: "blogcareerfly.in",
        link: "https://wa.me/+918273466595",
        img: "/qrcode.jpeg",
      },
      {
        image: "/assets/contact/mail.jpeg",
        text1: "For Guest Blog Inquiries",
        text2: "info@careerfly.in",
        text3: "blogcareerfly.in",
        link: "mailto:info@careerfly.in",
      },
      {
        image: "/assets/contact/maps.png",
        text1: "Corporate office",
        text2: "C 23 Block C Noida sector 63 UP 201309",
        text3: "blogcareerfly.in",
        link: "https://goo.gl/maps/aQnzvbcuaycdGM6XA",
      },
    ],
  };

  const isMobileScreen = useMediaQuery("(max-width: 767px)");

  return (
    <div>
      <div
        style={{
          marginTop: isMobileScreen ? "50px" : "70px",
          backgroundColor: themeColors.primary,
          padding: "20px",
          paddingBottom: "200px",
        }}
      >
        <Container style={{ color: "white", marginTop: "100px" }}>
          <h1 style={{ fontWeight: 800 }}>Contact Us</h1>
          <div className="d-flex justify-content-center">
            <p className={isMobileScreen ? "w-100" : "w-50"}>{data.content}</p>
          </div>
        </Container>
      </div>

      <div
        style={{
          marginTop: "-50px",
          backgroundColor: themeColors.backgroundColor,
          paddingBottom: "150px",
        }}
      >
        <Container>
          <div
            className={
              isMobileScreen
                ? "d-flex flex-column justify-content-evenly"
                : "d-flex justify-content-evenly"
            }
          >
            {data.details?.map((item, i) => (
              <a
                href={item.link}
                style={{ color: "black", textDecoration: "none" }}
                target="_blank"
                key={i}
                rel="noreferrer"
              >
                <Card
                  style={{
                    width: isMobileScreen ? "100%" : "300px",
                    height: isMobileScreen ? "250px" : "250px",

                    border: `1px solid ${themeColors.primary}`,
                    marginTop: isMobileScreen ? "50px" : "-50px",
                  }}
                  key={i}
                  className={
                    isMobileScreen
                      ? undefined
                      : " d-flex flex-column justify-content-center align-items-center"
                  }
                >
                  <div className="d-flex flex-column justify-content-center align-items-center">
                    <div
                      style={{
                        backgroundColor: "white",
                        top: -30,
                        position: "absolute",
                        borderRadius: "50%",
                        width: "60px",
                        height: "60px",
                        border: `2px solid ${themeColors.primary}`,
                      }}
                      className="d-flex m-auto justify-content-center"
                    >
                      <Image
                        src={item.image}
                        width={40}
                        height={40}
                        alt="careerfly"
                        objectFit="contain"
                      />
                    </div>
                  </div>
                  <div
                    style={{ marginTop: i === 3 ? "95px" : "60px" }}
                    className="text-center"
                  >
                    <div>{item.text1}</div>
                    <div style={{ fontSize: "25px" }}>
                      <b>{item.text2}</b>
                    </div>

                    {item.img ? (
                      <div className="mt-2 mb-2">
                        <Image
                          src={item.img}
                          width={90}
                          height={90}
                          alt="qrcode"
                        ></Image>
                      </div>
                    ) : (
                      <div
                        className="mt-3 mb-2"
                        style={{ width: "90px", height: "90px" }}
                      ></div>
                    )}
                  </div>
                </Card>
              </a>
            ))}
          </div>
        </Container>
      </div>
    </div>
  );
};

export default ContactUsScreen;
