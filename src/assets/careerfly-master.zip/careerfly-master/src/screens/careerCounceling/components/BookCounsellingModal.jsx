import React, { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { ImCross } from "react-icons/im";
import Image from "next/image";
import { toast, ToastContainer } from "react-toastify";

import {
  Button,
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  TextField,
  useMediaQuery,
  CircularProgress,
} from "@mui/material";
import { themeColors } from "../../../themes/colors";
import Button1 from "../../../components/button/Button";
import { useStateContext } from "../../../context/StateContext";

const BookCounsellingModal = ({ open, setOpen }) => {
  const [url, setUrl] = useState();
  const [loader, setLoader] = useState(false);
  const hiddenFileInput = React.useRef(null);
  const [file, setFile] = useState();
  const [isSelected, setIsSelected] = useState(false);
  const isMobileScreen = useMediaQuery("(max-width:600px)");
  const [fullName, setFullName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [disabled, setDisabled] = useState(false);

  const handleChange = (e) => {
    setLoader(true);
    var file = e.target.files[0];
    var reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function (e) {
      var rawLog = reader.result.split(",")[1];
      var dataSend = {
        dataReq: { data: rawLog, name: file.name, type: file.type },
        fname: "uploadFilesToGoogleDrive",
      };
      fetch(
        "https://script.google.com/macros/s/AKfycbx0u0B9QSA120ZG0vgqdls9R5cJyi63SuFIAJixSes-RPEeS4WWYHXpTX6LIRBQGUYPXw/exec",
        { method: "POST", body: JSON.stringify(dataSend) }
      )
        .then((res) => res.json())
        .then((a) => {
          setUrl(a.url);

          if (a) {
            setLoader(false);
          }
        })
        .catch((e) => console.log(e));
    };
    setFile(e.currentTarget.files[0]);
    setIsSelected(true);
    // setLoader(false)
  };

  const handleClick = (e) => {
    hiddenFileInput.current.click();
  };

  const handleSubmit = (e) => {
    const date = new Date();
    // e.preventDefault();
    if (fullName && email && phone.length === 10 && url) {
      setDisabled(true);
      setTimeout(() => setDisabled(false), 3000);

      const form = {
        name: fullName,
        email: email,
        phone: phone,
        url: url,
        date: date.toUTCString(),
      };
      fetch("/api/resume", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(form),
      })
        .then((res) => res.json())
        .then((data) => {
          data.data
            ? toast.success("Response Submitted", { theme: "colored" })
            : undefined;
          setFullName("");
          setEmail("");
          setPhone();
        });

      setOpen(false);
    } else {
      toast.error("Some Fields are missing/invalid", {
        theme: "colored",
      });
    }
  };

  return (
    <div>
      <ToastContainer />

      <Dialog
        open={open}
        maxWidth={"md"}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle
          className="d-flex justify-content-between"
          id="alert-dialog-title"
        >
          <div className=""></div>
          <div onClick={() => setOpen(false)} style={{ cursor: "pointer" }}>
            <ImCross />
          </div>
        </DialogTitle>
        <DialogContent
          sx={{
            display: "flex",
            flexDirection: isMobileScreen ? "column" : "row",
          }}
        >
          <Box
            sx={{
              width: isMobileScreen ? "100%" : "50%",
              display: "flex",
              justifyContent: "center",
              flexDirection: "column",
              columnGap: "10px",
            }}
          >
            <h2 className="text-center">Get in touch</h2>
            <Image
              src="/assets/form image.jpg"
              width={isMobileScreen ? "250" : "350"}
              height={isMobileScreen ? "200" : "300"}
              alt="careerfly"
              placeholder="blur"
              blurDataURL="/assets/form image.jpg"
              objectFit="contain"
            />
          </Box>
          <Box
            sx={{
              width: isMobileScreen ? "100%" : "50%",
            }}
          >
            <TextField
              margin="dense"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              id="name"
              label="Full Name"
              type="text"
              fullWidth
              variant="outlined"
              size="small"
              color="warning"
            />
            <TextField
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              margin="dense"
              id="email"
              label="Email Address"
              type="email"
              fullWidth
              variant="outlined"
              size="small"
              color="warning"
            />
            <Box display="flex" gap="10px">
              <TextField
                sx={{
                  width: "162px",
                  "& label.Mui-focused": {
                    color: themeColors.primary,
                  },
                  "& .MuiInput-underline:after": {
                    borderBottomColor: themeColors.primary,
                  },
                  "& .MuiOutlinedInput-root": {
                    "& fieldset": {
                      borderColor: themeColors.primary,
                    },
                    "&:hover fieldset": {
                      borderColor: themeColors.primary,
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: themeColors.primary,
                    },
                  },
                }}
                margin="dense"
                value="India (+91)"
                type="text"
                variant="outlined"
                size="small"
              />
              <TextField
                autoFocus
                margin="dense"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                id="phoneNumber"
                label="Mobile Number"
                type="text"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
              />
            </Box>

            <div className="my-3">
              <Button1
                style={{ marginTop: "5px" }}
                onClick={(e) => handleClick(e)}
                title="Upload resume"
              ></Button1>
            </div>
            <input
              style={{ display: "none" }}
              type="file"
              name="file"
              ref={hiddenFileInput}
              accept="application/pdf"
              id="customFile"
              onChange={(e) => handleChange(e)}
            ></input>
            {loader ? <CircularProgress /> : null}
            {isSelected ? (
              <div>
                <p>Filetype: {file.name}</p>
              </div>
            ) : (
              <p>Select a file to show details</p>
            )}
            <FormGroup>
              <FormControlLabel control={<Checkbox />} label="Accept T&C" />
            </FormGroup>

            {disabled ? null : (
              <Button
                style={{
                  fontSize: 16,
                  fontWeight: 500,
                  backgroundColor: themeColors.primary,
                  color: themeColors.textLight,
                  padding: "5px 15px",
                }}
                onClick={(e) => handleSubmit(e)}
              >
                Submit
              </Button>
            )}
          </Box>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BookCounsellingModal;
