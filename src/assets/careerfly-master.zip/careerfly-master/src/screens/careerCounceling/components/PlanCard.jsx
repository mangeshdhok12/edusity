import React from "react";
import { themeColors } from "../../../themes/colors";
import { BiRupee } from "react-icons/bi";
import { BsCheckCircleFill } from "react-icons/bs";
import { currency } from "../../../themes/currency";
import { useMediaQuery } from "@mui/material";
import { useRouter } from "next/router";
import { useStateContext } from "../../../context/StateContext";


const PlanCard = ({ data }) => {
  const router = useRouter();
  const { setQuoteOpen, setOrderData } = useStateContext();
  
  const isMobileScreen = useMediaQuery("(max-width:768px)");
  const { userData } = useStateContext();
  const careerCouncelingPlan = {
    careerCouncelingPlanData: data.carrerCouncelings[0]?.careerCouncelingPlan,
  };

  const displayRazorpay = async (planPrice) => {
    const initializeRazorpay = () => {
      return new Promise((resolve) => {
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";

        script.onload = () => {
          resolve(true);
        };
        script.onerror = () => {
          resolve(false);
        };

        document.body.appendChild(script);
      });
    };

    const makePayment = async () => {
      const res = await initializeRazorpay();

      if (!res) {
        alert("Razorpay SDK Failed to load");
        return;
      }

      var options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY,
        name: userData.name,
        currency: currency.name,
        amount: planPrice * 100,
        description: "Thank you for your purchase !",

        prefill: {
          name: userData.name,
          email: userData.email,
          contact: userData.phone,
        },
      };

      const paymentObject = new window.Razorpay(options);
      paymentObject.open();
    };
    makePayment();
  };

  return (
    <div
      className={
        isMobileScreen
          ? "d-flex  flex-column justify-content-center align-items-center"
          : "d-flex justify-content-evenly my-5 "
      }
    >
      {careerCouncelingPlan.careerCouncelingPlanData?.map((item, i) => (
        <div
          key={i}
          style={{
            width: isMobileScreen ? "95%" : "30%",
            borderRadius: "20px",
            boxShadow: "1px 1px 5px gray",
            padding: "20px",
            margin: "10px 0px",
          }}
        >
          <h3
            className="fw-bold text-center"
            style={{
              marginTop: "10px",
              textUnderlineOffset: "10px",
            }}
          >
            {item.planTitle}
          </h3>
          <div className="mt-3">
            <div
              className="d-flex align-items-center justify-content-center"
              style={{
                color: item.caardTheme,
              }}
            >
              <BiRupee size={35} className="mt-1" />
              <p className="m-0 fs-2 fw-semibold">{item.planPrice}</p>
            </div>
            <p className="text-center fw-bold">*Inclusive of all taxes</p>
            <div className="d-flex justify-content-center">
              <button
                className="px-4 py-2 border-0"
                style={{
                  color: themeColors.textLight,
                  backgroundColor: item.caardTheme,
                }}
                onClick={() => {
                  const date = new Date();

                  router.push("/payment");
                  setOrderData({
                    courseTitle: item.planTitle,
                    coursePrice: item.planPrice,
                    couponDiscount: "0%",
                    courseProgram: item.planFeatures,
                    date: date.toDateString(),
                    time: date.toLocaleTimeString(),
                  });
                  localStorage.setItem("orderData",JSON.stringify({
                    courseTitle: item.planTitle,
                    coursePrice: item.planPrice,
                    couponDiscount: "0%",
                    courseProgram: item.planFeatures,
                    date: date.toDateString(),
                    time: date.toLocaleTimeString(),
                  }))
                }}
              >
                Buy Now
              </button>
            </div>
            <div className="mt-5">
              {item.planFeatures.map((item2, i) => (
                <div className="d-flex align-items-start">
                  <div style={{ marginTop: "-2px", paddingRight: "7px" }}>
                    <BsCheckCircleFill
                      className="mt-1"
                      size={20}
                      color={item.caardTheme}
                    />
                  </div>
                  <div>
                    <p
                      className="fw-semibold"
                      style={{
                        fontSize: "1.1rem",
                      }}
                    >
                      {item2}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default PlanCard;
