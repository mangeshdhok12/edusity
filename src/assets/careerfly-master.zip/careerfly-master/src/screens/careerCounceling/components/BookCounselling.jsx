import React, { useState } from "react";
import { Container } from "react-bootstrap";
import { useMediaQuery } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import { BiPlus } from "react-icons/bi";
import Button from "../../../components/button/Button";
import { themeColors } from "../../../themes/colors";
import BookCounsellingModal from "./BookCounsellingModal";
import { RichText } from "@graphcms/rich-text-react-renderer";
import ReactPlayer from "react-player";

const BookCounselling = ({ data }) => {
  const [expanded, setExpanded] = useState();

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  const careerCounceling = {
    heading: data.carrerCouncelings[0]?.careerCounceling[0].heading,
    content: data.carrerCouncelings[0]?.careerCounceling[0].content,
    accordian: data.carrerCouncelings[0]?.careerCounceling,
    youTubeLink: data.carrerCouncelings[0]?.youTubeLink,
  };
  const ismobile = useMediaQuery("(max-width:991px)");
  const [open, setOpen] = useState(false);
  const handleBookCounselling = () => {
    setOpen(true);
  };
  return (
    <Container style={{ marginTop: "-80px" }}>
      <div
        className={`d-flex ${
          ismobile && "flex-wrap gap-4 mt-0"
        } text-center mt-5 gap-2 align-items-center`}
        style={{
          backgroundColor: themeColors.white,
          padding: "20px 10px",
          boxShadow: "1px 1px 7px 1px lightgray",
          borderRadius: "14px",
        }}
      >
        <div style={{ width: ismobile ? "90%" : "" }}>
          <h1
            className="px-md-3"
            style={{
              textAlign: "left",
            }}
          >
            {careerCounceling?.heading}
          </h1>
          <p
            className="wrap px-md-3"
            style={{ fontSize: "1.1rem", textAlign: "left" }}
          >
            {careerCounceling?.content}
          </p>
          <div
            className={ismobile ? "d-flex justify-content-center" : undefined}
          >
            <div
              style={{ width: ismobile ? "100%" : "" }}
              className={
                ismobile
                  ? "d-flex flex-column justify-content-center"
                  : undefined
              }
            >
              {careerCounceling.accordian?.map((item, i) => {
                if (i === 0) {
                  return;
                }
                return (
                  <Accordion
                    expanded={expanded === i}
                    onChange={handleChange(i)}
                    className="my-2"
                    key={i}
                    style={{
                      width: ismobile ? "100%" : "90%",
                    }}
                  >
                    <AccordionSummary
                      expandIcon={<BiPlus />}
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                    >
                      <Typography variant="" className="text-start">
                        {" "}
                        <b>{item?.heading}</b>
                      </Typography>
                    </AccordionSummary>
                    <AccordionDetails style={{ textAlign: "left" }}>
                      <RichText content={item.description?.raw} />
                    </AccordionDetails>
                  </Accordion>
                );
              })}
            </div>
          </div>
        </div>
        <div style={{ width: "100%" }}>
          <div
            className={`d-flex flex-column align-items-center ${
              ismobile ? "gap-3" : "gap-5"
            }`}
          >
            <ReactPlayer
              url={careerCounceling.youTubeLink}
              width={ismobile ? 270 : 400}
              height={ismobile ? 158.75 : 230}
            />
            <div
              className="d-flex justify-content-center"
              onClick={() => handleBookCounselling()}
            >
              <Button title="Book Counselling" />
            </div>
            {open && <BookCounsellingModal open={open} setOpen={setOpen} />}
          </div>
        </div>
      </div>
    </Container>
  );
};

export default BookCounselling;
