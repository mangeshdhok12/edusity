import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import Image from "next/image";
import { themeColors } from "../../../themes/colors";
import { useMediaQuery } from "@mui/material";

const Advice = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const careerCounceling = {
    careerCouncelingdata: data.carrerCouncelings[0]?.careerCouncelingAdvice,
  };
  return (
    <div
      className={isMobileScreen ? "mt-5 mb-5" : "mt-5"}
      style={{
        display: "flex",
        flexDirection: "column",
        textAlign: "center",
        backgroundColor: themeColors.secondary,
        padding: "10px 0px 30px 0px",
      }}
    >
      <div className="pb-3">
        <h2
          style={{
            color: themeColors.textLight,
          }}
        >
          Career guidance session with industry experts
        </h2>
      </div>
      <div>
        <Swiper
          breakpoints={{
            320: {
              slidesPerView: 1,
              spaceBetween: 10,
            },
            622: {
              slidesPerView: 2,
              spaceBetween: 10,
            },
            924: {
              slidesPerView: 3,
              spaceBetween: 10,
            },
            1224: {
              slidesPerView: 4,
              spaceBetween: 10,
            },
          }}
          slidesPerView={isMobileScreen ? 2 : 3}
          autoplay={{ delay: 2000 }}
          modules={[Autoplay]}
        >
          {careerCounceling.careerCouncelingdata?.map((item, i) => (
            <SwiperSlide
              key={i}
              style={{
                display: "flex",
                justifyContent: "center",
              }}
            >
              <div
                style={{
                  borderRadius: "10px",
                  display: "flex",
                  justifyContent: "space-between",
                  padding: "10px",
                  alignItems: "center",
                  backgroundColor: themeColors.backgroundColor,
                  width: "18rem",
                  gap: "5px",
                }}
              >
                <Image
                  objectFit="cover"
                  placeholder="blur"
                  blurDataURL={item.adviceGiverImage?.url}
                  src={item.adviceGiverImage?.url}
                  height={300}
                  width={300}
                  alt="careerfly"
                  style={{ marginTop: "-1px", borderRadius: "50%" }}
                />
                <div>
                  <p
                    style={{
                      fontSize: "0.8rem",
                      textAlign: "left",
                    }}
                  >
                    {item?.advice}
                  </p>
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default Advice;
