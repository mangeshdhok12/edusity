import React from "react";
import Image from "next/image";
import { useMediaQuery } from "@mui/material";
import { Autoplay } from "swiper";
import { SwiperSlide, Swiper } from "swiper/react";

const CareerBanner = ({ data }) => {
  const banner = {
    image: data.carrerCouncelings[0].heroBanner,
  };
  const isMobileScreen = useMediaQuery("(max-width:768px)");

  return (
    <div
      className="position-relative d-flex justify-content-center"
      style={{ marginTop: isMobileScreen ? "2rem" : "6rem"}}
    >
      <Swiper modules={[Autoplay]} autoplay={{ delay: 7000 }}>
        {banner.image?.map((item, i) => (
          <SwiperSlide className="d-flex justify-content-center" key={i}>
            <Image
              src={item.url}
              alt="careerfly"
              width={isMobileScreen ? 400 : 1920}
              height={isMobileScreen ? 150 : 500}
              objectFit="contain"
              placeholder="blur"
              blurDataURL={item.url}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default CareerBanner;
