import { useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import Advice from "./components/Advice";
import CareerBanner from "./components/CareerBanner";
import PlanCard from "./components/PlanCard";
import BookCounselling from "./components/BookCounselling";
import BookCounsellingModal from "./components/BookCounsellingModal";
import { Container } from "react-bootstrap";

const CareerCounsellingScreen = ({ data }) => {
  const ismobile = useMediaQuery("(max-width:768px)");
  const [open, setOpen] = useState(false);
  return (
    <div>
      <div className="p-2 mt-4">
        <div>
          <Container>
            <CareerBanner data={data} />
          </Container>
          <div
            className={`container d-flex ${
              ismobile && "flex-wrap gap-4"
            } text-center mt-5 gap-2 align-items-center`}
          >
            <div style={{ width: "100%" }}>
              <div
                className={`d-flex flex-column align-item-center ${
                  ismobile ? "gap-3" : "gap-5"
                }`}
              >
                {open && <BookCounsellingModal open={open} setOpen={setOpen} />}
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container">
        <BookCounselling data={data} />
      </div>
      <Advice data={data} />
      <div className="container">
        <PlanCard data={data} />
      </div>
    </div>
  );
};

export default CareerCounsellingScreen;
