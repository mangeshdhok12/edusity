import Image from "next/image";
import React from "react";
import { themeColors } from "../../themes/colors";

const Dashboard = () => {
  return (
    <div className="mt-5">
      <h3
        style={{
          fontSize: "18px",
          fontWeight: "bold",
        }}
      >
        Dashboard
      </h3>
      <div className="d-flex">
        <div
          style={{
            width: "323px",
            height: "396px",
            backgroundColor: " #FCFCFC",
            borderRadius: "10px",
            boxShadow: `4px 4px 6px 2px ${themeColors.gray}`,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <Image
            src="/assets/studentdashboardAssets/trainer2.png"
            alt="Careerfly"
            width={141}
            height={141}
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/trainer2.png"
            style={{
              borderRadius: "50%",
            }}
          />
          <h4 className="text-center fw-border fs-4 mt-3">Gautam Kumar</h4>
          <p className="text-center mt-3">Persistence is the key to success</p>
        </div>
        <div
          style={{
            width: "323px",
            height: "157px",
            borderRadius: "10px",
            boxShadow: `4px 4px 6px 2px ${themeColors.gray}`,
            display: "flex",
            justifyContent: "space-evenly",
            alignItems: "center",
          }}
        >
          <div>
            <p className="fw-bolder fs-2 text-center m-0 ">23</p>
            <p className=" text-center fs-5">Achievements</p>
          </div>
          <div>
            <p className="fw-bolder fs-2 text-center m-0 ">5</p>
            <p className=" text-center fs-5">Days Streak (max)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
