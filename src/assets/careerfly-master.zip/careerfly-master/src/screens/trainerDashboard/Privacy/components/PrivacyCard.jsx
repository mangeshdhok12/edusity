import React, { useState } from "react";
import Image from "next/image";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import ErrorOutlineRoundedIcon from "@mui/icons-material/ErrorOutlineRounded";
import DeleteForeverRoundedIcon from "@mui/icons-material/DeleteForeverRounded";
import BlockRoundedIcon from "@mui/icons-material/BlockRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";

const style = {
  position: "absolute",
  top: "35%",
  left: "70%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "#dfe4ea",
  boxShadow:
  "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
  p: 4,
  borderRadius: "4px",
};

const PrivacyCard = () => {
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [blockModal, setBlockModal] = useState(false);
  const handleBlockModal = () => setBlockModal(true);
  const handleBlockClose = () => setBlockModal(false);
  return (
    <div className="d-flex flex-wrap   w-100 justify-content-between align-items-center rounded-2xl">
      <div
        className="d-flex  justify-content-between p-3 "
        style={{ backgroundColor: "#f9f9f9" }}
      >
        <div className="w-75">
          <strong
            className="font-black "
            style={{ fontWeight: "bolder", fontSize: "30px" }}
          >
            <b>Remove user</b>
          </strong>
          <p>
            Once you remove someone, that person can no longer see things you
            post on your timeline, tag your Page, invite your Page to events or
            groups, or start a conversation with your Page. Note: Does not
            includeapps, games or groups you both participate in.
          </p>
        </div>
        <div>
          <button
            style={{
              backgroundColor: "#1abc9c",
              border: "0",
              borderRadius: "5px",
              color: "white",
              fontWeight: "bold",
              marginRight: "140px",
            }}
            className="px-4 py-2 my-5"
            onClick={handleOpen}
          >
            <DeleteForeverRoundedIcon onClick={handleOpen} />
          </button>
        </div>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          style={{ marginTop: "50px" }}
        >
          <Box sx={style}>
            <ErrorOutlineRoundedIcon
              style={{
                position: "absolute",
                right: "0",
                top: "10%",
                cursor: "pointer",
                width: "50px",
                color: "gray",
              }}
            />
            <Typography id="modal-modal-description">
              <h5>
                <b>Remove</b>
              </h5>
              <hr />
            </Typography>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "35%",
                      marginLeft: "10px",
                    }}
                  >
                    Francesca Metts
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <DeleteForeverRoundedIcon />
                </div>
              </div>

              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "54%",
                      marginLeft: "10px",
                    }}
                  >
                    Aakash Sharma
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <DeleteForeverRoundedIcon />
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "72%",
                      marginLeft: "10px",
                    }}
                  >
                    John Doe
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <DeleteForeverRoundedIcon />
                </div>
              </div>
            </Typography>
          </Box>
        </Modal>
      </div>
      <div
        className="d-flex  justify-content-between my-4  p-3"
        style={{ backgroundColor: "#f9f9f9" }}
      >
        <div className="w-75">
          <strong
            className="font-black "
            style={{ fontWeight: "bolder", fontSize: "30px" }}
          >
            <b>Block user</b>
          </strong>
          <p>
            Once you block someone, that person can no longer see things you
            post on your timeline, tag your Page, invite your Page to events or
            groups, or start a conversation with your Page. Note: Does not
            includeapps, games or groups you both participate in.
          </p>
        </div>
        <div>
          <button
            style={{
              backgroundColor: "#1abc9c",
              border: "0",
              borderRadius: "5px",
              color: "white",
              fontWeight: "bold",
              marginRight: "140px",
            }}
            className="px-4 py-2 my-5"
            onClick={handleBlockModal}
          >
            <BlockRoundedIcon />
          </button>
        </div>
        <Modal
          open={blockModal}
          onClose={handleBlockClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
          style={{ marginTop: "50px" }}
        >
          <Box sx={style}>
            <ErrorOutlineRoundedIcon
              style={{
                position: "absolute",
                right: "0",
                top: "10%",
                cursor: "pointer",
                width: "50px",
                color: "gray",
              }}
            />
            <Typography id="modal-modal-description">
              <h5>
                <b>Block</b>
              </h5>
              <hr />
            </Typography>
            <Typography id="modal-modal-title" variant="h6" component="h2">
              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "35%",
                      marginLeft: "10px",
                    }}
                  >
                    Francesca Metts
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <BlockRoundedIcon />
                </div>
              </div>

              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "54%",
                      marginLeft: "10px",
                    }}
                  >
                    Aakash Sharma
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <BlockRoundedIcon />
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div>
                  <Image
                    src="/assets/studentdashboardAssets/profile.png"
                    alt="AVATAR"
                    width={40}
                    height={40}
                  />
                  <span
                    style={{
                      position: "absolute",
                      top: "72%",
                      marginLeft: "10px",
                    }}
                  >
                    John Doe
                  </span>
                </div>
                <div style={{ color: "gray", fontSize: "18px" }}>
                  <BlockRoundedIcon />
                </div>
              </div>
            </Typography>
          </Box>
        </Modal>
      </div>
      <div
        className="d-flex  justify-content-between  p-3"
        style={{ backgroundColor: "#f9f9f9" }}
      >
        <div className="w-75">
          <strong
            className="font-black "
            style={{ fontWeight: "bolder", fontSize: "30px" }}
          >
            <b>Privacy Policies</b>
          </strong>
          <p>
            Careerty along with its subsidiaries and international amates
            referred to collectively careeryus we or four or me Company in
            committed to person data secu and management in order to function
            effectively and successtuty for me benett of our stakeholders,
            customer, and a community in doing so tis critical to protect
            people&apos;s privacy by using lawful and appropriate methods for handing
            personal cata As a result, we have put in place this privacy policy
            Cherematier referred to as coic.
          </p>
        </div>
        <div>
          <button
            style={{
              backgroundColor: "#1abc9c",
              border: "0",
              borderRadius: "5px",
              color: "white",
              fontWeight: "bold",
              marginRight: "140px",
            }}
            className="px-4 py-2 my-5"
          >
            <AdminPanelSettingsRoundedIcon />
          </button>
        </div>
      </div>
    </div>
  );
};
export default PrivacyCard;
