import React from "react";
import { Container } from "react-bootstrap";
import PrivacyCard from "./components/PrivacyCard";
import DeleteForeverRoundedIcon from "@mui/icons-material/DeleteForeverRounded";
import BlockRoundedIcon from "@mui/icons-material/BlockRounded";
import AdminPanelSettingsRoundedIcon from "@mui/icons-material/AdminPanelSettingsRounded";




const Privacy = () => {
  return (
    <Container style={{ marginTop: "110px" }}>
      <div>
        <div className="d-flex justify-content-between align-items-center mx-5">
          <h2 style={{ color: "#2e86de", marginBottom: "30px" }}>
            <b>PRIVACY</b>
          </h2>
        </div>
        <div className="d-flex flex-column">
          <PrivacyCard />
        </div>
      </div>
    </Container>
  );
};

export default Privacy;
