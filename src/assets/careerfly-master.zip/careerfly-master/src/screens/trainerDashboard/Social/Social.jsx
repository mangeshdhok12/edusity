import React, { useState } from "react";
import Image from "next/image";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { db } from "../../../lib/firebase";
import { CopyToClipboard } from "react-copy-to-clipboard";

const data = [
  {
    logo: "/INSTAGRAM LOGO.png",
    teacherId: "_Sushantrajput33_",
    officialId: "Careerflyofficial",
    copy: <ContentCopyIcon />,
  },
  {
    logo: "/facebook-icon.png",
    teacherId: "_Sushantrajput33_",
    officialId: "Careerfly",
    copy: <ContentCopyIcon />,
  },
  {
    logo: "/linkedIn-icon.png",
    teacherId: "_Sushantrajput33_",
    officialId: "Careerflyofficial",
    copy: <ContentCopyIcon />,
  },
  {
    logo: "/Yt-icon.png",
    teacherId: "PushpajeKumar",
    officialId: "@Careerflyofficial",
    copy: <ContentCopyIcon />,
  },
];

const Social = () => {
  const [copied, setCopied] = useState(false);
  const [value, setValue] = useState(data);

  // const socialRef = doc(db, "Trainer", "7ercbTKlInc2U4XMZPei");

  return (
    <div
      style={{
        marginTop: "40px",
        backgroundColor: "#FDF7E8",
        width: "1160px",
        height: "920px",
      }}
    >
      <div className="d-flex flex-column" style={{ position: "relative" }}>
        <div
          style={{
            backgroundImage: "url(/social.svg)",
            backgroundRepeat: "no-repeat",
            width: "1100px",
            height: "1000px",
            marginTop: "275px",
          }}
        ></div>
        <div style={{ position: "absolute", top: "10%" }}>
          {data?.map((v, i) => {
            return (
              <div key={i}>
                <div
                  className="d-flex flex-wrap justify-content-between "
                  style={{
                    width: "290px",
                    marginTop: "20px",
                    marginLeft: "150px",
                    backgroundColor: "#E4E4E4",
                    borderRadius: "37px",
                  }}
                >
                  <div
                    style={{
                      backgroundColor: "#FEE1B3",
                      padding: "15px",
                      borderRadius: "50%",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <Image
                      src={v.logo}
                      alt="Logo"
                      width={40}
                      height={40}
                      objectFit="contain"
                    />
                  </div>
                  <div className="py-3">
                    <span>{v.teacherId}</span>
                    <br />
                    <span>{v.officialId}</span>
                  </div>

                  <CopyToClipboard
                    text={v.teacherId}
                    onCopy={() => setCopied({ copied: true })}
                  >
                    <div className="py-4 px-3" style={{ cursor: "pointer" }}>
                      {v.copy}
                    </div>
                  </CopyToClipboard>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default Social;
