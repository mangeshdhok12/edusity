import React, { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/router";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import WidgetsOutlinedIcon from "@mui/icons-material/WidgetsOutlined";
import DangerousIcon from "@mui/icons-material/Dangerous";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";
import GroupsIcon from "@mui/icons-material/Groups";
import LockClockIcon from "@mui/icons-material/LockClock";
import RecommendIcon from "@mui/icons-material/Recommend";
import LogoutIcon from "@mui/icons-material/Logout";
import { useMediaQuery } from "@mui/material";

const data = [
  {
    title: "Overview",
    icon: <WidgetsOutlinedIcon />,
    url: "overview",
  },
  {
    title: "Videos",
    icon: <PlayCircleIcon />,
    url: "videos",
  },
  {
    title: "Classes",
    icon: <GroupsIcon />,
    url: "classes",
  },
  {
    title: "Privacy",
    icon: <LockClockIcon />,
    url: "privacy",
  },
  {
    title: "Social",
    icon: <RecommendIcon />,
    url: "social",
  },
];

const style = {
  position: "absolute",
  top: "25%",
  left: "35%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "#dfe4ea",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  borderRadius: "7px",
};

const TrainerSidebar = () => {
  const isMobileScreen = useMediaQuery("(max-width: 768px)");

  const [hover, setHover] = useState(false);
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const router = useRouter();

  return (
    <div
      style={{
        marginLeft:"30px",
        marginBottom: "60px",
        boxShadow: "rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px",
        width: "260px",
      }}
    >
      <div
        className="d-flex justify-content-center align-items-center "
        style={{
          marginTop:isMobileScreen?"65px": "73px",
          // marginLeft: "20px",
        }}
      >
        <div style={{marginTop:"10px"}}>
          <Image
            src="/assets/studentdashboardAssets/profile.png"
            alt="AVATAR"
            width={40}
            height={40}
          />
        </div>
        <div style={{ marginTop: "10px", marginLeft: "15px" }}>
          <h5>
            <b>CareerFly</b>
          </h5>
        </div>
        <div
          style={{ marginTop: "1px", marginLeft: "100px", cursor: "pointer" }}
        >
          <div className="d-flex gap-4 ">
            <div
              style={{
                width: "8px",
                height: "8px",
                backgroundColor: "red",
                borderRadius: "50%",
                position: "absolute",
                left: "20%",
                top: "14%",
              }}
            ></div>
          </div>
          <NotificationsNoneIcon onClick={handleOpen} />
        </div>
      </div>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
        style={{ marginTop: "50px" }}
      >
        <Box sx={style}>
          <DangerousIcon
            onClick={handleClose}
            style={{
              position: "absolute",
              right: "0",
              top: "3%",
              cursor: "pointer",
              width: "50px",
              color: "brown",
            }}
          />
          <Typography id="modal-modal-description">
            <h5>
              <b>Notifications</b>
            </h5>
            <hr />
          </Typography>
          <Typography id="modal-modal-title" variant="h6" component="h2">
            <Image
              src="/assets/studentdashboardAssets/profile.png"
              alt="AVATAR"
              width={40}
              height={40}
              className="my-1"
            />
            <span style={{ fontSize: "18px" }}>John Doe</span>
            <span
              style={{ color: "gray", marginLeft: "8px", fontSize: "18px" }}
            >
              messaged on chat
            </span>
            <p style={{ marginLeft: "40px", color: "gray", fontSize: "15px" }}>
              1 min ago
            </p>
            <Image
              src="/assets/studentdashboardAssets/profile.png"
              alt="AVATAR"
              width={40}
              height={40}
              className="my-1"
            />
            <span style={{ fontSize: "18px" }}>John Doe</span>
            <span
              style={{ color: "gray", marginLeft: "8px", fontSize: "18px" }}
            >
              messaged on chat
            </span>
            <p style={{ marginLeft: "40px", color: "gray", fontSize: "15px" }}>
              1 min ago
            </p>
            <Image
              src="/assets/studentdashboardAssets/profile.png"
              alt="AVATAR"
              width={40}
              height={40}
              className="my-1"
            />
            <span style={{ fontSize: "18px" }}>John Doe</span>
            <span
              style={{ color: "gray", marginLeft: "8px", fontSize: "18px" }}
            >
              messaged on chat
            </span>
            <p style={{ marginLeft: "40px", color: "gray", fontSize: "15px" }}>
              1 min ago
            </p>
          </Typography>
        </Box>
      </Modal>
      <hr />
      {data?.map((elem, i) => {
        return (
          <div
            key={i}
            style={{
              marginBottom: "20px",
              cursor: "pointer",
              backgroundColor: hover ? "#74b9ff" : "",
              color: hover ? "black" : "",
            }}
            onClick={() => {
              router.push(`/trainer-dashboard/${elem.url}`);
            }}
            // onMouseEnter={() => {
            //   setHover(!hover);
            // }}
            // onMouseLeave={() => {
            //   setHover(!hover);
            // }}
          >
            <span>{elem.icon}</span>
            <span className="mx-3">{elem.title}</span>
          </div>
        );
      })}
      <div style={{ marginTop: "500px", padding: "20px" }}>
        <span>
          <LogoutIcon />
        </span>
        <span className="mx-2 py-5">Logout</span>
      </div>
    </div>
  );
};

export default TrainerSidebar;
