import React, { useEffect, useState } from "react";
import Image from "next/image";
import { themeColors } from "../../../themes/colors";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import AccountCircleRoundedIcon from "@mui/icons-material/AccountCircleRounded";
import StarIcon from "@mui/icons-material/Star";
import ErrorOutlineRoundedIcon from "@mui/icons-material/ErrorOutlineRounded";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import ClipLoader from "react-spinners/ClipLoader";
import {
  getDoc,
  doc,
  updateDoc,
  arrayUnion,
  arrayRemove,
} from "firebase/firestore";
import { db } from "../../../lib/firebase";

const Overview = () => {
  const trainerId = localStorage.getItem("TrainerId");

  const [date, setDate] = useState(new Date());
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [checked, setChecked] = useState(true);

  const todoRef = doc(db, "Trainer", trainerId);
  const getTodo = async () => {
    try {
      const docSnap = await getDoc(todoRef);
      if (docSnap.exists()) {
        setData(docSnap.data());
        console.log("Document data:", docSnap.data());
      } else {
        console.log("No such document!");
      }
    } catch (error) {}
  };
  useEffect(() => {
    getTodo();
  }, [open, loading]);

  // const handleTodocomplete = async (todo) => {
  //   setLoading(true);
  //   try {
  //     await updateDoc(todoRef, {
  //       DailyTask: arrayRemove({
  //         todo: todo,
  //         done: false,
  //       }),
  //     });
  //     await updateDoc(todoRef, {
  //       DailyTask: arrayUnion({
  //         todo: todo,
  //         done: true,
  //       }),
  //     });
  //     setLoading(false);
  //   } catch (error) {
  //     console.log(error.message);
  //     setLoading(false);
  //   }
  // };

  return (
    <div className="d-flex ">
      <div>
        <div style={{ marginTop: "80px", marginLeft: "25px" }}>
          <div className="d-flex justify-content-between align-items-center mx-3">
            <div>
              <p
                style={{
                  fontSize: "18px",
                  fontweight: "bold",
                }}
              >
                Hii
              </p>
              <p>Good Morning</p>
            </div>
          </div>
          <div className="">
            <div className="d-flex flex-wrap align-items-center justify-content-center mt-2">
              <div>
                <div
                  className="d-flex flex-wrap"
                  style={{ marginBottom: "30px" }}
                >
                  <div>
                    <Image
                      alt="placeholder"
                      src="/assets/studentdashboardAssets/Placeholder_Rad.png"
                      width={100}
                      height={100}
                      placeholder="blur"
                      blurDataURL="/assets/studentdashboardAssets/Placeholder_Rad.png"
                    />
                  </div>
                  <div className="mx-5">
                    <p
                      style={{
                        fontSize: "18px",
                        fontWeight: "bold",
                        margin: 0,
                        textAlign: "center",
                      }}
                    >
                      {data?.Name}
                    </p>
                    <span>{data?.email}</span>
                    <br />
                    <span>{data?.Contact}</span>
                  </div>
                </div>
                <button
                  style={{
                    backgroundColor: themeColors.primary,
                    width: "130px",
                    height: "40px",
                    borderRadius: "10px",
                    color: "white",
                    border: "none",
                  }}
                >
                  View Profile
                </button>
                <button
                  style={{
                    width: "130px",
                    height: "40px",
                    borderRadius: "10px",
                    color: "#11243D",
                    border: "none",
                    border: "1px solid #E6E6EB",
                    marginLeft: "5%",
                  }}
                >
                  Edit Profile
                </button>
              </div>

              <div
                style={{ marginLeft: "90px", marginRight: "4px" }}
                className="d-md-flex flex-lg-column justify-content-between"
              >
                <div>
                  <p
                    style={{
                      fontSize: "18px",
                      fontWeight: "bold",
                      margin: 0,
                    }}
                  >
                    Trainer
                  </p>
                  <p style={{ color: "gray" }}>Status</p>
                </div>
                <div className="text-center">
                  <p
                    style={{
                      fontSize: "18px",
                      fontWeight: "bold",
                      margin: 0,
                    }}
                  >
                    {data?.Classes}
                  </p>
                  <p style={{ color: "gray" }}>Classes</p>
                </div>
                <div className="text-center">
                  <p
                    style={{
                      fontSize: "18px",
                      fontWeight: "bold",
                      margin: 0,
                    }}
                  >
                    {data?.Program}
                  </p>
                  <p style={{ color: "gray" }}>Program</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div
          className=" p-4 mx-4 mt-5"
          style={{
            boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            backgroundColor: "#ecf0f1",
          }}
        >
          <div className="d-flex flex-wrap">
            <div>
              <LinkedInIcon
                color="primary"
                style={{
                  fontSize: "60px",
                }}
              />
            </div>
            <div className="mx-4">
              <h4>
                <b>{data?.Name}</b>
              </h4>
              <p>{data?.Position}</p>
            </div>
          </div>
          <div className="d-flex justify-content-between">
            <div>
              <span>Experience - {data?.Experience} Years</span>
              <br />
              <span>
                Ratings -<StarIcon style={{ color: "#FFC312" }} />
                <StarIcon style={{ color: "#FFC312" }} />
                <StarIcon style={{ color: "#FFC312" }} />
                <StarIcon style={{ color: "#FFC312" }} />
                <StarIcon style={{ color: "#FFC312" }} />
              </span>
              <p>{data?.address}</p>
              <button className="btn btn-primary px-4">+Connect</button>
            </div>
            <div style={{ marginLeft: "20px" }}>
              <AccountCircleRoundedIcon />
              <span className="mx-2">red hat Jr</span>
              <br />
              <AccountCircleRoundedIcon />
              <span className="mx-2">
                Excellence Center for
                <br /> Distance Learning
              </span>
            </div>
          </div>
        </div>
      </div>
      <div style={{ marginLeft: "10%" }}>
        <div
          style={{
            borderRadius: "12px",
            width: "350px",
            padding: "15px",
            boxShadow:
              "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
            marginTop: "100px",
          }}
        >
          <span style={{ marginRight: "220px", marginLeft: "20px" }}>
            <b>Task</b>
          </span>
          <ErrorOutlineRoundedIcon />
          <hr />
          <div className="d-flex justify-content-center">
            <ClipLoader
              loading={loading}
              size={30}
              aria-label="Loading Spinner"
              data-testid="loader"
            />
          </div>
          {data?.DailyTask?.reverse()
            .slice(0, 8)
            .map((v, index) => {
              return (
                <div
                  className="py-2 px-3"
                  key={index}
                  style={{ borderBottom: "1px solid gray" }}
                >
                  {/* <input
                    checked={v.done}
                    type="checkbox"
                    onChange={(e) => handleTodocomplete(v.todo)}
                  /> */}
                  <span className="mx-2">{v?.todo}</span>
                </div>
              );
            })}
        </div>

        <div className="px-3" style={{ marginLeft: "15px", marginTop: "30px" }}>
          <h5 className="text-center py-2">
            <b>Calender</b>
          </h5>
          <div style={{ width: "350px" }}>
            <Calendar onChange={setDate} value={date} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Overview;
