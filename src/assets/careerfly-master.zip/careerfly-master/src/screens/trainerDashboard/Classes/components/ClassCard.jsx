import React from "react";
import Image from "next/image";
import ArrowCircleLeftOutlinedIcon from '@mui/icons-material/ArrowCircleLeftOutlined';
import ArrowCircleRightOutlinedIcon from '@mui/icons-material/ArrowCircleRightOutlined';

const data = [
  {
    title: "Introduction to Recruitment",
    time: "09:00 to 10:00",
    image1: "/assets/studentdashboardAssets/profile.png",
    image2: "/assets/studentdashboardAssets/profile.png",
    sr: "10+",
    color: "#c7fcf4",
  },
  {
    title: "Basic of US recruitment",
    time: "11:00 to 12:00",
    image1: "/assets/studentdashboardAssets/profile.png",
    image2: "/assets/studentdashboardAssets/profile.png",
    sr: "7+",
    color: "#ffeaa7",
  },
  {
    title: "US Geographical Overview",
    time: "02:00 to 03:00",
    image1: "/assets/studentdashboardAssets/profile.png",
    image2: "/assets/studentdashboardAssets/profile.png",
    sr: "11+",
    color: "#dfe6e9",
  },
  {
    title: "US Recruitment Technologies",
    time: "04:00 to 05:00",
    image1: "/assets/studentdashboardAssets/profile.png",
    image2: "/assets/studentdashboardAssets/profile.png",
    sr: "16+",
    color: "#fab1a0",
  },
];

const ClassCard = () => {
  return (
    <div>
     <div className="my-1 py-4" style={{borderTop:"2px solid gray"}}>
     <span className="mx-3" style={{ color: "#192a56", fontSize: "30px" }}>
     <b>4 February</b>
   </span>
   <ArrowCircleLeftOutlinedIcon fontSize="large" />
   <ArrowCircleRightOutlinedIcon fontSize="large" />
   <span
     style={{
       width: "50px",
       backgroundColor: "#dcdde1",
       borderRadius: "8px",
       marginLeft:"15%",
     }}
     className="p-2 my-4"
   >
     <span className="px-3 py-2" style={{backgroundColor:"gray", borderRadius:"8px"}}>Day</span>
     <span className="px-3 py-2">Week</span>
     <span className="px-3 py-2">Month</span>
   </span>
     </div>
      <div className="d-flex flex-wrap">
        {data?.map((item, i) => {
          return (
            <div
              className="d-flex flex-wrap p-3  justify-content-between align-items-center rounded-2xl"
              style={{
                backgroundColor: "#f9f9f9",
                borderBottom: "1px solid gray",
                borderTop: "1px solid gray",
                width:"100%"
              }}
              key={i}
            >
              <div
                className="d-flex justify-content-between w-100 px-5"
                style={{
                  backgroundColor: `${item.color}`,
                  paddingTop: "40px",
                }}
              >
               <div className="d-flex flex-wrap justify-content-between w-100">
               <div className="px-3">
               <strong className="font-black " style={{ fontSize: "20px" }}>
                 {item.title}
               </strong>
               <p>{item.time}</p>
             </div>
             <div className="d-flex justify-content-end py-2">
               <Image
                 src={item.image1}
                 alt="profile"
                 width={50}
                 height={20}
               />
               <Image
                 src={item.image2}
                 alt="profile"
                 width={50}
                 height={20}
               />
               <span
                 style={{
                   backgroundColor: "#beccca",
                   color: "black",
                   width: "40px",
                   height: "40px",
                   borderRadius: "50%",
                   textAlign: "center",
                   padding: "10px",
                 }}
               >
                 {item.sr}
               </span>
             </div>
               </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ClassCard;
