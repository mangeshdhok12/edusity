import React, { useEffect } from "react";
import ClassCard from "./components/ClassCard";
import ErrorOutlineRoundedIcon from "@mui/icons-material/ErrorOutlineRounded";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import { useState } from "react";
import GoalChart from "./components/GoalChart";
import Box from "@mui/material/Box";
import Modal from "@mui/material/Modal";
import TextField from "@mui/material/TextField";
import { Button } from "@mui/material";
import {
  getDoc,
  doc,
  updateDoc,
  arrayUnion,
  arrayRemove,
} from "firebase/firestore";
import { db } from "../../../lib/firebase";
import ClipLoader from "react-spinners/ClipLoader";

const todo = [
  {
    title: "Meeting",
  },
  {
    title: "Meeting",
  },
  {
    title: "Meeting",
  },
  {
    title: "Meeting",
  },
];

const style = {
  position: "absolute",
  top: "25%",
  left: "75%",
  transform: "translate(-50%, -50%)",
  width: 500,
  bgcolor: "#dfe4ea",
  boxShadow: 24,
  p: 4,
  borderRadius: "20px",
};

const Classes = () => {
  const [date, setDate] = useState(new Date());
  const [todoInput, setTodoInput] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [data, setData] = useState(null);

  const [checked, setChecked] = useState(true);

  const todoRef = doc(db, "Trainer", "7ercbTKlInc2U4XMZPei");

  const handleChange = (val) => {
    setChecked(val);
  };

  const getTodo = async () => {
    try {
      const docSnap = await getDoc(todoRef);
      if (docSnap.exists()) {
        setData(docSnap.data());
        console.log("Document data:", docSnap.data());
      } else {
        // doc.data() will be undefined in this case
        console.log("No such document!");
      }
    } catch (error) {}
  };

  useEffect(() => {
    getTodo();
  }, [open, loading]);

  const addTodo = async () => {
    setLoading(true);
    try {
      await updateDoc(todoRef, {
        DailyTask: arrayUnion({
          todo: todoInput,
          done: false,
        }),
      });
      setTodoInput("");
      setLoading(false);
    } catch (error) {
      console.log(error.message);
      setLoading(false);
    }
  };

  // const todoRef = doc(db, "Trainer", "7ercbTKlInc2U4XMZPei");

  const handleTodocomplete = async (todo) => {
    setLoading(true);
    try {
      await updateDoc(todoRef, {
        DailyTask: arrayRemove({
          todo: todo,
          done: false,
        }),
      });
      await updateDoc(todoRef, {
        DailyTask: arrayUnion({
          todo: todo,
          done: true,
        }),
      });
      setLoading(false);
    } catch (error) {
      console.log(error.message);
      setLoading(false);
    }
  };

  return (
    <div style={{ marginTop: "100px" }}>
      <div className="mx-4 d-flex flex-wrap">
        <div style={{ width: "68%" }}>
          <h4 className="mx-4" style={{ color: "#192a56", fontSize: "30px" }}>
            <b>CLASSES</b>
          </h4>
          <div>
            <ClassCard />
          </div>
        </div>
        <div className="px-4 p-2" style={{ width: "30%" }}>
          <button
            className="btn btn-primary px-4"
            style={{
              padding: "10px 8px",
              marginLeft: "100px",
              whiteSpace: "nowrap",
              letterSpacing: "2px",
            }}
            onClick={handleOpen}
          >
            +ADD TASK
          </button>

          <Modal
            open={open}
            onClose={handleClose}
            aria-labelledby="modal-modal-title"
            aria-describedby="modal-modal-description"
            style={{ marginTop: "50px" }}
          >
            <Box sx={style}>
              <TextField
                id="outlined-basic"
                label="Add To do"
                variant="outlined"
                value={todoInput}
                onChange={(e) => setTodoInput(e.target.value)}
                fullWidth
              />
              <div className="py-2 d-flex justify-content-center">
                <ClipLoader
                  loading={loading}
                  size={50}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                />
              </div>
              <div className="text-center mt-3">
                <Button
                  variant="contained"
                  color="primary"
                  onClick={addTodo}
                  disabled={loading}
                >
                  Add
                </Button>
              </div>
            </Box>
          </Modal>

          <div className="my-4">
            <div
              style={{
                marginBottom: "60px",
                width: "350px",
                height: "250px",
                borderRadius: "10px",
                boxShadow:
                  "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
              }}
            >
              <Calendar onChange={setDate} value={date} />
            </div>
            <div
              className="my-3"
              style={{
                borderRadius: "12px",
                width: "350px",
                padding: "15px",
                boxShadow:
                  "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
              }}
            >
              <span style={{ marginRight: "220px", marginLeft: "20px" }}>
                <b>Task</b>
              </span>
              <ErrorOutlineRoundedIcon />
              <hr />
              <div className="d-flex justify-content-center">
                <ClipLoader
                  loading={loading}
                  size={30}
                  aria-label="Loading Spinner"
                  data-testid="loader"
                />
              </div>
              {data?.DailyTask?.reverse()
                .slice(0, 8)
                .map((v, index) => {
                  return (
                    <div
                      className="py-2 px-3"
                      key={index}
                      style={{ borderBottom: "1px solid gray" }}
                    >
                      <input
                        checked={v.done}
                        type="checkbox"
                        onChange={(e) => handleTodocomplete(v.todo)}
                      />
                      <span className="mx-2">{v.todo}</span>
                    </div>
                  );
                })}
            </div>
            <div
              style={{
                width: "350px",
                boxShadow: "rgba(0, 0, 0, 0.1) 0px 4px 8px",
                position: "relative",
              }}
            >
              <h4 className="mx-4 my-2">
                <b>Daily Goal</b>
              </h4>
              <GoalChart />
              <div
                style={{
                  position: "absolute",
                  zIndex: "50",
                  bottom: "33%",
                  left: "31%",
                  width: "80px",
                  height: "80px",
                  backgroundColor: "#dfe6e9",
                  borderRadius: "50%",
                }}
              >
                <h4 style={{ marginLeft: "14px", marginTop: "20px" }}>
                  <b>55%</b>
                </h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Classes;
