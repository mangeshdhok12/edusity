import React from "react";
import { PieChart, Pie, Cell } from "recharts";

const data = [
  { name: "Group A", value: 70 },
  { name: "Group B", value: 30 },
];
const COLORS = ["#0fbcf9", "#1e272e"];

const GoalChart = () => {
  return (
    <PieChart width={300} height={240}>
      <Pie
        data={data}
        startAngle={180}
        endAngle={0}
        innerRadius={60}
        outerRadius={120}
        fill="#8884d8"
        dataKey="value"
      >
        {data.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
        ))}
      </Pie>
    </PieChart>
  );
};

export default GoalChart;
