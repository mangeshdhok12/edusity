import React, { useState } from "react";
import { Container } from "react-bootstrap";
import Banner from "./components/Banner";
import Certification from "./components/Certification";
import Curriculum from "./components/Curriculum";
import EnrollmentProcess from "./components/EnrollmentProcess";
import Fee from "./components/Fee";
import InsightsBanner from "./components/InsightsBanner";
import Overview from "./components/Overview";
import TrainingProcess from "./components/TraningProcess";
import LatestTrend from "./components/LatestTrend";
import KnowledgePartner from "./components/KnowledgePartner";
import PlacementPartner from "./components/PlacementPartner";
import { themeColors } from "../../themes/colors";
import { useMediaQuery } from "@mui/material";
import { Link } from "react-scroll";

const Course = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  const [active, setActive] = useState();

  const Items = [
    { name: "Curriculum", goto: "#" },
    { name: "Knowledge Partner", goto: "#" },
    { name: "Career Insights", goto: "#" },
    { name: "Enrollment Process", goto: "#" },
    { name: "Our Trainer", goto: "#" },
    { name: "Fee structure", goto: "#" },
    { name: "Latest Trend", goto: "#" },
    { name: "Placement Partners", goto: "#" },
    { name: "Certification", goto: "#" },
  ];

  const hoverEffect = (e, mouse) => {
    if (mouse) {
      e.currentTarget.style.backgroundColor = themeColors.primary;
      e.currentTarget.style.color = "white";
      e.currentTarget.style.transition = "all 0.1s ease-in-out";
    } else {
      e.currentTarget.style.backgroundColor = "transparent";
      e.currentTarget.style.color = "black";
      e.currentTarget.style.transition = "all 0.1s ease-in-out";
    }
  };

  return (
    <div>
      <section id="Overview">
        <Banner data={data} />
      </section>
      <Container style={{ marginTop: "580px" }}>
        <section id="">
          <Overview data={data} />
        </section>
        {!isMobileScreen && (
          <div
            className="w-full sticky-top py-3"
            style={{
              display: "flex",
              justifyContent: "space-evenly",
              alignItems: "center",
              backgroundColor: "white",
              top: "66px",
              boxShadow: "0 0.125rem 0.25rem 0 rgb(0 0 0 / 11%)",
              marginTop: "3rem",
              height: "50px",
            }}
          >
            {Items.map((item, i) => {
              return (
                <div
                  className="d-flex justify-content-center align-items-center text-center"
                  key={i}
                >
                  <Link
                    onSetActive={() => setActive(true)}
                    style={{
                      cursor: "pointer",
                      fontSize: "15px",
                      borderRadius: "8px",
                      padding: "5px",
                    }}
                    onMouseEnter={(e) => {
                      hoverEffect(e, true);
                    }}
                    onMouseLeave={(e) => {
                      hoverEffect(e, false);
                    }}
                    activeStyle={{
                      backgroundColor: themeColors.primary,
                      color: "white",
                      borderRadius: "8px",
                      padding: "5px",
                      textDecoration: "none",
                    }}
                    duration={100}
                    spy
                    smooth
                    offset={-180}
                    to={item.name}
                  >
                    {item.name}
                  </Link>
                </div>
              );
            })}
          </div>
        )}
        <section id="Curriculum">
          <Curriculum data={data} />
        </section>
        <section id="Knowledge Partner">
          <KnowledgePartner id="Career Insights" data={data} />
        </section>
        <section id="Career Insights">
          <InsightsBanner data={data} />
        </section>
        <section id="Enrollment Process">
          <EnrollmentProcess data={data} />
        </section>
        <section id="Our Trainer">
          <TrainingProcess data={data} />
        </section>
        <section id="Fee structure">
          <Fee data={data} />
        </section>

        <section id="Latest Trend">
          <LatestTrend data={data} />
        </section>
        <section id="Placement Partners">
          <PlacementPartner data={data} />
        </section>
        <section id="Certification">
          <Certification data={data} />
        </section>
      </Container>
    </div>
  );
};

export default Course;
