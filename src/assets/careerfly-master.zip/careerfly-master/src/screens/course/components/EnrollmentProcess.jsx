import { useMediaQuery } from "@mui/material";
import React from "react";
import { themeColors } from "../../../themes/colors";
import { CgArrowLongRight, CgArrowLongDown } from "react-icons/cg";

const EnrollmentProcess = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div
      className={
        isMobileScreen
          ? "mt-5 p-3 d-flex flex-column justify-content-between"
          : "mt-5 p-5"
      }
      style={{
        backgroundColor: themeColors.coursePageBg,
        boxShadow: "1px 1px 4px 1px lightgray",
      }}
    >
      <div>
        <h2 className="text-center">
          <b>Enrollment Process</b>
        </h2>
      </div>
      <div
        className={
          isMobileScreen
            ? "mt-5 d-flex flex-column justify-content-between align-items-center"
            : "mt-5 d-flex justify-content-center"
        }
      >
        {data.course.enrollmentProcess?.map((item, i) => (
          <div key={i} className={isMobileScreen ? undefined : "d-flex"}>
            <div
              style={{
                boxShadow: "0px 3px 3.5px rgba(0,0,0,0.35)",
                borderRadius: "30px",
                display: "flex",
                flexDirection: "column",
                width: "210px",
                justifyContent: "center",
                padding: "10px",
              }}
            >
              <span
                className="mt-3 text-center d-flex flex-column justify-content-center"
                style={{ fontSize: "1.4rem", fontWeight: "bold" }}
              >
                {item.heading}
              </span>
              <span className="text-center my-2">
                <b>{item.desc}</b>
              </span>
            </div>
            {i === 2 ? undefined : isMobileScreen ? (
              <div
                className={
                  isMobileScreen
                    ? "py-4"
                    : "d-flex mx-2 py-5 text-center align-items-center"
                }
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <CgArrowLongDown size={50} />
              </div>
            ) : (
              <div className="d-flex align-items-center px-5">
                <CgArrowLongRight size={50} />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default EnrollmentProcess;
