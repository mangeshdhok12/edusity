import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { themeColors } from "../../../themes/colors";
import { SiLinkedin } from "react-icons/si";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation, Pagination } from "swiper";
import Link from "next/link";

const TrainingProcess = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  console.log(data);
  return (
    <div
      className={isMobileScreen ? "mt-5 p-3 " : "mt-5 p-5 "}
      style={{
        backgroundColor: themeColors.coursePageBg,
        boxShadow: "1px 1px 4px 1px lightgray",
      }}
    >
      <div>
        <h2>
          <b>{data.course.ourTrainers[0]?.heading}</b>
        </h2>
        <p className="pb-3">{data.course.ourTrainers[0]?.desc}</p>
      </div>
      <Swiper
        spaceBetween={50}
        pagination={true}
        navigation={isMobileScreen ? false : true}
        modules={[Navigation, Autoplay, Pagination]}
        autoplay={{ delay: 7000 }}
        slidesPerView={isMobileScreen ? 1 : 2}
      >
        {data.course.ourTrainers?.map((item, i) => {
          if (item.__typename === "Type1") {
            return;
          }
          return (
            <SwiperSlide
              key={i}
              className="align-items-center px-1"
              style={{
                border: `2px solid ${themeColors.primary}`,
                borderRadius: "10px",
                padding: isMobileScreen ? "10px" : "0px",
                paddingBottom: isMobileScreen ? "30px" : "",
                display: "flex",
                height: isMobileScreen ? "100%" : "270px",
                flexDirection: isMobileScreen ? "column" : "row",
                marginBottom: isMobileScreen ? "0.5rem" : "",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                }}
              >
                <div className="d-flex flex-column justify-content-center">
                  <Image
                    src={item.image?.url}
                    width={170}
                    height={270}
                    objectFit="contain"
                    alt="CareerFly"
                    placeholder="blur"
                    blurDataURL={item.image?.url}
                    style={{
                      borderRadius: "10px",
                    }}
                  />
                </div>
                <div
                  style={{
                    backgroundColor: "#e4bbb9",
                    width: "150px",
                    height: "150px",
                    clipPath: "circle(36.3% at 0 100%)",
                    position: "absolute",
                    bottom: -2,
                    left: -2,
                    zIndex: 10,
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "end",
                  }}
                >
                  <div>
                    <a
                      target="_blank"
                      rel="noopener noreferrer"
                      href={item?.text3[0]}
                    >
                      <div style={{ padding: "7px" }}>
                        <SiLinkedin color="#0077B5" size={25} />
                      </div>
                    </a>
                  </div>
                </div>
              </div>
              <div
                className="d-flex flex-column justify-conetent-center text-center"
                style={{
                  width: "65%",
                }}
              >
                <div className="">
                  <h2
                    className={isMobileScreen ? "mt-3" : "m-0"}
                    style={{
                      fontSize: isMobileScreen ? "20px" : "32px",
                      fontweight: 800,
                    }}
                  >
                    {item.text1}
                  </h2>
                  <h5
                    className="m-0 "
                    style={{
                      fontSize: isMobileScreen ? "17px" : "24px",
                      fontweight: 700,
                    }}
                  >
                    {item.text2}
                  </h5>
                </div>
                <p
                  className="m-0 mt-2"
                  style={{
                    fontSize: isMobileScreen ? "13px" : "17px",
                    fontweight: 700,
                  }}
                >
                  {item.text4}
                </p>
              </div>
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

export default TrainingProcess;
