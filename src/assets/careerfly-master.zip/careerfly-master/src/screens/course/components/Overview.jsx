import React from "react";
import { themeColors } from "../../../themes/colors";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import { BiPlus } from "react-icons/bi";
import ReactPlayer from "react-player";
import { useMediaQuery } from "@mui/material";
import { RichText } from "@graphcms/rich-text-react-renderer";

const Overview = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  console.log(data.course.programOverview);
  return (
    <div
      style={{
        backgroundColor: themeColors.coursePageBg,
        boxShadow: "1px 1px 4px 1px lightgray",
        marginTop: "100px",
        padding: "50px",
      }}
    >
      <div
        className={
          isMobileScreen
            ? "d-flex flex-column"
            : "d-flex justify-content-between"
        }
      >
        <div style={{ width: isMobileScreen ? undefined : "600px" }}>
          <h3>
            <b>{data.course.programOverview[0]?.heading}</b>
          </h3>
          <RichText
            content={data.course.programOverview[0]?.description?.raw}
          />
          <div>
            {data.course.programOverview?.map((item, j) => {
              if (j === 0) {
                return;
              }
              return (
                <Accordion key={j} className="my-2">
                  <AccordionSummary
                    expandIcon={<BiPlus />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography variant="">
                      <b>{item.heading}</b>
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography variant="">
                      <RichText content={item.description?.raw} />
                    </Typography>
                  </AccordionDetails>
                </Accordion>
              );
            })}
          </div>
        </div>
        <div
          className={
            isMobileScreen
              ? "d-flex justify-content-center mt-4"
              : "d-flex justify-content-center"
          }
        >
          {data?.course?.programOverview?.map((item, i) => {
            if (item.__typename === "HeadingAndContent") {
              console.log(item.content);
              return (
                <ReactPlayer
                  style={{ paddingLeft: isMobileScreen ? undefined : "10px" }}
                  width={isMobileScreen ? 350 : 400}
                  height={isMobileScreen ? 200 : 230}
                  url={item?.content}
                />
              );
            }
          })}
          {/*  */}
        </div>
      </div>
    </div>
  );
};

export default Overview;
