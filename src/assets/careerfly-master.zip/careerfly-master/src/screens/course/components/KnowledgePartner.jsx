import React, { useState } from "react";
import Image from "next/image";

const KnowledgePartner = ({ data }) => {
  const [isHover, setHover] = useState();

  return (
    <div
      className="mt-5 p-3 text-center"
      style={{
        boxShadow: "1px 1px 4px 1px lightgray",
        flexWrap: "wrap",
      }}
    >
      <p className=" pt-3 " style={{ fontSize: "2rem", fontWeight: "900" }}>
        Our Knowledge Partners
      </p>
      <div
        className="d-flex p-2 text-center"
        style={{ justifyContent: "center" }}
      >
        <div
          className="d-flex p-2 text-center["
          style={{ justifyContent: "center", flexWrap: "wrap" }}
        >
          {data.course.ourKnowledgePartners?.map((item, id) => {
            return (
              <div
                key={id}
                className="mx-4 my-2"
                style={{
                  borderRadius: "24px",
                  boxShadow: "1px 1px 3px grey",
                  backgroundColor: isHover == id ? "#EBF2F7" : "#f9f9f9",
                }}
                onMouseEnter={(e) => {
                  setHover(id);
                }}
                onMouseLeave={(e) => {
                  setHover(-1);
                }}
              >
                <Image
                  style={{
                    backgroundColor: isHover == id ? "#EBF2F7" : "#f9f9f9",
                    borderRadius: "24px",
                  }}
                  src={item.image?.url}
                  blurDataURL={item.image?.url}
                  alt="careerfly"
                  width={300}
                  height={120}
                  placeholder="blur"
                  objectFit="contain"
                />
                <div>
                  <p className="mb-0" style={{ fontSize: "1.2rem" }}>
                    {item.text1}
                  </p>
                  <p>{item.text2}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default KnowledgePartner;
