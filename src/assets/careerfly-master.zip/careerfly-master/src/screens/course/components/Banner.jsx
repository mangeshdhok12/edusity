import { useMediaQuery } from "@mui/material";
import React from "react";
import { RxDownload } from "react-icons/rx";
import Button from "../../../components/button/Button";
import { themeColors } from "../../../themes/colors";
import { useStateContext } from "../../../context/StateContext";
import { Container } from "react-bootstrap";
import { useRouter } from "next/router";

const Banner = ({ data }) => {
  const router = useRouter();
  const price = parseInt(data.course.feeStructure[0]?.text2);

  const { setQuoteOpen, setOrderData, setCourse, setCcd, setRouteFrom } =
    useStateContext();

  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div className="d-flex justify-content-center pt-lg-5">
      <div
        style={{
          display: "flex",
          position: "absolute",
          flexDirection: "column",
          paddingTop: isMobileScreen ? undefined : "2.5rem",
          color: themeColors.white,
          width: "100%",
          height: "480px",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPositionX: isMobileScreen ? "80%" : "60%",
          backgroundPositionY: isMobileScreen ? "10px" : "",
          backgroundImage: `url(${data.course.heroBanner[0]?.image?.url})`,
        }}
      >
        <div className="d-flex flex-column justify-content-between">
          <Container className="d-flex justify-content-start">
            <div
              style={{
                width: isMobileScreen ? "100%" : "50%",
              }}
              className="d-flex flex-column"
            >
              <h1
                className={`fw-semibold mt-5 ${
                  isMobileScreen ? "my-5 mb-2" : ""
                }`}
                style={{
                  fontSize: isMobileScreen ? "1.5rem " : "2.5rem",
                  paddingTop: isMobileScreen ? "6rem" : "",
                }}
              >
                {data.course.heroBanner[0]?.heading}
              </h1>
              <p
                className={` ${isMobileScreen ? "mt-2 mb-5" : "mt-4"}`}
                style={{
                  fontSize: isMobileScreen ? "0.8rem " : "1rem",
                }}
              >
                {data.course.heroBanner[0]?.desc}
              </p>
              <div
                className={`d-flex  justify-content-start ${
                  isMobileScreen ? "justify-content-between mb-5" : ""
                }  align-data.courses-start`}
              >
                <div className="my-4">
                  <Button
                    title="Apply Now"
                    padding={isMobileScreen ? "" : "10px 50px"}
                    fontSize={isMobileScreen ? "0.85rem" : "1rem"}
                    onClick={() => {

                      const date = new Date();

                      router.push("/payment");
                      console.log(data.course);
                      setOrderData({
                        courseTitle: data.course.title,
                        coursePrice: price,
                        courseRating: "4.5",
                        couponDiscount: "19",
                        courseMRP:
                          data.course.feeStructure[0]?.text1.split(" ")[0],
                        courseDiscount: data.course.feeStructure[0]?.text1
                          .split(" ")[1]
                          .split("% ")[0],
                        courseDescription: data.course.heroBanner[0]?.desc,
                        courseImage: data.course.image?.url,
                        courseProgram: data.course.feeStructure[0]?.text3,
                        coursePrice: price,
                        courseBenifits: data.course.feeStructure[1]?.text3,
                        couponCode: data.course.coupon[0]?.text1,
                        couponDiscount: data.course.coupon[0]?.text2,
                        date: date.toDateString(),
                        time: date.toLocaleTimeString(),
                        // date :  date.toLocaleSg('en-US', { timeZone: 'Asia/Kolkata' })

                      })
                      localStorage.setItem("orderData", JSON.stringify({
                        courseTitle: data.course.title,
                        coursePrice: price,
                        courseRating: "4.5",
                        couponDiscount: "19",
                        courseMRP:
                          data.course.feeStructure[0]?.text1.split(" ")[0],
                        courseDiscount: data.course.feeStructure[0]?.text1
                          .split(" ")[1]
                          .split("% ")[0],
                        courseDescription: data.course.heroBanner[0]?.desc,
                        courseImage: data.course.image?.url,
                        courseProgram: data.course.feeStructure[0]?.text3,
                        coursePrice: price,
                        courseBenifits: data.course.feeStructure[1]?.text3,
                        couponCode: data.course.coupon[0]?.text1,
                        couponDiscount: data.course.coupon[0]?.text2,
                        date: date.toDateString(),
                        time: date.toLocaleTimeString(),
                      }));
                      
                    }}
                  />
                </div>
                <div
                  className={isMobileScreen ? "mt-4 " : "mx-3 my-4"}
                  onClick={() => {
                    setCcd(data.course.syllabus.url);
                    // setCc(item.title);
                    setQuoteOpen(true);
                    setRouteFrom("Curriculam");
                    setCourse(data.course.title);
                  }}
                >
                  <Button
                    icon={<RxDownload />}
                    title="Download Syllabus"
                    fontSize={isMobileScreen ? "0.85rem" : "1rem"}
                    bgColor={themeColors.white}
                    padding={isMobileScreen ? "" : "10px 50px"}
                    color={themeColors.primary}
                  />
                </div>
              </div>
            </div>
          </Container>

          {isMobileScreen ? undefined : (
            <div
              style={{ marginTop: "70px" }}
              className="d-flex justify-content-center"
            >
              <Container
                className="d-flex justify-content-center"
                style={{
                  color: themeColors.black,
                }}
              >
                <div
                  className="d-flex justify-content-between"
                  style={{
                    backgroundColor: themeColors.white,
                    color: themeColors.black,
                    width: "100%",
                  }}
                >
                  {data.course.heroBanner?.map((item, i) => {
                    if (item.__typename === "Type1") {
                      return;
                    }

                    return (
                      <div
                        key={i}
                        style={{
                          border: "1px solid black",
                          padding: "1rem",
                          width: "100%",
                        }}
                      >
                        <div style={{ width: "100%" }}>
                          <h5>
                            <b>{item.text1}</b>
                          </h5>
                          <p>{item.text4}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </Container>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Banner;
