import Image from "next/image";
import React from "react";
import { themeColors } from "../../../themes/colors";
import Button from "../../../components/button/Button";
import { BiDownload } from "react-icons/bi";
import { useMediaQuery } from "@mui/material";
import FileSaver from "file-saver";

const InsightsBanner = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  const handleDownloadInsight = () => {
    FileSaver.saveAs("/assets/newCareerInside.png", "image.jpg");
  };

  return (
    <div className="mt-5" style={{ backgroundColor: "#fff" }}>
      <div>
        <div
          className={`d-flex justify-content-center ${
            isMobileScreen ? "p-2" : "p-5"
          } flex-column`}
          style={{ position: "relative" }}
        >
          <h2 className="text-center mb-5">
            <b>{data.course.title} Career Insights </b>
          </h2>
          <Image
            src={data.course.careerInsightBanner?.url}
            blurDataURL={data.course.careerInsightBanner?.url}
            alt="careerfly"
            width={1100}
            height={480}
            placeholder="blur"
            objectFit="contain"
          />

          <div
            style={
              isMobileScreen
                ? {
                    display: "flex",
                    justifyContent: "end",
                    marginTop: "1rem",
                  }
                : { position: "absolute", bottom: "8%", right: "15%" }
            }
          >
            <Button
              onClick={handleDownloadInsight}
              title="Download Insights"
              color={themeColors.primary}
              bgColor="#fff"
              icon={<BiDownload />}
              border="#fff"
              boxShadow="1px 1px 5px grey"
              fontSize={isMobileScreen ? "0.85rem" : "1rem"}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default InsightsBanner;
