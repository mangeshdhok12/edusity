import React, { useState } from "react";
import { themeColors } from "../../../themes/colors";
import { useMediaQuery } from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper";
import { IoIosArrowDropdown, IoIosArrowDropup } from "react-icons/io";
import { HiCheckCircle } from "react-icons/hi";

const Curriculum = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const [currentModule, setCurrentModule] = useState("");
  return (
    <div
      className={isMobileScreen ? "mt-5 p-3" : "mt-5 py-3 px-5"}
      style={{
        backgroundColor: themeColors.coursePageBg,
        boxShadow: "1px 1px 4px 1px lightgray",
      }}
    >
      <h3 style={{ fontSize: "2rem", textAlign: "center" }}>
        <b>Curriculum</b>
      </h3>
      <div className="">
        <Swiper
          breakpoints={{
            640: {
              width: 640,
              slidesPerView: 1,
            },

            768: {
              width: 768,
              slidesPerView: 2,
            },
          }}
          modules={[Autoplay, Pagination]}
          pagination={{ clickable: true }}
          autoplay={{ delay: 7000 }}
        >
          {data.course.curriculum?.map((item, index) => (
            <SwiperSlide key={index}>
              <div>
                <div
                  style={{
                    textAlign: "",
                    paddingBottom: "60px",
                  }}
                >
                  <div
                    className="btn d-flex justify-content-evenly"
                    style={{
                      fontWeight: 500,
                      color: "#fff",
                      fontSize: "1.5rem",
                      width: isMobileScreen ? "250px" : "300px",
                      backgroundColor: themeColors.primary,
                      borderColor: themeColors.primary,
                      padding: "10px 50px",
                      borderRadius:
                        currentModule == index + 1 ? "20px 20px 0 0" : "20px",
                      textShadow: "4px 4px 4px 1px #000",
                    }}
                    onClick={(e) => {
                      if (currentModule === index + 1) {
                        setCurrentModule(null);
                        return;
                      }
                      setCurrentModule(index + 1);
                    }}
                  >
                    {item.text1}
                    {currentModule == index + 1 ? (
                      <IoIosArrowDropup size={34} />
                    ) : (
                      <IoIosArrowDropdown size={34} />
                    )}
                  </div>
                  {currentModule === index + 1 ? (
                    <div>
                      <div
                        className="py-2 d-flex justify-content-start ps-2 "
                        style={{
                          marginTop: "-10px",
                          borderRadius: "0px 0px 20px 20px",
                          backgroundColor: themeColors.coursePageBg,
                          boxShadow: "1px 1px 4px 1px lightgray",
                          width: isMobileScreen ? "250px" : "300px",
                        }}
                      >
                        <div className="d-flex flex-column ">
                          {item.text3?.map((item2, j) => (
                            <div
                              key={j}
                              className="d-flex align-content-center justify-content-start"
                            >
                              <div style={{ marginTop: "-1px" }}>
                                <HiCheckCircle
                                  color={themeColors.primary}
                                  size={20}
                                />
                              </div>
                              &nbsp;
                              <div className="d-flex flex-column justify-content-center">
                                <p style={{ color: "#000" }}>
                                  <b>{item2}</b>
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : undefined}
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
};

export default Curriculum;
