import React from "react";
import { themeColors } from "../../../themes/colors";

const LatestTrend = ({ data }) => {
  return (
    <div
      className="mt-5 p-3 text-center"
      style={{
        backgroundColor: themeColors.coursePageBg,
        boxShadow: "1px 1px 4px 1px lightgray",
      }}
    >
      <h2 className="text-center">
        <b>{data.course.latestTrend?.heading}</b>
      </h2>
      <p className="text-start p-3">{data.course.latestTrend?.desc}</p>
    </div>
  );
};

export default LatestTrend;
