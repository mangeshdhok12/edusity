import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { FiCheckCircle } from "react-icons/fi";
import { themeColors } from "../../../themes/colors";

const Certification = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div
      className={
        isMobileScreen
          ? "mt-5 p-3 d-flex flex-column justify-content-between mb-5"
          : "mt-5 p-5 d-flex justify-content-center mb-5"
      }
      style={{
        boxShadow: "1px 1px 4px 1px lightgray",
        backgroundColor: themeColors.coursePageBg,
      }}
    >
      <div>
        <h3 className="text-center">
          <b>{data.course.certification?.text1}</b>
        </h3>
        <div
          className={
            isMobileScreen
              ? "d-flex flex-column justify-content-center mt-5"
              : "d-flex justify-content-center mt-5"
          }
        >
          <div className="d-flex justify-content-center">
            <Image
              placeholder="blur"
              blurDataURL={data.course.certification?.image?.url}
              src={data.course.certification?.image?.url}
              width={420}
              height={300}
              objectFit="contain"
              alt="careerfly"
            />
          </div>
          <div
            className={isMobileScreen ? "mt-4 ms-1" : "mt-3 ps-4"}
            style={{
              width: isMobileScreen ? undefined : "50%",
            }}
          >
            <p>{data.course.certification?.text4}</p>
            <div className="d-flex flex-column align-items-start">
              {data.course.certification?.text3?.map((item, index) => {
                return (
                  <div key={index}>
                    <p>
                      <FiCheckCircle color="lightgreen" /> {item}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Certification;
