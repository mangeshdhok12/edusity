import React from "react";
import Image from "next/image";
import { themeColors } from "../../../themes/colors";

const PlacementPartner = ({ data }) => {
  return (
    <div
      className="d-flex justify-content-center my-5 p-3 text-center"
      style={{
        boxShadow: "1px 1px 4px 1px lightgray",
        backgroundColor: themeColors.coursePageBg,
        flexWrap: "wrap",
      }}
    >
      <h2 className="pb-4 col-12 pb-3" style={{ fontWeight: "900" }}>
        Placement Partners
      </h2>
      {data.course.placementPartners?.map((item, index) => {
        return (
          <div key={index} className="col-lg-3 col-sm-5 mb-3 mx-1">
            <Image
              style={{ borderRadius: "24px" }}
              src={item.image?.url}
              blurDataURL={item.image?.url}
              alt="careerfly"
              width={150}
              height={80}
              placeholder="blur"
              objectFit="contain"
            />
            <div
              className=" d-flex text-center"
              style={{ justifyContent: "center", alignItems: "center" }}
            >
              <p style={{ fontSize: "1.1rem" }}>{item.text1}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default PlacementPartner;
