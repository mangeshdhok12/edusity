import { useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import Button from "../../../components/button/Button";
import { HiCheckCircle } from "react-icons/hi";
import { themeColors } from "../../../themes/colors";
import { currency } from "../../../themes/currency";

const Fee = ({ data }) => {
  const isSmallMobileScreen = useMediaQuery("(max-width: 320px)");
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const [clickedButton1, setClickedButton1] = useState(false);
  const [clickedButton2, setClickedButton2] = useState(false);
  const [clickedButton3, setClickedButton3] = useState(false);

  return (
    <div>
      <div
        className={isMobileScreen ? "mt-5 p-3" : "mt-5 p-5"}
        style={{
          backgroundColor: themeColors.coursePageBg,
          boxShadow: "1px 1px 4px 1px lightgrey",
        }}
      >
        <h2 className="text-center">
          <b>Fee Structure</b>
        </h2>

        <div
          className="d-flex "
          style={{
            flexWrap: "wrap",
            justifyContent: isMobileScreen ? "center" : "space-evenly",
          }}
        >
          <div
            className="d-flex"
            style={{
              flexDirection: isMobileScreen ? "column" : "row",
              justifyContent: isMobileScreen ? "center" : "space-evenly",
            }}
          >
            <div style={{ position: "relative" }}>
              <div
                className="my-3 mx-auto"
                style={{
                  width: isSmallMobileScreen ? "17rem" : "20rem",
                  margin: "0 2rem",
                  boxShadow: "1px 1px 4px 1px lightgray",
                  borderRadius: "25px",
                }}
              >
                <div
                  className="py-4 "
                  style={{
                    width: "100%",
                    height: "7rem",
                    backgroundColor: "#ebcbc9",
                    borderTopLeftRadius: "25px",
                    borderTopRightRadius: "25px",
                  }}
                >
                  <div className="d-flex justify-content-center align-items-center">
                    <p
                      className="m-0"
                      style={{
                        color: themeColors.primary,
                      }}
                    >
                      <b className="m-0">
                        <span>
                          <span style={{ textDecoration: "line-through" }}>
                            {data.course.feeStructure[0]?.text1.split(" ")[0]}
                          </span>
                          &nbsp;
                          {data.course.feeStructure[0]?.text1.split(" ")[1]}
                          &nbsp;
                          {data.course.feeStructure[0]?.text1.split(" ")[2]}
                        </span>
                      </b>
                    </p>
                  </div>
                  <div className="d-flex justify-content-center align-items-center fs-3 fw-bolder">
                    <p className="m-0">
                      {currency.symbol}
                      {data.course.feeStructure[0]?.text2}
                    </p>
                  </div>
                </div>

                <div
                  style={{
                    backgroundColor: themeColors.white,
                    borderBottomLeftRadius: "25px",
                    borderBottomRightRadius: "25px",
                    paddingTop: "3rem",
                    paddingBottom: "1rem",
                    position: "relative",
                  }}
                >
                  {clickedButton1 && (
                    <div>
                      {data.course.feeStructure[0]?.text3?.map((item, i) => (
                        <div
                          key={i}
                          className="d-flex align-items-center px-3 "
                        >
                          <HiCheckCircle
                            color={themeColors.primary}
                            size={20}
                          />
                          <p className="m-0 py-1 fs-6 mx-2">
                            <b>{item}</b>
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div
                  className="d-flex w-100 justify-content-center"
                  style={{
                    position: "absolute",
                    top: 110,
                  }}
                >
                  <Button
                    title="Program Fee"
                    fontSize={21}
                    fontWeight={600}
                    padding="5px 35px"
                  />
                </div>
                <div className="d-flex justify-content-center pb-3">
                  <Button
                    bgColor="white"
                    color={themeColors.primary}
                    title={clickedButton1 ? "View Less" : "View More"}
                    fontSize={15}
                    fontWeight={600}
                    padding="5px 35px"
                    onClick={(e) => {
                      setClickedButton1(!clickedButton1);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div
            className="d-flex"
            style={{
              flexDirection: isMobileScreen ? "column" : "row",
              justifyContent: isMobileScreen ? "center" : "space-evenly",
            }}
          >
            <div style={{ position: "relative" }}>
              <div
                className="my-3 mx-auto"
                style={{
                  boxShadow: "1px 1px 4px 1px lightgray",
                  borderRadius: "25px",
                  margin: "0 2rem",
                  width: isSmallMobileScreen ? "17rem" : "20rem",
                }}
              >
                <div
                  className="py-4"
                  style={{
                    width: "100%",
                    height: "7rem",
                    backgroundColor: "#ebcbc9",
                    borderTopLeftRadius: "25px",
                    borderTopRightRadius: "25px",
                    paddingBottom: "10px",
                    alignItems: "center",
                  }}
                >
                  <div className="d-flex justify-content-center align-items-center fs-3 fw-bolder">
                    <p style={{ marginTop: "14px" }}>
                      {data.course.feeStructure[1]?.text1}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    backgroundColor: themeColors.white,
                    borderRadius: "25px",
                    paddingTop: "3rem",
                    paddingBottom: "1rem",
                    position: "relative",
                  }}
                >
                  {clickedButton2 && (
                    <div>
                      {data.course.feeStructure[1]?.text3.map((item, i) => (
                        <div
                          key={i}
                          className="d-flex align-items-center px-3 "
                        >
                          <HiCheckCircle
                            color={themeColors.primary}
                            size={20}
                          />
                          <p className="m-0 py-1 fs-6 mx-2">
                            <b>{item}</b>
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div
                  className="d-flex w-100 justify-content-center"
                  style={{
                    position: "absolute",
                    top: 110,
                  }}
                >
                  <Button
                    title="Free"
                    fontSize={21}
                    fontWeight={600}
                    padding="5px 35px"
                  />
                </div>
                <div className="d-flex justify-content-center pb-3">
                  <Button
                    title={clickedButton2 ? "View Less" : "View More"}
                    fontSize={15}
                    fontWeight={600}
                    padding="5px 30px"
                    bgColor={themeColors.white}
                    color={themeColors.primary}
                    onClick={(e) => {
                      setClickedButton2(!clickedButton2);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          <div
            className="d-flex"
            style={{
              flexDirection: isMobileScreen ? "column" : "row",
              justifyContent: isMobileScreen ? "center" : "space-evenly",
            }}
          >
            <div style={{ position: "relative" }}>
              <div
                className="my-3 mx-auto"
                style={{
                  width: isSmallMobileScreen ? "17rem" : "20rem",
                  boxShadow: "1px 1px 4px 1px lightgray",
                  borderRadius: "25px",
                }}
              >
                <div
                  className="py-3 px-5"
                  style={{
                    width: "100%",
                    height: "7rem",
                    backgroundColor: "#7FEDD2",
                    borderTopLeftRadius: "25px",
                    borderTopRightRadius: "25px",
                  }}
                >
                  <div className="justify-content-center">
                    <p
                      className="m-0 text-center"
                      style={{
                        color: "white",
                      }}
                    >
                      {data.course.feeStructure[2]?.text1}
                    </p>
                  </div>
                  <div className="d-flex justify-content-center mb-3 pb-1 align-items-center">
                    <p className="m-0  fs-3 fw-bolder">
                      {currency.symbol}
                      {data.course.feeStructure[2]?.text2}
                    </p>
                  </div>
                </div>
                <div
                  style={{
                    backgroundColor: themeColors.white,
                    borderBottomLeftRadius: "25px",
                    borderBottomRightRadius: "25px",
                    paddingTop: "3rem",
                    paddingBottom: "1rem",
                    position: "relative",
                  }}
                >
                  {clickedButton3 && (
                    <div>
                      {data.course.feeStructure[2]?.text3.map((item, i) => (
                        <div
                          key={i}
                          className="d-flex align-items-center px-3 "
                        >
                          <HiCheckCircle color="#0BAA81" size={20} />
                          <p className="m-0 py-1 fs-6 mx-2">
                            <b>{item}</b>
                          </p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <div
                  className="d-flex w-100 justify-content-center"
                  style={{
                    position: "absolute",
                    top: 110,
                  }}
                >
                  <Button
                    border=""
                    bgColor="#0BAA81"
                    title="EMI"
                    fontSize={21}
                    fontWeight={600}
                    padding="5px 35px"
                  />
                </div>
                <div className="d-flex justify-content-center pb-3">
                  <Button
                    border=""
                    bgColor={themeColors.white}
                    title={clickedButton3 ? "View Less" : "View More"}
                    fontSize={15}
                    fontWeight={600}
                    color={"#0BAA81"}
                    padding="5px 30px"
                    onClick={(e) => {
                      setClickedButton3(!clickedButton3);
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Fee;
