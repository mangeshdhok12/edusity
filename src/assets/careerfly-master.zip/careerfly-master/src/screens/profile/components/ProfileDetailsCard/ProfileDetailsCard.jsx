import {
  DialogTitle,
  Dialog,
  useMediaQuery,
  DialogContent,
  TextField,
} from "@mui/material";
import React, { useState } from "react";
import { Card } from "react-bootstrap";
import Button from "../../../../components/button/Button";
import { themeColors } from "../../../../themes/colors";
import { useEffect } from "react";
import { db, storage, auth } from "../../../../lib/firebase";
import { doc, getDoc, updateDoc } from "firebase/firestore";
import { signOut } from "firebase/auth";
import { RxCross1 } from "react-icons/rx";
import { ref, uploadBytesResumable } from "firebase/storage";
import { useStateContext } from "../../../../context/StateContext";
import Image from "next/image";

function ProfileDetailsCard() {
  const { googleLogin, userData } = useStateContext();

  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [number, setNumber] = useState("");
  const [address, setAddress] = useState("");
  const [photo, setPhoto] = useState(undefined);
  const [editProfile, setEditProfile] = useState(false);
  const [enrolledCourses, setEnrolledCourses] = useState(0);

  const handleLogOut = () => {
    window.location.href = "/";
    signOut(auth);
    localStorage.removeItem("CareerFlyUser");
  };

  const handleSubmit = async (e, name, email, address, number, photo) => {
    e.preventDefault();
    const user = await JSON.parse(localStorage.getItem("CareerFlyUser"));
    if (user?.user?.uid) {
      const docRef = doc(db, "users", user?.user?.uid);
      const updatedUser = {
        name: name,
        email: email,
        address: address,
        number: number,
      };
      await updateDoc(docRef, updatedUser);
    }

    if (!photo) {
      alert("Please select a photo");
    } else {
      const storageRef = ref(storage, `/files/${user?.user?.uid}`);
      const uploadTask = await uploadBytesResumable(storageRef, photo);
    }
    setEditProfile(false);
    window.location.reload();
  };

  const getUserProfileInfo = async () => {
    const user1 = JSON.parse(localStorage.getItem("CareerFlyUser"));
    const getData1 = doc(db, "users", user1?.user?.uid);
    const getData = await getDoc(getData1);
    const data = getData.data();
    setName(data?.name);
    setEmail(data?.email);
    setAddress(data?.address);
    setNumber(data?.number);
    if (googleLogin) {
      setPhoto(data?.photo);
    }
    setEnrolledCourses(data?.enrolledCourses);
  };
  const getUserPhoto = async () => {
    const user1 = JSON.parse(localStorage.getItem("CareerFlyUser"));
    let storageRef = storage.ref(`/files/${user1?.user?.uid}`);
    const data = storageRef
      .getDownloadURL()
      .then((url) => {
        setPhoto(url);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    getUserProfileInfo();
    if (!googleLogin) {
      getUserPhoto();
    }
  }, []);

  return (
    <>
      <div className="">
        <div className="mt-5 py-5">
          <Card className={`w-${isMobileScreen ? "full" : "75"}`}>
            <Card.Body
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <div
                style={{
                  borderRadius: "50%",
                  boxShadow: "1px 3px 5px 3px lightgray",
                }}
              >
                <Image
                  style={{ borderRadius: "50%" }}
                  alt="careerfly"
                  src={userData.imgUrl ? photo : "/assets/altProfile.png"}
                  width={100}
                  height={100}
                  placeholder="blur"
                  objectFit="contain"
                  blurDataURL={
                    userData.imgUrl ? photo : "/assets/altProfile.png"
                  }
                />
              </div>

              <div className="mt-4">
                <Button
                  icon={<i className="bi bi-pencil-square" />}
                  width="150px"
                  marginTop="12px"
                  title="Edit Profile"
                  onClick={() => setEditProfile(true)}
                />
              </div>
            </Card.Body>
            <div
              style={{
                padding: isMobileScreen ? undefined : "0px 100px 0px 100px",
              }}
            >
              <Card.Body>
                <div>
                  <div
                    className="d-flex justify-content-center align-items-center gap-3"
                    style={{
                      height: "3rem",
                    }}
                  >
                    <h5 className="m-0 fs-5 fw-bolder">Name:</h5>
                    <p className="fs-4 mt-1 m-0">{name}</p>
                  </div>
                  <div
                    className="d-flex justify-content-center align-items-center gap-3"
                    style={{
                      height: "3rem",
                    }}
                  >
                    <h5 className="m-0 fs-5 fw-bolder">Email:</h5>
                    <p className="fs-4  m-0">{email}</p>
                  </div>
                  <div
                    className="d-flex justify-content-center align-items-center gap-3"
                    style={{
                      height: "3rem",
                    }}
                  >
                    <h5 className="m-0 fs-5 fw-bolder">Contact:</h5>
                    <p className="fs-4 mt-1 m-0">{number}</p>
                  </div>
                  <div
                    className="d-flex justify-content-center align-items-center gap-3"
                    style={{
                      height: "3rem",
                    }}
                  >
                    <h5 className="m-0 fs-5 fw-bolder">Address:</h5>
                    <p className="fs-4 mt-1 m-0">{address}</p>
                  </div>
                  <div
                    className="d-flex justify-content-center align-items-center gap-3"
                    style={{
                      height: "3rem",
                    }}
                  >
                    <h5 className="m-0 fs-5 fw-bolder">Enrolled Courses:</h5>
                    <p className="fs-4  m-0">{enrolledCourses}</p>
                  </div>
                </div>
              </Card.Body>
            </div>
            <Card.Body
              style={{
                padding: isMobileScreen ? undefined : "50px 100px 50px 100px",
              }}
            >
              <div className="d-flex justify-content-center">
                <Button
                  title="Log Out"
                  bgColor={themeColors?.primary}
                  onClick={() => handleLogOut()}
                />
              </div>
            </Card.Body>
          </Card>
        </div>
        <Dialog
          open={editProfile}
          maxWidth={"md"}
          aria-labelledby="alert-dialog-title"
          aria-describedby="alert-dialog-description"
        >
          <DialogTitle
            className="d-flex justify-content-between"
            id="alert-dialog-title"
            style={{
              backgroundColor: themeColors.white,
            }}
          >
            <div className="fs-2 fw-bolder">Edit Profile</div>
            <div
              onClick={() => setEditProfile(false)}
              style={{ cursor: "pointer" }}
            >
              <RxCross1 />
            </div>
          </DialogTitle>
          <DialogContent
            sx={{
              width: "40rem",
              padding: "2rem 5rem",
            }}
          >
            <form>
              <div>
                <p>Photo is not working(Work in progress) rest is working</p>
                <TextField
                  autoFocus
                  id="photo"
                  type="file"
                  fullWidth
                  size="small"
                  color="warning"
                  margin="dense"
                  onChange={(e) => setPhoto(e.target.files[0])}
                />
              </div>
              <TextField
                autoFocus
                id="email"
                type="text"
                label="Update Your Name"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
                margin="dense"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              <TextField
                autoFocus
                type="email"
                id="email"
                label="Update Your Email Address"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
                margin="dense"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <TextField
                autoFocus
                id="name"
                type="text"
                label="Update Your Address"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
                margin="dense"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <TextField
                autoFocus
                id="number"
                type="text"
                label="Update Your Mobile Number"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
                margin="dense"
                value={number}
                onChange={(e) => setNumber(e.target.value)}
              />
              <div className="d-flex justify-content-center my-3">
                <Button
                  title="Update"
                  bgColor={themeColors.primary}
                  onClick={(e) =>
                    handleSubmit(e, name, email, address, number, photo)
                  }
                />
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}

export default ProfileDetailsCard;
