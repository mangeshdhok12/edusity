import React from "react";
import { Container } from "react-bootstrap";
import { useStateContext } from "../../context/StateContext";
import { themeColors } from "../../themes/colors";
import LogIn from "../auth/components/logIn/LogIn";
import ProfileDetailsCard from "./components/ProfileDetailsCard/ProfileDetailsCard";

const ProfileScreen = () => {
  const { userToken } = useStateContext();
  return (
    <>
      <Container>
        {userToken ? (
          <div>
            <div>
              <ProfileDetailsCard />
            </div>
          </div>
        ) : (
          <LogIn />
        )}
      </Container>
    </>
  );
};

export default ProfileScreen;
