export const data = [
  {
    __typename: "Category",
    categoryName: "Industry",
    trending: true,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Marketing",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "HR",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "ITES",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Finance",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Software",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Business Development",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Job Type",
    trending: true,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Work from Home",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Onsite",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Hybrid",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "No fixed hours",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Part time",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Freelancing",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Entrepreneurship Possibilities",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Desk job",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Program Duration",
    trending: null,
    subCategories: [],
  },
  {
    __typename: "Category",
    categoryName: "Nature of Job",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Coding",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Semi Coding",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "No Coding",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Field Job",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Target Job",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Education Level",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "10th - 12th",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Graduate",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Dropout",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Post Graduate",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Doctorate",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Education Stream",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Mechanical",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Electronic",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Commerce",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Arts",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Science",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Computer Science",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Civil",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Other",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Fees",
    trending: null,
    subCategories: [],
  },
  {
    __typename: "Category",
    categoryName: "Working Days",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "5 Days",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "6 Days",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "5.5 Days",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Shift",
    trending: true,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "India Day (9 am -6 pm)",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "US Night (6:30 pm– 3:30 am)",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "UK Noon (2:00 pm to 11 :PM)",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Candidate Status",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Student",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Fresher",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Professional",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Initial Package",
    trending: true,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "2 - 3 LPA",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "3 - 5 LPA",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "5+ LPA",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Communication / 10",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "0 - 3 ",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "3 - 5 ",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "5 - 7",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "7 +",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Benefits",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Medical",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Food",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "PF",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Incentives",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Commission",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Paid off",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Corporate Environment",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Personality Traits",
    trending: true,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "Introvert",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Extrovert",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Talkative",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Silent",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Creative",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Writing Expert",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Dedicated",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "hard worker",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Smart worker",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Optimistic",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Team player",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Individual Contributor",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Follower",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Leader",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Disciplined",
      },
    ],
  },
  {
    __typename: "Category",
    categoryName: "Computer Skills",
    trending: null,
    subCategories: [
      {
        __typename: "SubCategory",
        subcategoryName: "MS Office",
      },
      {
        __typename: "SubCategory",
        subcategoryName: "Computer shortcuts",
      },
    ],
  },
];
