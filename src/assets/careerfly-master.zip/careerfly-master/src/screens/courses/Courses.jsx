import React, { useState } from "react";
import { Container, Modal } from "react-bootstrap";
import { themeColors } from "../../themes/colors";
import Image from "next/image";
import { RxLapTimer } from "react-icons/rx";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Slider,
  useMediaQuery,
} from "@mui/material";
import Button from "../../components/button/Button";
import Link from "next/link";
import { BiFilterAlt } from "react-icons/bi";
import { ImCross } from "react-icons/im";
import FilterCourses from "./components/FilterCourses";
import { BsDownload } from "react-icons/bs";
import CoursesBanner from "./components/CoursesBanner";
import { MdOutlineHighlight } from "react-icons/md";
import { Typography } from "@material-ui/core";
import { currency } from "../../themes/currency";
import { useStateContext } from "../../context/StateContext";

const Courses = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  const { setQuoteOpen, setCc, setCcd, setRouteFrom, setCourse } =
    useStateContext();

  const [openFilter, setOpenFilter] = useState(false);

  const [filteredCourses, setFilteredCourses] = useState([]);

  const [valueFees, setValueFees] = useState([0, 500000]);

  const [valueProgramDuration, setValueProgramDuration] = useState([1, 24]);

  const handleChangeFees = (e, newValue) => {
    setValueFees(newValue);
  };

  const handleChangeDuration = (e, newValue) => {
    setValueProgramDuration(newValue);
  };

  return (
    <div>
      <Container>
        <CoursesBanner data={data} />
      </Container>
      <div
        className={
          isMobileScreen ? undefined : "p-3 mb-5 d-flex justify-content-center"
        }
      >
        <Container>
          <div
            className={
              isMobileScreen
                ? "d-flex p-2 justify-content-center"
                : "d-flex gap-5 justify-content-center"
            }
          >
            {isMobileScreen ? (
              <div
                onClick={() => setOpenFilter(true)}
                className="position-fixed"
                style={{
                  zIndex: 11,
                  cursor: "pointer",
                  display: "flex",
                  bottom: 10,
                  left: 10,
                  width: "45px",
                  height: "45px",
                  borderRadius: "50%",
                  backgroundColor: themeColors.primary,
                  padding: "5px",
                }}
              >
                <div className="m-auto">
                  <BiFilterAlt color="white" size={25} />
                </div>
              </div>
            ) : (
              <FilterCourses
                data={data}
                setFilteredCourses={setFilteredCourses}
                filteredCourses={filteredCourses}
                valueFees={valueFees}
                setValueFees={setValueFees}
                valueProgramDuration={valueProgramDuration}
                setValueProgramDuration={setValueProgramDuration}
              />
            )}

            <div className="w-100">
              <h3
                className="mb-5 mt-2 fw-bolder"
                style={{ color: themeColors?.primary }}
              >
                Our Placement Programs - &nbsp;
                <span style={{ color: themeColors?.textPrimary }}>
                  Get to start
                </span>
              </h3>
              <div
                style={{
                  overflowX: "auto",
                  width: isMobileScreen ? "100%" : "100%",
                }}
                className="pb-5 d-flex"
              >
                {data.subCategories?.map((item, index) => {
                  const label = item.subcategoryName;

                  if (item.trending === false || item.trending === null) {
                    return;
                  }

                  return (
                    <button
                      onClick={() => {
                        if (filteredCourses?.includes(item.subcategoryName)) {
                          setFilteredCourses(
                            filteredCourses.filter(
                              (item3) => item3 !== item.subcategoryName
                            )
                          );
                          return;
                        }

                        setFilteredCourses([
                          ...filteredCourses,
                          item.subcategoryName,
                        ]);
                      }}
                      key={index}
                      value={label}
                      onMouseEnter={(e) => {
                        e.target.style.background = themeColors.primary;
                        e.target.style.color = "#fff";
                      }}
                      onMouseLeave={(e) => {
                        if (filteredCourses?.includes(label)) {
                          return;
                        }
                        e.target.style.background = "white";
                        e.target.style.color = "#000";
                      }}
                      className="px-2 ms-0 mx-2"
                      style={{
                        whiteSpace: "nowrap",
                        border: `1px solid ${themeColors.primary}`,
                        backgroundColor: filteredCourses?.includes(
                          item.subcategoryName
                        )
                          ? themeColors.primary
                          : "white",
                        color: filteredCourses?.includes(item.subcategoryName)
                          ? "white"
                          : "black",
                        borderRadius: "10px",
                      }}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>

              <div style={{ marginTop: "-65px" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "center",
                    flexWrap: "wrap",
                  }}
                >
                  {data.courses?.map((item, i) => {
                    let flag = false;

                    item.subCategories?.map((item2) => {
                      filteredCourses?.map((item3) => {
                        if (item3 === item2.subcategoryName) {
                          flag = true;
                        }
                      });
                    });

                    if (flag || filteredCourses?.length === 0) {
                      const price = item.feeStructure[0]?.text1.split(" ")[0];
                      const duration = item.duration?.split(" ")[0];

                      if (
                        price > valueFees[0] &&
                        price <= valueFees[1] &&
                        duration > valueProgramDuration[0] &&
                        duration <= valueProgramDuration[1]
                      ) {
                        return (
                          <div className="mt-5" key={i}>
                            <div
                              className="d-flex flex-column justify-content-between"
                              style={{
                                borderRadius: "10px",
                                width: "300px",
                                height: "100%",
                                margin: "10px",
                                border: `1px solid ${themeColors.textLight}`,
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.transform = "scale(1.02)";
                                e.currentTarget.style.boxShadow =
                                  "1px 2px 15px 3px gray";
                                e.currentTarget.style.transition =
                                  "all 0.3s ease-in-out";
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.transform = "scale(1)";
                                e.currentTarget.style.boxShadow = "none";
                                e.currentTarget.style.transition =
                                  "all 0.3s ease-in-out";
                              }}
                            >
                              <div style={{ position: "relative" }}>
                                <div
                                  style={{
                                    position: "absolute",
                                    zIndex: "100",
                                    padding: "0 0.5em",
                                    width: "40%",
                                    fontSize: "1em",
                                    marginLeft: "-15px",
                                    lineHeight: "2em",
                                    color: "#e6e2c8",
                                    borderRadius: "0 0.2em 0.2em 0",
                                    background: themeColors.primary,
                                    boxShadow: "-1px 2px 5px rgba(0,0,0,0.5)",
                                    top: "2em",
                                  }}
                                >
                                  <p className="m-0 p-0">
                                    {item?.certificationLabel}
                                  </p>
                                </div>
                                <div
                                  style={{
                                    position: "absolute",
                                    width: "23px",
                                    height: "20px",
                                    backgroundColor: themeColors.primary,
                                    filter: "brightness(90%)",
                                    marginLeft: "-11.49px",
                                    marginTop: "55px",
                                    transform: "rotate(45deg)",
                                  }}
                                />
                                <div>
                                  <Image
                                    style={{
                                      borderRadius: "10px 10px 0 0 ",
                                    }}
                                    src={
                                      item.image?.url
                                        ? item.image?.url
                                        : "/assets/altCourse.jpg"
                                    }
                                    alt="careerfly"
                                    width={350}
                                    height={233}
                                    placeholder="blur"
                                    blurDataURL={
                                      item.image?.url
                                        ? item.image?.url
                                        : "/assets/altCourse.jpg"
                                    }
                                    objectFit="cover"
                                  />
                                </div>
                                <div
                                  className="d-flex w-100 p-1"
                                  style={{
                                    marginTop: "-5px",
                                    borderRadius: "8px",
                                    boxShadow:
                                      "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
                                    border: `3px solid ${themeColors.primary}`,
                                  }}
                                >
                                  <div className="px-2 w-25 d-flex justify-content-center align-items-center">
                                    <Image
                                      src={item.courseCardIcon?.url}
                                      width={32}
                                      height={32}
                                      alt="Careerfly"
                                      placeholder="blur"
                                      blurDataURL={item.courseCardIcon?.url}
                                    />
                                  </div>
                                  <div
                                    className="w-100 d-flex justify-content-center align-items-center fw-bold "
                                    style={{
                                      fontSize: "17px",
                                      borderLeft: "2px solid #000",
                                      alignContent: "center",
                                    }}
                                  >
                                    {item.chooseCourseType[0] ===
                                    "Placement_Program"
                                      ? "Placement Program"
                                      : "Skill Certification"}
                                  </div>
                                </div>
                                <div className="p-2 m-0">
                                  <h5 className="fs-4 m-0">{item.title}</h5>
                                  <p className="fs-6">{item.desc}</p>
                                </div>
                              </div>

                              <div
                                className="p-2"
                                style={{ borderRadius: "20px" }}
                              >
                                <div>
                                  <div className="d-flex gap-2 align-items-center">
                                    <RxLapTimer size={20} />
                                    <p className="m-0 fs-6">{item.duration} </p>
                                  </div>
                                  <div className="d-flex gap-2 align-items-center">
                                    <MdOutlineHighlight size={20} />
                                    <p className="m-0 fs-6">{item.insights}</p>
                                  </div>
                                </div>

                                <div className="d-flex my-2 justify-content-between">
                                  <div
                                    onClick={() => {
                                      setCcd(item?.curriculumDoc?.url);
                                      setCc(item.title);
                                      setQuoteOpen(true);
                                      setRouteFrom("Curriculam");
                                      setCourse(item.title);
                                    }}
                                    className="d-flex w-50 justify-content-center"
                                  >
                                    <Button
                                      fontSize={14}
                                      title="CURRICULUM"
                                      bgColor={themeColors.backgroundColor}
                                      color={themeColors.primary}
                                      icon={<BsDownload />}
                                      border={themeColors.primary}
                                      marginBottom="0"
                                      boxShadow="1px 1px 2px 1px lightgray"
                                      marginTop="0"
                                    />
                                  </div>
                                  <Link href={`/courses/${item.slug}`}>
                                    <div className="d-flex w-50 justify-content-center">
                                      <Button
                                        fontSize={14}
                                        title="KNOW MORE"
                                        marginBottom="0"
                                        marginTop="0"
                                      />
                                    </div>
                                  </Link>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      }
                    }
                  })}
                </div>
              </div>
            </div>
          </div>
          {openFilter && isMobileScreen && (
            <div
              className="modal show"
              style={{
                display: "block",
                position: "fixed",
                top: "50%",
                left: "50%",
                transform: "translate(-50%,-50%)",
              }}
            >
              <Modal.Dialog>
                <Modal.Header className="d-flex justify-content-end">
                  <ImCross onClick={() => setOpenFilter(false)} />
                </Modal.Header>
                <Modal.Body className="m-auto">
                  <div className="mt-5">
                    {data.categories?.map((item2, j) => {
                      return (
                        <div key={j} className="mt-3">
                          <Accordion
                            style={{
                              width: "280px",
                              borderBottom: `1px solid ${themeColors.primary}`,
                              marginTop: "5px",
                            }}
                          >
                            <AccordionSummary
                              onMouseEnter={(e) => {
                                e.currentTarget.style.backgroundColor =
                                  themeColors.primary;
                                e.currentTarget.style.color = "white";
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.backgroundColor = "white";
                                e.currentTarget.style.color = "black";
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls="panel1a-content"
                              id="panel1a-header"
                            >
                              <Typography variant="undefined">
                                {item2.categoryName}
                              </Typography>
                            </AccordionSummary>
                            <AccordionDetails>
                              <Typography variant="undefined">
                                <div className="d-flex flex-column flex-wrap">
                                  <div className="d-flex">
                                    {item2.categoryName === "Fees" ||
                                    item2.categoryName ===
                                      "Program Duration" ? (
                                      <Box width={200}>
                                        <span
                                          style={{ width: "250px" }}
                                          className="d-flex justify-content-between"
                                        >
                                          <span
                                            className={
                                              item2.categoryName ===
                                              "Program Duration"
                                                ? "d-flex flex-row-reverse"
                                                : undefined
                                            }
                                          >
                                            <span>
                                              {item2.categoryName === "Fees"
                                                ? currency.symbol
                                                : `month(s)`}
                                            </span>
                                            &nbsp;
                                            <span>
                                              {item2.categoryName === "Fees"
                                                ? valueFees[0]
                                                : valueProgramDuration[0]}
                                            </span>
                                          </span>
                                          <span
                                            className={
                                              item2.categoryName ===
                                              "Program Duration"
                                                ? "d-flex flex-row-reverse"
                                                : undefined
                                            }
                                          >
                                            <span>
                                              {item2.categoryName === "Fees"
                                                ? currency.symbol
                                                : `month(s)`}
                                            </span>
                                            &nbsp;
                                            <span>
                                              {item2.categoryName === "Fees"
                                                ? valueFees[1]
                                                : valueProgramDuration[1]}
                                            </span>
                                          </span>
                                        </span>
                                        <Slider
                                          onChange={
                                            item2.categoryName === "Fees"
                                              ? handleChangeFees
                                              : handleChangeDuration
                                          }
                                          value={
                                            item2.categoryName === "Fees"
                                              ? valueFees
                                              : valueProgramDuration
                                          }
                                          sx={{ color: themeColors.primary }}
                                          min={0}
                                          max={
                                            item2.categoryName ===
                                            "Program Duration"
                                              ? 24
                                              : 500000
                                          }
                                        />
                                      </Box>
                                    ) : (
                                      <div>
                                        {item2.subCategories?.map(
                                          (item3, k) => {
                                            return (
                                              <div key={k}>
                                                <input
                                                  checked={filteredCourses.includes(
                                                    item3.subcategoryName
                                                  )}
                                                  onClick={(e) => {
                                                    if (
                                                      e.currentTarget.checked
                                                    ) {
                                                      setFilteredCourses([
                                                        ...filteredCourses,
                                                        e.currentTarget.value,
                                                      ]);
                                                    } else {
                                                      filteredCourses?.map(
                                                        (item) => {
                                                          if (
                                                            item ===
                                                            e.currentTarget
                                                              .value
                                                          ) {
                                                            setFilteredCourses(
                                                              filteredCourses.filter(
                                                                (item) =>
                                                                  item !==
                                                                  e
                                                                    .currentTarget
                                                                    .value
                                                              )
                                                            );
                                                          }
                                                        }
                                                      );
                                                    }
                                                  }}
                                                  style={{
                                                    accentColor:
                                                      themeColors.primary,
                                                  }}
                                                  type="checkbox"
                                                  id="cb"
                                                  name={item3.subcategoryName}
                                                  value={item3.subcategoryName}
                                                />
                                                <label className="mx-2">
                                                  {item3.subcategoryName}
                                                </label>
                                              </div>
                                            );
                                          }
                                        )}
                                      </div>
                                    )}
                                    <br />
                                  </div>
                                </div>
                              </Typography>
                            </AccordionDetails>
                          </Accordion>
                        </div>
                      );
                    })}
                  </div>
                </Modal.Body>
              </Modal.Dialog>
            </div>
          )}
        </Container>
      </div>
    </div>
  );
};

export default Courses;
