import Image from "next/image";
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import { useMediaQuery } from "@mui/material";
import { Container } from "react-bootstrap";

function CoursesBanner({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <Container>
      <div
        style={{ marginTop: isMobileScreen ? "3rem" : "6rem" }}
        className="d-flex justify-content-center"
      >
        <Swiper modules={[Autoplay]} autoplay={{ delay: 3000 }}>
          {data.globalModels[0]?.coursesBanner?.map((item, i) => (
            <SwiperSlide className="d-flex justify-content-center" key={i}>
              <Image
                src={item.url}
                width={isMobileScreen ? 400 : 1920}
                alt="careerfly"
                height={isMobileScreen ? 150 : 500}
                objectFit="contain"
                placeholder="blur"
                blurDataURL={item.url}
              />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </Container>
  );
}

export default CoursesBanner;
