import React, { useState } from "react";
import Box from "@mui/material/Box";
import Slider from "@mui/material/Slider";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Typography,
  useMediaQuery,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { themeColors } from "../../../themes/colors";
import Button from "../../../components/button/Button";
import { currency } from "../../../themes/currency";

const FilterCourses = ({
  data,
  setFilteredCourses,
  filteredCourses,
  valueFees,
  setValueFees,
  valueProgramDuration,
  setValueProgramDuration,
}) => {
  const isMobileScreen = useMediaQuery("(max-width: 768px)");

  const [viewAllCoursesCategory, setViewAllCoursesCategory] = useState(true);

  const handleChangeFees = (e, newValue) => {
    setValueFees(newValue);
  };

  const handleChangeDuration = (e, newValue) => {
    setValueProgramDuration(newValue);
  };

  return (
    <div style={{ marginTop: "90px" }}>
      {!isMobileScreen && (
        <div>
          <h3>Career Preferences</h3>
        </div>
      )}
      {viewAllCoursesCategory ? (
        <div className="mt-5">
          {data.categories?.map((item2, j) => {
            if (item2.trending) {
              return (
                <div key={j} className="mt-3">
                  <Accordion
                    style={{
                      width: "280px",
                      borderBottom: `1px solid ${themeColors.primary}`,
                      marginTop: "5px",
                    }}
                  >
                    <AccordionSummary
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor =
                          themeColors.primary;
                        e.currentTarget.style.color = "white";
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = "white";
                        e.currentTarget.style.color = "black";
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1a-content"
                      id="panel1a-header"
                    >
                      <Typography variant="undefined">
                        {item2.categoryName}
                      </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography variant="undefined">
                        <div className="d-flex flex-column flex-wrap">
                          <div className="d-flex">
                            <div>
                              {item2.subCategories?.map((item3, k) => {
                                return (
                                  <div key={k}>
                                    <input
                                      checked={filteredCourses?.includes(
                                        item3.subcategoryName
                                      )}
                                      onClick={(e) => {
                                        if (e.currentTarget.checked) {
                                          setFilteredCourses([
                                            ...filteredCourses,
                                            e.currentTarget.value,
                                          ]);
                                        } else {
                                          filteredCourses?.map((item) => {
                                            if (
                                              item === e.currentTarget.value
                                            ) {
                                              setFilteredCourses(
                                                filteredCourses.filter(
                                                  (item) =>
                                                    item !==
                                                    e.currentTarget.value
                                                )
                                              );
                                            }
                                          });
                                        }
                                      }}
                                      style={{
                                        accentColor: themeColors.primary,
                                      }}
                                      type="checkbox"
                                      id="cb"
                                      name={item3.subcategoryName}
                                      value={item3.subcategoryName}
                                    />
                                    <label className="mx-2">
                                      {item3.subcategoryName}
                                    </label>
                                  </div>
                                );
                              })}
                            </div>
                            <br />
                          </div>
                        </div>
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                </div>
              );
            }
          })}

          <div className="d-flex mt-4">
            <div className="m-2">
              <Button
                title="View More"
                onClick={() => setViewAllCoursesCategory(false)}
              />
            </div>
          </div>
        </div>
      ) : (
        <div className="mt-5">
          {data.categories?.map((item2, j) => {
            return (
              <div key={j} className="mt-3">
                <Accordion
                  style={{
                    width: "280px",
                    borderBottom: `1px solid ${themeColors.primary}`,
                    marginTop: "5px",
                  }}
                >
                  <AccordionSummary
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor =
                        themeColors.primary;
                      e.currentTarget.style.color = "white";
                      e.currentTarget.style.transition = "all 0.1s ease-in-out";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = "white";
                      e.currentTarget.style.color = "black";
                      e.currentTarget.style.transition = "all 0.1s ease-in-out";
                    }}
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography variant="undefined">
                      {item2.categoryName}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Typography variant="undefined">
                      <div className="d-flex flex-column flex-wrap">
                        <div className="d-flex">
                          {item2.categoryName === "Fees" ||
                          item2.categoryName === "Program Duration" ? (
                            <Box width={200}>
                              <span
                                style={{ width: "250px" }}
                                className="d-flex justify-content-between"
                              >
                                <span
                                  className={
                                    item2.categoryName === "Program Duration"
                                      ? "d-flex flex-row-reverse"
                                      : undefined
                                  }
                                >
                                  <span>
                                    {item2.categoryName === "Fees"
                                      ? currency.symbol
                                      : `month(s)`}
                                  </span>
                                  &nbsp;
                                  <span>
                                    {item2.categoryName === "Fees"
                                      ? valueFees[0]
                                      : valueProgramDuration[0]}
                                  </span>
                                </span>
                                <span
                                  className={
                                    item2.categoryName === "Program Duration"
                                      ? "d-flex flex-row-reverse"
                                      : undefined
                                  }
                                >
                                  <span>
                                    {item2.categoryName === "Fees"
                                      ? currency.symbol
                                      : `month(s)`}
                                  </span>
                                  &nbsp;
                                  <span>
                                    {item2.categoryName === "Fees"
                                      ? valueFees[1]
                                      : valueProgramDuration[1]}
                                  </span>
                                </span>
                              </span>
                              <Slider
                                onChange={
                                  item2.categoryName === "Fees"
                                    ? handleChangeFees
                                    : handleChangeDuration
                                }
                                value={
                                  item2.categoryName === "Fees"
                                    ? valueFees
                                    : valueProgramDuration
                                }
                                sx={{ color: themeColors.primary }}
                                min={0}
                                max={
                                  item2.categoryName === "Program Duration"
                                    ? 24
                                    : 500000
                                }
                              />
                            </Box>
                          ) : (
                            <div>
                              {item2.subCategories?.map((item3, k) => {
                                return (
                                  <div key={k}>
                                    <input
                                      checked={filteredCourses.includes(
                                        item3.subcategoryName
                                      )}
                                      onClick={(e) => {
                                        if (e.currentTarget.checked) {
                                          setFilteredCourses([
                                            ...filteredCourses,
                                            e.currentTarget.value,
                                          ]);
                                        } else {
                                          filteredCourses?.map((item) => {
                                            if (
                                              item === e.currentTarget.value
                                            ) {
                                              setFilteredCourses(
                                                filteredCourses.filter(
                                                  (item) =>
                                                    item !==
                                                    e.currentTarget.value
                                                )
                                              );
                                            }
                                          });
                                        }
                                      }}
                                      style={{
                                        accentColor: themeColors.primary,
                                      }}
                                      type="checkbox"
                                      id="cb"
                                      name={item3.subcategoryName}
                                      value={item3.subcategoryName}
                                    />
                                    <label className="mx-2">
                                      {item3.subcategoryName}
                                    </label>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                          <br />
                        </div>
                      </div>
                    </Typography>
                  </AccordionDetails>
                </Accordion>
              </div>
            );
          })}

          <div className="d-flex mt-4">
            <div className="m-2">
              <Button
                title="View Less"
                onClick={() => setViewAllCoursesCategory(true)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterCourses;
