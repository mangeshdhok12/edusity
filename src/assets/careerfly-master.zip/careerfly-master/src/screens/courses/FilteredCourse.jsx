import React, { useState } from "react";
import Box from "@mui/material/Box";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { data } from "./data";

const FilteredCourse = () => {
  const [industry, setIndustry] = useState("");
  const [jobType, setJobType] = useState("");
  const [programDuration, setProgramDuration] = useState("");
  const [natureOfJob, setNatureOfJob] = useState("");
  const [educationLevel, setEducationLevel] = useState("");
  const [educationStream, setEducationStream] = useState("");
  const [fees, setFees] = useState("");
  const [workingDays, setWorkingDays] = useState("");
  const [shift, setShift] = useState("");
  const [candidateStatus, setCandidateStatus] = useState("");

  const [jobs, setJobs] = useState([]);
  const [duration, setDuration] = useState([]);
  const [jobNature, setJobNature] = useState([]);
  const [education, setEducation] = useState([]);
  const [stream, setStream] = useState([]);
  const [fee, setFee] = useState([]);
  const [working, setWorking] = useState([]);
  const [shifting, setShifting] = useState([]);
  const [status, setStatus] = useState([]);

  const handleChange = (event) => {
    setAge(event.target.value);
  };

  return (
    <div>
      <Box sx={{ minWidth: 120 }}>
        <FormControl fullWidth>
          <InputLabel id="demo-simple-select-label">Age</InputLabel>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={Industry}
            label="Age"
            onChange={handleChange}
          >
            {data.map((item, index) => (
              <div key={index}>
                <MenuItem value={10}>{item.categoryName}</MenuItem>
              </div>
            ))}
          </Select>
        </FormControl>
      </Box>
    </div>
  );
};

export default FilteredCourse;
