import React, { useState } from "react";
import { Container } from "react-bootstrap";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import Banner from "./components/Banner";

const Live = ({ data }) => {
  const [date, setDate] = useState(new Date());
  return (
    <Container style={{ marginTop: "110px" }}>
      <Banner data={data} />
      <div
        style={{ padding: "0px 10%" }}
        className="d-flex flex-wrap justify-content-between"
      >
        <div className="py-3">
          <h2 className="font-weight-bold" style={{ color: "#273c75" }}>
            Next Class
          </h2>
        </div>
        <div className="py-3">
          <span style={{ fontSize: "20px" }}>
            Time :{" "}
            {new Date(
              data.panels[0]?.trainer.createAClass[1]?.dateAndTime[0]
            ).toLocaleTimeString("en-IN", {
              timeZone: "Asia/Kolkata",
              timeStyle: "short",
            })}
          </span>
          &nbsp;&nbsp;
          <NotificationsNoneIcon style={{ cursor: "pointer" }} />
        </div>
        <div style={{ width: "400px" }} className="py-3">
          <p
            style={{ textAlign: "center", fontSize: "28px", color: "#273c75" }}
          >
            Todays Topic
          </p>
          <p style={{ textAlign: "center" }}>
            {data.panels[0]?.trainer.createAClass[0]?.text3}
          </p>
        </div>
      </div>
      <div style={{ marginLeft: "5%", marginBottom:"20px",width: "300px" }}>
        <Calendar onChange={setDate} value={date} />
      </div>
    </Container>
  );
};

export default Live;
