import Image from "next/image";
import React from "react";

const Banner = ({ data }) => {
  return (
    <div>
      <h2 style={{ font: "bolder" }}>Class (Live)</h2>

      <div
        className="justify-content-center"
        style={{
          width: "100%",
          height: "315px",
          backgroundColor: "#2d3436",
          textAlign: "center",
          borderRadius: "15px",
        }}
      >
        <h3 style={{ color: "white", paddingTop: "100px" }}>
          {data.panels[0]?.trainer.createAClass[0]?.text1}
        </h3>
        <h5 style={{ color: "white" }}>{`( ${new Date(
          data.panels[0]?.trainer.createAClass[0]?.dateAndTime[0]
        ).toLocaleTimeString("en-IN", {
          timeZone: "Asia/Kolkata",
          timeStyle: "short",
        })} - ${new Date(
          data.panels[0]?.trainer.createAClass[0]?.dateAndTime[1]
        ).toLocaleTimeString("en-IN", {
          timeZone: "Asia/Kolkata",
          timeStyle: "short",
        })} )`}</h5>
        <button
          onClick={() =>
            window.open(data.panels[0]?.trainer.createAClass[0]?.link, "_blank")
          }
          className="btn btn-light px-5 my-3"
        >
          <b>JOIN NOW</b>
        </button>
      </div>
    </div>
  );
};

export default Banner;
