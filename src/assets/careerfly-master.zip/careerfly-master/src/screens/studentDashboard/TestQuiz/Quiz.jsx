import React, { useEffect, useState } from "react";
import { themeColors } from "../../../themes/colors";
import {
  doc,
  updateDoc,
  addDoc,
  collection,
  arrayUnion,
} from "firebase/firestore";
import { db } from "../../../lib/firebase";

import { SwiperSlide, Swiper } from "swiper/react";
import { Container } from "react-bootstrap";
import { Navigation, Pagination } from "swiper";
import { useRouter } from "next/router";
import { useMediaQuery } from "@mui/material";

const Quiz = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 768px)");

  const [res, setRes] = useState([]);
  const [title, setTitle] = useState("");
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [quiz, setQuiz] = useState("");
  const [map, setMap] = useState(false);

  useEffect(() => {
    const modules = localStorage.getItem("module");
    // console.log(modules,data)
    setTitle(modules);
    const course = localStorage.getItem("enrolled");
    const slug = localStorage.getItem("moduleno");
    const filter = data?.courses?.filter((item) => item?.slug === course);

    if (
      modules !== "Aptitude" &&
      modules !== "Computer" &&
      modules !== "Communication"
    ) {
      const data1 = filter[0]?.moduleTest.filter((item) => item.slug === slug);
      if (data1.length > 0) {
        setQuiz(data1[0]?.mcQs);
        setMap(true);
      }
      // console.log("quiz", data1[0]?.mcQs);
    }
    if (modules === "Aptitude") {
      // console.log(filter[0]?.aptitudeTest[0]?.mcQs)
      setQuiz(filter[0]?.aptitudeTest[0]?.mcQs);
      setMap(true);
    }

    if (modules === "Computer") {
      // console.log(filter[0]?.aptitudeTest[0]?.mcQs)
      setQuiz(filter[0]?.computerTest[0]?.mcQs);
      setMap(true);
    }
    if (modules === "Communication") {
      // console.log(filter[0]?.aptitudeTest[0]?.mcQs)
      setQuiz(filter[0]?.communicationTest[0]?.mcQs);
      setMap(true);
    }
  }, []);

  const router=useRouter()

  const submitResponse = async () => {
    const total = 0;
    if (res) {
      const filteredResponses = res.reduce((acc, curr) => {
        const index = acc.findIndex((item) => item.qns === curr.qns);
        if (index >= 0) {
          acc[index] = curr;
        } else {
          acc.push(curr);
        }
        return acc;
      }, []);

      filteredResponses.forEach((item) => {
        if (item.ans === item.res) total = total + 1;
      });
      console.log("total", total, res);
      setScore(total);
      setShowScore(true);

      try {
        const res = JSON.parse(localStorage.getItem("CareerFlyUser"));
        // console.log(res.user.uid, title, score, quiz.length);
        await updateDoc(doc(db, "users", res.user.uid), {
          test: arrayUnion({
            title: title,
            score: total,
            outOf: quiz.length,
            date: new Date().toDateString(),
            time: new Date().toLocaleTimeString(),
          }),
        });
      } catch (error) {
        console.log(error);
      }
    }
  };

  return (
    // <></>
    <Container>
      <div style={{ marginTop:isMobileScreen?"70px": "200px" }} className="mb-5">
        <div>
          {showScore ? (
           <>
            <div
              className="score-section"
              style={{ fontSize: "25px", fontWeight: "800" }}
            >
              You scored {score} out of {quiz?.length}
            </div>
            <button
                  className="px-3 p-2 mt-2"
                  style={{
                    backgroundColor: themeColors.primary,
                    color: "white",
                    borderRadius: "5px",
                    border: "none",
                  }}
                  onClick={() =>{router.push("/student-dashboard/overview")}}
                >
                  Back To DashBoard
                </button>
            </>
          ) : (
            <div>
              <h2 className="text-center mb-5">{title}</h2>
              <Swiper
                style={{
                  width: isMobileScreen?"95%%":"50%",
                  boxShadow: "1px 1px 7px 1px lightgray",
                  borderRadius: "14px",
                  padding: "50px 50px 50px 100px",
                }}
                spaceBetween={50}
                navigation
                pagination
                modules={[Navigation, Pagination]}
              >
                {map && (
                  <>
                    {quiz?.map((item2, j) => {
                      return (
                        <SwiperSlide>
                          <div>
                            <p>{`Q${j + 1}`}</p>
                            <p>{item2.question}</p>
                            <div className="d-flex flex-column">
                              {item2.options?.map((item3, k) => (
                                <div
                                  style={{
                                    width: "40px",
                                  }}
                                  className="d-flex align-items-center justify-content-between gap-2"
                                  key={k}
                                >
                                  <input
                                    onClick={(e) => {
                                      setRes([
                                        ...res,
                                        {
                                          qns: item2.question,
                                          ans: item2.correctAnswer,
                                          res: e.currentTarget.value,
                                        },
                                      ]);
                                    }}
                                    type="radio"
                                    name={j}
                                    value={item3}
                                  />
                                  <span>{item3}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </SwiperSlide>
                      );
                    })}
                  </>
                )}
              </Swiper>
              <div className="d-flex justify-content-center gap-5 mt-5">
                <button
                  className="px-3 p-2"
                  style={{
                    backgroundColor: themeColors.primary,
                    color: "white",
                    borderRadius: "5px",
                    border: "none",
                  }}
                  onClick={() => submitResponse()}
                >
                  Submit
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </Container>
  );
};

export default Quiz;
