import { Divider, useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { AiFillLinkedin } from "react-icons/ai";
import { themeColors } from "../../../../themes/colors";

const Alumni = ({ data, title = "Our Successful Alumni", searchText }) => {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");
  return (
    <div className="w-100">
      <h1 className="px-5 py-3 text-center">{title}</h1>
      <div className="d-flex justify-content-evenly flex-wrap">
        {data.placements[0]?.alumni
          ?.filter((item) => {
            if (searchText === undefined) {
              return item.text1;
            } else if (
              item.text1?.toLowerCase().includes(searchText?.toLowerCase())
            ) {
              return item.text1;
            }
          })
          ?.map((item, index) => {
            return (
              <div
                className="col-sm-12 p-3"
                key={index}
                style={{
                  width: "",
                  border: `1px solid ${themeColors.primary}`,
                  backgroundColor: themeColors.backgroundColor,
                  boxShadow: "1px 1px 7px 1px lightgray",
                  marginBottom: "20px",
                }}
              >
                <div
                  className={isMobileScreen?"d-flex justify-content-center":"d-flex justify-content-start column"}
                  style={{ flexWrap: isMobileScreen ? "wrap" : "" }}
                >
                  <div
                    className={isMobileScreen ? "" : "m-4"}
                    style={{
                      borderRadius: "12px",
                    }}
                  >
                    <Image
                      objectFit="cover"
                      placeholder="blur"
                      blurDataURL={item.image1?.url}
                      src={item.image1?.url}
                      height={300}
                      width={300}
                      alt="profiles"
                      style={{ marginTop: "-1px", borderRadius: "12px" }}
                    />
                    {item.link ? (
                      <div style={{ cursor: "pointer" }}>
                        <a
                          style={{ color: "black" }}
                          target="_blank"
                          href={item.link}
                          rel="noreferrer"
                        >
                          <AiFillLinkedin size={25} />
                        </a>
                      </div>
                    ) : undefined}
                  </div>
                  <div className={isMobileScreen?"d-flex w-100 justify-content-start align-items-center":"d-flex w-100 justify-content-between"}>
                    <div className="" style={{ width:isMobileScreen?"50%":"70%" }}>
                      <h3 className="mt-1 fw-bold" >{item.text1}</h3>
                      {!isMobileScreen ? (
                        <p className="p-2 " >{item.text3}</p>
                      ) : null}
                    </div>
                    <div
                      style={{ width: "2px", backgroundColor: "lightgray" }}
                    />
                    <div className={isMobileScreen?"d-flex m-2 gap-3 flex-row justify-content-center align-items-center":"d-flex m-auto gap-3 flex-column justify-content-center align-items-center"}>
                      <div className="d-flex">
                        <Image
                          objectFit="contain"
                          placeholder="blur"
                          blurDataURL={item.image2.url}
                          src={item.image2.url}
                          height={40}
                          width={100}
                          alt="careerfly"
                        />
                      </div>
                      <h4 style={{fontSize:isMobileScreen?"14px":""}}>{item.text2}</h4>
                    </div>
                  </div>
                </div>
                <div
                  style={{
                    display: isMobileScreen ? "block" : "none",
                  }}
                >
                  <p className="p-2" style={{fontSize:isMobileScreen?"13px":""}}>{item.text3}</p>
                </div>
              </div>
            );
          })}
      </div>
    </div>
  );
};

export default Alumni;
