import { useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import { Container } from "react-bootstrap";
import Alumni from "./components/Alumini";

const Placement = ({ data }) => {
  const [searchText, setSearchText] = useState();
  const isMobile = useMediaQuery("(max-width: 768px)");


  const searchOnChange = (e) => {
    setSearchText(e.currentTarget.value);
  };

  return (
    <Container style={{ marginTop: "110px" }}>
      <div>
        <div className={isMobile?"":"mx-3 px-5"}>
          <p style={{ fontSize: "34px" }}>Placement</p>
          <input
            onChange={searchOnChange}
            className={isMobile?"w-100":"w-75"}
            style={{ borderRadius: "10px", padding: "5px 12px" }}
            type="search"
            placeholder="Search or paste a link here"
          />
        </div>

        <div>
          <Alumni searchText={searchText} title="" data={data} />
        </div>
      </div>
    </Container>
  );
};

export default Placement;
