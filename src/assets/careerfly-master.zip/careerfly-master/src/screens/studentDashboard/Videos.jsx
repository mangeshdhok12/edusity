// import Image from "next/image";
import { useMediaQuery } from "@mui/material";
import React, { useState, useEffect } from "react";
import { Container } from "react-bootstrap";
import { Navigation, Autoplay, Pagination } from "swiper";
import { SwiperSlide, Swiper } from "swiper/react";
// import { dashboard } from "../../../public/assets/studentdashboardAssets/data/data";
// import { themeColors } from "../../themes/colors";
import { BsFillLockFill } from "react-icons/bs";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormHelperText from "@mui/material/FormHelperText";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { setLazyProp } from "next/dist/server/api-utils";

const Playlist = ({ playlist, title }) => {
  const isMobileScreen = useMediaQuery("(max-width: 990px)");
  return (
    <div className="">
      <div style={{ fontSize: "20px", fontWeight: "800" }}>{title}</div>
      <Swiper
        className="d-flex flex-wrap py-4"
        spaceBetween={1}
        slidesPerView={isMobileScreen?1:3}
        scrollbar={{ draggable: true }}
        pagination={{ clickable: true }}
        modules={[Navigation, Autoplay, Pagination]}
      >
        {playlist?.map((item, i) => {
          return (
            <SwiperSlide className="py-2" key={i}>
              {i === 0 ? (
                <iframe
                  width="380"
                  height="200"
                  src={item}
                  title="YouTube video player"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                ></iframe>
              ) : (
                <div
                  style={{
                    backgroundColor: "#a6a6a6",
                    width: "380px",
                    height: "200px",
                    position: "relative",
                    filter: "opacity(70%)",
                  }}
                  className="d-flex justify-content-center align-items-center"
                >
                  <div style={{ position: "absolute", zIndex: "100" }}>
                    <BsFillLockFill size={100} />
                  </div>
                </div>
              )}
            </SwiperSlide>
          );
        })}
      </Swiper>
    </div>
  );
};

const Videos = ({ data }) => {
  const [industry, setIndustry] = useState([]);
  const [type, setType] = useState([]);
  const [industryValue, setIndustryValue] = useState();
  const [typeValue, setTypeValue] = useState();
  const [fplaylist, setFPlaylist] = useState([]);
  const [mapData,setMapData]=useState()
  
  useEffect(() => {
    setIndustry(
      data[0]?.categories[0]?.subCategories.map((item) => {
        return item.subcategoryName;
      })
    );
    setType(
      data[0]?.categories[1]?.subCategories.map((item) => {
        return item.subcategoryName;
      })
    );
    if(industryValue && typeValue){
      filterFunction()
    }
  }, [industryValue,typeValue]);
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  const filterFunction = () => {
    console.log("in function",industryValue,typeValue)
    if(industryValue.length>0 && typeValue.length>0){
      let array = [];
      for (let i = 0; i < data.length; i++) {
         let first = 0;
         let second = 0;
         for (let x = 0; x < data[i].subCategories.length; x++) {
           if (data[i].subCategories[x].subcategoryName === industryValue) {
             first = 1;
           }
           if (data[i].subCategories[x].subcategoryName === typeValue){
             second = 1;
           }
           if (first === 1 && second === 1) {
            const slug = data[i];
            if (!array.includes(slug)) {
              array.push(slug);
             }
           }
         }
       }
       
       setFPlaylist(array);
    }

  };
  console.log(">", data, fplaylist,industryValue,typeValue);

  return (
    <Container>
      <h2
        style={{
          color: "#2e4765",
          fontSize: "32px",
          fontWeight: "bold",
          marginTop: "100px",
        }}
      >
        RECORDED VIDEOS
      </h2>
      <div className="d-flex flex-column gap-4">
        <div className="d-flex flex-column p-2">
          <div className="">
            <div
              style={{ backgroundColor: "#f5f5f5", width: "300px" }}
              className="btn py-2 my-2"
              type="button"
              id="dropdownMenuButton1"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              Enrolled Program
            </div>
            <div
              style={{
                backgroundColor: "#f5f5f5",
                width: "300px",
                marginLeft: isMobileScreen?null:"30px",
              }}
              className="btn py-2 my-2"
              type="button"
              id="dropdownMenuButton1"
              data-bs-toggle="dropdown"
              aria-expanded="false"
            >
              {data.filter((i)=>i.slug===localStorage.getItem("enrolled"))[0].title}
            </div>
          </div>
          <div className={isMobileScreen?"d-flex  justify-content-start gap-5":"d-flex flex-row justify-content-start gap-5"}>
            <Swiper
              className={isMobileScreen?"d-flex flex-column flex-wrap py-4":"d-flex flex-wrap py-4"}
              spaceBetween={1}
              slidesPerView={isMobileScreen?1:3}
              scrollbar={{ draggable: true }}
              pagination={{ clickable: true }}
              modules={[Navigation, Autoplay, Pagination]}
            >
              {data.filter((i)=>i.slug===localStorage.getItem("enrolled"))[0]?.playlist?.map((item, id) => {
                return (
                  <SwiperSlide className="py-2" key={id}>
                    <div>Class {id + 1}</div>
                    <iframe
                      key={id}
                      width="380"
                      height="200"
                      src={item}
                      title="YouTube video player"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  </SwiperSlide>
                );
              })}
            </Swiper>
          </div>
        </div>
        <div>
          <hr></hr>

          <div className="d-flex flex-row justify-content-center gap-5">
            <div style={{ width: "150px" }}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">Industry</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={industryValue}
                  label="Industry"
                  onChange={(e) => setIndustryValue(e.target.value)}
                >
                  {industry.map((item) => {
                    return <MenuItem value={item}>{item}</MenuItem>;
                  })}
                </Select>
              </FormControl>
            </div>
            <div style={{ width: "150px" }}>
              <FormControl fullWidth>
                <InputLabel id="demo-simple-select-label">Type</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={typeValue}
                  label="Type"
                  onChange={(e) => setTypeValue(e.target.value)}
                >
                  {type.map((item) => {
                    return <MenuItem value={item}>{item}</MenuItem>;
                  })}
                </Select>
              </FormControl>
            </div>
          </div>
          <div>
            
            {fplaylist.length>0?(
              <div className="">
              {fplaylist?.map((data, id) => {
                return (
                  <Playlist
                    key={id}
                    playlist={data.playlist}
                    title={data.title}
                  />
                );
              })}
            </div>
            ):(<div className="">
              {data?.map((data, id) => {
                return (
                  <Playlist
                    key={id}
                    playlist={data.playlist}
                    title={data.title}
                  />
                );
              })}
            </div>)}
          </div>
        </div>
      </div>
    </Container>
  );
};

export default Videos;
