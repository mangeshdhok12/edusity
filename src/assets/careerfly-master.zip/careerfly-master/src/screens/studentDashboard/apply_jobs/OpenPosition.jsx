import React from "react";
import { Container } from "react-bootstrap";
import JobCards from "./components/JobCards";

const OpenPosition = ({data}) => {
  return (
    <Container style={{ marginTop: "110px" }}>
      <div>
        <div className="d-flex justify-content-between align-items-center mx-5">
          <h2 style={{ color: "gray" }}>
            <b>OPEN POSITION</b>
          </h2>
        </div>
        <div className="d-flex flex-column">
          {data?.globalModels[0]?.openPositions?.map((item, i) => {
            return (
              <div className="mx-4 p-1" key={i}>
                <JobCards
                  title={item.text1}
                  image={item.image2.url}
                  company={item.text2}
                  country={item.text3}
                  link={item.link}
                  // time={item.time}
                />
              </div>
            );
          })}
        </div>
      </div>
    </Container>
  );
};

export default OpenPosition;
