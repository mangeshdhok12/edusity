import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React, { useState } from "react";

const JobCards = ({ title, image, company, country, time,link }) => {
  const isMobileScreen = useMediaQuery("(max-width: 990px)");

  return (
    <div
      className="d-flex flex-wrap p-3  w-100 justify-content-between align-items-center rounded-2xl"
      style={{ backgroundColor: "#f9f9f9", borderBottom: "2px solid gray" }}
    >
      <div className={isMobileScreen?"d-flex flex-column gap-4 justify-content-between  p-3 ":"d-flex gap-4 justify-content-between  p-3 "}>
        <div>
          <Image
            placeholder="blur"
            blurDataURL={image}
            alt="profile"
            src={image}
            width={150}
            height={150}
            objectFit="contain"
          />
        </div>
        <div>
          <strong className="font-black mt-3" style={{ fontWeight: "bolder", fontSize:"30px"}}>
            <b>{title}</b>
          </strong>
          <p style={{fontSize:"20px"}}>{company}</p>
          <p style={{fontSize:"20px"}}>{country}</p>
          <small>{time}</small>
        </div>
        <div>
        <a href={link} target="_blank" style={{textDecoration:"none", color:"Black"}}>
        <button
            style={{
              backgroundColor: "#AE4B45",
              border: "0",
              borderRadius: "5px",
              color: "white",
              fontWeight: "bold",
              // position:"absolute",
              left:"70%",
              Padding:"5px",
            }}
            className="px-4 py-2"
          >
            APPLY NOW
          </button>
        </a>
        </div>
      </div>
    </div>
  );
};
export default JobCards;
