import { useMediaQuery } from "@mui/material";
import React from "react";
import Progress from "./Progress";

const Topics = () => {
  const data = [
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
  ];
  const isMobile = useMediaQuery("(max-width: 768px)");

  return (
    <div>
      <h2 className="mt-3 mb-3">Topicwise performance</h2>
      <h4>Topic Vs Marks</h4>
      <div className="d-flex justify-content-center flex-wrap ">
        {data?.map((item, i) => {
          return (
            <div key={i}>
              <div
                style={{
                  boxShadow: "1px 1px 1px 5px lightgray",
                  padding: "10px",
                  margin: "20px",
                  width: "320px",
                }}
              >
                <h4>{item.topic}</h4>
                <Progress/><span>0%</span>
                <p>{item.points}</p>
                <button style={{paddingRight:"28px",paddingLeft:"28px",paddingTop:"5px",paddingBottom:"5px", backgroundColor:"lightgray", border:"0", borderRadius:"10px",color:"blue"}}>View</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Topics;
