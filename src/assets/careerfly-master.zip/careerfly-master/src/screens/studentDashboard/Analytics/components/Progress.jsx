import ProgressBar from 'react-bootstrap/ProgressBar';
function Progress({percentage}) {
    return <ProgressBar now="0" />;
}

export default Progress;