import { useMediaQuery } from "@mui/material";
import React, { Component } from "react";

import SemiCircleProgressBar from "react-progressbar-semicircle";
// import GaugeChart from 'react-gauge-chart'
// import ReactSpeedometer from "react-d3-speedometer"

const Test = () => {
  const data = [
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
    {
      topic: "Topic name",
      desc: "syllabus of test",
    },
  ];
  const isMobile = useMediaQuery("(max-width: 768px)");

  return (
    <div>
      <h2 className="mt-3 mb-3">Test History</h2>

      <div className="d-flex flex-wrap ">
        {data?.map((item, i) => {
          return (
            <div key={i}>
              <div
                style={{
                  padding: "10px",
                  margin: "20px",
                  width: isMobile?"320px":"500px",
                  background: "linear-gradient(#79AAFF,#4877D2)",
                }}
              >
                <div className="d-flex p-4">
                  <div>
                    <h4>{item.topic}</h4>
                    <p style={{ color: "white" }}>{item.desc}</p>
                  </div>

                  <div className="d-flex justify-content-end">
                    <div style={{ width: "90%", marginLeft: "20px" }}>
                    <SemiCircleProgressBar percentage={33} showPercentValue />
                    </div>
                  </div>
                </div>
                <button
                  style={{
                    paddingRight: "28px",
                    paddingLeft: "28px",
                    paddingTop: "5px",
                    paddingBottom: "5px",
                    backgroundColor: "black",
                    color: "white",
                    marginRight: "10px",
                    marginLeft: "10px",
                    border: "0",
                    borderRadius: "10px",
                  }}
                >
                  Retest
                </button>
                <button
                  style={{
                    paddingRight: "28px",
                    paddingLeft: "28px",
                    paddingTop: "6px",
                    paddingBottom: "6px",
                    backgroundColor: "lightgray",
                    border: "0",
                    borderRadius: "10px",
                    color: "blue",
                  }}
                >
                  View Result
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Test;
