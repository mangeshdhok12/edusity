import React from "react";
import Image from "next/image";
import { useMediaQuery } from "@mui/material";

const Improvement = () => {
  const isMobile = useMediaQuery("(max-width: 768px)");

  return (
    <div className="d-flex flex-wrap" style={{ marginTop: "30px" }}>
      <h2>
        <b>Self Improvement Index</b>
      </h2>
      <div className="d-flex justify-content-evenly align-items-center gap-3">
      <div>
        <h3 style={{fontSize:isMobile?"14px":""}}>
          You have scored x% more/less than the previous test keep learning and
          gaining knowledge
        </h3>
      </div>
      <div>

        <Image
          src="/assets/studentdashboardAssets/trainer1.png"
          alt="img"
          width={250}
          height={250}
        />
      </div>
      </div>
    </div>
  );
};

export default Improvement;
