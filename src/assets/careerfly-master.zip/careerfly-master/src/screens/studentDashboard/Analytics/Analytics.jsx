import React, { useState } from "react";
import Class from "./components/Class";
import Improvement from "./components/Improvement";
import Marks from "./components/Marks";
import Pie from "./components/Pie";
import Topics from "./components/Topics";
import Test from "./components/Test";
import { Container } from "react-bootstrap";
import { useMediaQuery } from "@mui/material";

const Analytics = () => {
  const [filter, setFilter] = useState("");
  const isMobileScreen = useMediaQuery("(max-width: 990px)");



  const data = [
    { option: "Marks vs Test date", string: <Marks />, match: "Marks" },
    { option: "Topicwise Performance", string: <Topics />, match: "Topics" },
    { option: "Class Performance", string: <Class />, match: "Class" },
    { option: "Test History", string: <Test />, match: "Test" },
    {
      option: "Self improvement index",
      string: <Improvement />,
      match: "Improvement",
    },
  ];
  return (
    <Container>
      <div>
        <div style={{ marginTop: "100px" }}>
          <div>
            <h2>
              <b>Analytics</b>
            </h2>
            <div className={!isMobileScreen?"d-flex w-100  flex-row justify-content-between":"d-flex flex-column"}>
              <div>
                {data?.map((item, i) => {
                  return (
                    <div key={i} onClick={() => setFilter(item.match)}>
                      <input
                        defaultChecked={item.match === "Marks" ? true : false}
                        type="radio"
                        value={item.match}
                        id={item.match}
                        name="option"
                        className="mx-2"
                      />
                      <span className="">{item.option}</span>
                    </div>
                  );
                })}
              </div>
              <div className=" ">
                <div 
                // style={{ position: "absolute", top: isMobileScreen?"200px":"10%", right: isMobileScreen?"":"10%" }}
                >
                  <Pie />
                </div>
              </div>
            </div>
          </div>
        </div>
        {filter ? (
          <div>
            {data?.map((v, i) => {
              return <>{v.match === filter && <div>{v.string}</div>}</>;
            })}
          </div>
        ) : (
          <Marks />
        )}
      </div>
    </Container>
  );
};

export default Analytics;
