import React from "react";
// import PieChart from "react-pie-graph-chart";
import PieChart from "react-pie-graph-chart";

const Pie = () => {
  const Data = [
   
    {
      type: "Correct Answer",
      value: 75,
      color: "#86F6AD"
    },
    {
      type: "Incorrect Answer",
      value: 25,
      color: "#F6A086"
    }
  ];
  return <PieChart data={Data} />

};

export default Pie;
