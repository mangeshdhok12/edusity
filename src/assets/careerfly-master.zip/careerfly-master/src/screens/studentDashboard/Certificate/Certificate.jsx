import Image from "next/image";
import React from "react";
import { Container } from "react-bootstrap";
import {HiDownload} from "react-icons/hi"
import {SlSocialInstagram} from "react-icons/sl"
import {BsFacebook} from "react-icons/bs"
import {AiFillTwitterCircle} from "react-icons/ai"
import { useMediaQuery } from "@mui/material";


const Certificate = () => {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");
  const data=[{image:"/google.png",cName:"Google",loc:"India"},
  {image:"/amazon.png",cName:"Amazon",loc:"India"}]
  
  return (
    <Container style={{marginTop:isMobileScreen?"60px":"100px"}}>
    <div className="d-flex justify-content-between align-items-center ">
          <h2
            style={{ color: "#2e4765", fontSize: "36px", fontWeight: "bold",marginLeft:isMobileScreen?"":"10px" }}
          >
            Certificate
          </h2>
        </div>
    <div className={isMobileScreen?"w-100 d-flex flex-column justify-content-start gap-4 align-items-start":"w-100 d-flex flex-row justify-content-start gap-4 align-items-start"}>
      <div>
        <Image src="/certificate.jpg" width={600} height={400} alt="certificate"></Image>
      </div>
      <div className="d-flex flex-row" style={{height:"400px"}}>
        <div style={{borderLeft: "2px solid black"}} className="mx-3"></div>
        <div className="d-flex flex-column p-2 justify-content-start align-items-start">
          <div className="p-3 px-5 w-100 text-center" style={{backgroundColor:"#f7f7f7"}}>Download Certificate <HiDownload size={20}/></div>
          <div className="p-3 px-5 mt-5 w-100 text-center" style={{backgroundColor:"#f7f7f7"}}>Share Achivement</div>
          <div className="d-flex w-100 flex-row justify-content-center align-items-center p-3  gap-3" style={{}}>
            <div><SlSocialInstagram size={30}/></div>
            <div><BsFacebook  size={30}/></div>
            <div><AiFillTwitterCircle size={35}/></div>
          </div>
          <div className="p-3 px-5  w-100 text-center" style={{backgroundColor:"#f7f7f7"}}>XXXXXXXXX</div>
          <div className="p-3 px-5  w-100 text-center">Certificate Id</div>
        </div>
      </div>
    </div>
    <div className="d-flex flex-column p-2" style={{width:isMobileScreen?"300px":"600px"}}>
      <p className="text-center my-3" style={{ color: "#2e4765", fontSize: "28px", fontWeight: "bold" }}>Approved by
      </p>
    
      <div className="d-flex flex-row Justify-content-start align-items-start gap-5">
        {data.map((item,id)=>{
          return (
            <div
              key={id}
              className="d-flex flex-column Justify-content-start align-items-center"
            >
              <div className="p-3 d-flex justify-content-center align-items-center " style={{border:"1px solid #808080",borderRadius:"2px" }}>
                <Image
                  object-fit="contain"
                  src={item.image}
                  width={130}
                  height={30}
                  alt={item.cName}
                />
              </div>
              <div className="text-center">{item.cName}</div>
              <div className="text-center">{item.loc}</div>
            </div>
          );
        })}
      </div>

    </div>
  </Container>

  );
};

export default Certificate;
