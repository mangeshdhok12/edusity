import { useMediaQuery } from "@material-ui/core";
import Image from "next/image";
import React from "react";
import { Container } from "react-bootstrap";

const HiringPartners = ({ data }) => {

  return (
    <Container>
      <div className="d-flex flex-column gap-5 px-3">
        <p style={{ fontSize: "34px", fontWeight: "bold" }}>Hiring Partners</p>
        <div className="d-flex justify-content-center">
          <Image
            src="/assets/studentdashboardAssets/map.svg"
            alt="Partners"
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/map.svg"
            width={1100}
            height={400}
            objectFit="contain"
          />
        </div>
        <div className="d-flex flex-wrap gap-2">
          {data.placements[0]?.partners?.map((items, i) => {
            return (
              <div key={i} className="col-1">
                <Image
                  src={items.url}
                  alt="Partners"
                  placeholder="blur"
                  blurDataURL={items.url}
                  width={190}
                  height={100}
                  objectFit="contain"
                />
              </div>
            );
          })}
        </div>
      </div>
    </Container>
  );
};

export default HiringPartners;
