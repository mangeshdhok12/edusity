import Image from "next/image";
import React, { useState } from "react";

const GlobalCards = ({ title, image, desc, time }) => {
  return (
    <div
      className="d-flex flex-wrap p-3 my-4 w-100 justify-content-between align-items-center"
      // style={{ backgroundColor: "#f9f9f9" }}
    >
      <div className="d-flex gap-4 justify-content-between shadow-lg shadow-gray-500 p-3 rounded-2xl" style={{borderRadius:"15px"}}>
        <div>
          <small style={{marginBottom:"20px"}}>The Global Recruiter</small>
          <h5 className="text-primary mt-3">{title}</h5>
          <p className="mt-2">
            {desc}
          </p>
          <small>{time}</small>
        </div>
        <div style={{borderRadius:"15px"}}>
          <Image
          style={{borderRadius:"15px"}}
            placeholder="blur"
            blurDataURL={image}
            alt="profile"
            src={image}
            width={200}
            height={200}
            objectFit="cover"
            className="rounded-2xl"
          />
        </div>
      </div>
    </div>
  );
};
export default GlobalCards;
