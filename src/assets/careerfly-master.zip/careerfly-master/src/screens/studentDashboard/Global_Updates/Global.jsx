import { useMediaQuery } from "@material-ui/core";
import Link from "next/link";
import React from "react";
import { Container } from "react-bootstrap";
import GlobalCards from "./components/GlobalCards";

const Global = ({data}) => {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");

  return (
    <Container style={{ marginTop: "110px" }}>
      <div>
        <div className="d-flex justify-content-between align-items-center">
          <h2
            style={{ color: "#2e4765", fontSize:isMobileScreen?"30px": "36px", fontWeight: "bold",marginLeft:isMobileScreen?"10px":"10px" }}
          >
            GLOBAL UPDATES
          </h2>
        </div>
        <div className="d-flex flex-column">
          {data?.globalModels[0]?.globalUpdates.map((item, i) => {
            return (
              <a href={item?.link} target="_blank" style={{textDecoration:"none", color:"Black"}}>
              <div className={isMobileScreen?"":"mx-4 p-1"} key={i}>
                <GlobalCards
                  title={item.text2}
                  image={item.image2?.url}
                  desc={item.text3}
                  // time={item.time}
                />
              </div>
              </a>
            );
          })}
        </div>
      </div>
    </Container>
  );
};

export default Global;
