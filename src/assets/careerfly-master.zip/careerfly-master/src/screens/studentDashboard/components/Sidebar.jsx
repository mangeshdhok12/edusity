import Image from "next/image";
import React, { useEffect, useState } from "react";
import { signOut } from "firebase/auth";
import { BiExit } from "react-icons/bi";
import LockIcon from "@mui/icons-material/Lock";
import { useRouter } from "next/router";
import { auth } from "../../../lib/firebase";
import { useMediaQuery } from "@mui/material";
import { useStateContext } from "../../../context/StateContext";

const items = [
  {
    title: "Overview",
    img: "/assets/studentdashboardAssets/overview.svg",
    url: "overview",
  },
  {
    title: "Recorded Videos",
    img: "/assets/studentdashboardAssets/record.svg",
    url: "recorded-videos",
    icon: <LockIcon />,
  },
  {
    title: "Resume",
    img: "/assets/studentdashboardAssets/resume.svg",
    url: "resume",
    icon: " ",
  },
  {
    title: "Certificate",
    img: "/assets/studentdashboardAssets/certificate.svg",
    url: "certificate",
    icon: <LockIcon />,
  },
  {
    title: "Test",
    img: "/assets/studentdashboardAssets/test-perfomance.png",
    url: "testPerformance",
    icon: <LockIcon />,
  },
  {
    title: "Our Trainers",
    img: "/assets/studentdashboardAssets/trainers.svg",
    url: "our-trainers",
    icon: " ",
  },
  {
    title: "Live",
    img: "/assets/studentdashboardAssets/live.svg",
    url: "live",
    icon: <LockIcon />,
  },
  {
    title: "Hiring Partners",
    img: "/assets/studentdashboardAssets/partner.svg",
    url: "hiring-partners",
    icon: " ",
  },
  {
    title: "Open Position",
    img: "/assets/studentdashboardAssets/apply.svg",
    url: "open-position",
    icon: " ",
  },
  {
    title: "Global Updates",
    img: "/assets/studentdashboardAssets/global.svg",
    url: "global-updates",
  },
  {
    title: "Placement",
    img: "/assets/studentdashboardAssets/placement.svg",
    url: "placement",
    icon: " ",
  },
  {
    title: "Analytics",
    img: "/assets/studentdashboardAssets/analytics.svg",
    url: "analytics",
    icon: <LockIcon />,
  },
];

const SidebarItem = ({ title, img, icon }) => {
  const [hover, setHover] = useState(false);
  return (
    <div
      className="d-flex py-2 px-3 justify-content-between align-items-center"
      style={{
        width: "100%",
        cursor: "pointer",
        borderRadius: "18px",
        color: hover ? "#508FF4" : "",
        backgroundColor: hover ? "#EAF2FF" : "",
        whiteSpace: "nowrap",
      }}
      onMouseEnter={() => {
        setHover(!hover);
      }}
      onMouseLeave={() => {
        setHover(!hover);
      }}
    >
      <div className="d-flex gap-4 align-items-center">
        <div className="d-flex align-items-center justify-content-center">
          <Image
            style={{
              filter: hover
                ? "invert(45%) sepia(92%) saturate(745%) hue-rotate(193deg) brightness(98%) contrast(95%)"
                : "",
            }}
            alt={title}
            src={img}
            width={20}
            height={20}
            objectFit="contain"
          />
        </div>
        <div className="w-100">{title}</div>
      </div>
      <div style={{ marginLeft: "30px" }}>{icon}</div>
    </div>
  );
};

const handleLogOut = () => {
  window.location.href = "/";
  signOut(auth);
  localStorage.removeItem("CareerFlyUser");
};

const Sidebar = ({ handleClick}) => {
  const isMobileScreen = useMediaQuery("(max-width: 990px)");
  
  const { setStudentEnrolledData , setToggle} = useStateContext();

  const res = JSON.parse(localStorage.getItem("CareerFlyUser"));
  const username = res.user.displayName;
  const userimage = res.user.photoURL;
  const router = useRouter();

  return (

    <div style={{ marginTop: "110px" }}>
      <div className="d-flex flex-column px-4 py-2">
        <div className="d-flex align-items-center gap-3">
          <div className="" style={{ borderRadius: "50%" }}>
            <Image
              style={{ borderRadius: "50%" }}
              alt="profile"
              src={userimage}
              width={50}
              height={50}
              objectFit="contain"
            />
          </div>
          <span
            style={{
              fontWeight: "bold",
              fontSize: "15px",
              whiteSpace: "no-wrap",
              width: "200px",
            }}
          >
            {username}
          </span>
        </div>

        <div className="d-flex flex-column gap-2 my-5">
          {items?.map((items, i) => {
            return (
              <div
                key={i}
                onClick={() => {
                  router.push(`/student-dashboard/${items.url}`);
                  setToggle(false)
                }}
              >
                <SidebarItem
                  key={i}
                  title={items.title}
                  img={items.img}
                  icon={items.icon}
                  handleClick={handleClick}
                />
              </div>
            );
          })}
        </div>

        <div
          style={{ cursor: "pointer" }}
          onClick={() => handleLogOut()}
          className="d-flex align-items-center gap-3 my-3"
        >
          <div style={{ transform: "rotate(180deg)" }}>
            <BiExit size={35} />
          </div>
          <div>Logout</div>
        </div>
      </div>
    </div>
  );
};
export default Sidebar;
