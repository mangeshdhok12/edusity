import React from "react";

const ProgressBar = ({ percent, target, width, bg }) => {
  return (
    <div
      className="row progressBar m-0 p-0"
      style={{
        height: "60px",
        width: "250px",
        margin: "8px 2px !important",
        position: "relative",
        display: "inline-flex",
        background: "#1B222A !important",
        borderRadius: "4.86207px",
        padding: "2px 12px !important",
      }}
    >
      <div>
        <span
          className="d-flex  m-0 p-0"
          style={{ position: "absolute", top: "5px", left: "8px" }}
        >
          {percent}
        </span>
        <span className="targetValue m-0 p-0">{target}</span>
      </div>
      <div
        className="progress m-0 p-0"
        style={{
          position: "absolute",
          display: "flex",
          top: "45px",
          right: "8px",
          left: "8px",
          width: "234px",
          backgroundColor: "#000",
          alignItems: "center",
          textAlign: "center",
          borderRadius: "4px",
          height: "8px",
        }}
      ></div>
      <div
        style={{ width: `${width}%`, backgroundColor: `${bg}` }}
        className="progressIn"
      ></div>
    </div>
  );
};
export default ProgressBar;
