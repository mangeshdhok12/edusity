import React from "react";
import { PieChart, Pie, Cell } from "recharts";
import { themeColors } from "../../../../themes/colors";

const COLORS = [themeColors.studentDashboardBg, themeColors.backgroundColor];

const renderCustomizedLabel = ({
  cx,
  cy,
  midAngle,
  innerRadius,
  outerRadius,
  percent,
  index,
}) => {
  const RADIAN = Math.PI / 180;
  const radius = innerRadius + (outerRadius - innerRadius) * 0.25;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius* Math.sin(-midAngle * RADIAN);
  console.log(cx,cy)

  return (
    <text
      x={x}
      y={y}
      fill={y > cx ? "Transparent" : "White"}
      textAnchor={x > cx ? "start" : "end"}
      dominantBaseline="central"
    >
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};

const PieChartExample = ({ width, height, cx, cy, radius,data}) => {
  return (
    <PieChart width={width} height={height}>
      <Pie
        data={data}
        cx={cx}
        cy={cy}
        labelLine={false}
        // label={renderCustomizedLabel}
        outerRadius={radius}
        fill="#8884d8"
      >
        {data?.map((entry, index) => (
          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
        ))}
      </Pie>
    </PieChart>
  );
};

export default PieChartExample;
