import React, { useState, useEffect } from "react";
import PieCharts from "./PieCharts";
import { themeColors } from "../../../../themes/colors";
import { useStateContext } from "../../../../context/StateContext";
import { useRouter } from "next/router";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../../../../lib/firebase";

const Score = ({ legendNone, test }) => {
  const router = useRouter();
  const { setCurrentModuleTest, studentEnrolledData } = useStateContext();
  const res = JSON.parse(localStorage.getItem("CareerFlyUser"));
  const [percent, setPercent] = useState();
  const [aptPer, setAptPer] = useState();
  const [compPer, setCompPer] = useState();
  const [commPer, setCommPer] = useState();
  const [percentage, setPercentage] = useState([]);

  // console.log(studentEnrolledData, ">");
  let Module = ["Aptitude", "Computer", "Communication"];
  let array = [0, 0, 0];

  const Test = test?.courses?.filter(
    (c) => c.slug === localStorage.getItem("enrolled")
  );
  const height = 150;
  const width = 150;
  const value = [
    { name: "70", value: 0, fill: themeColors.white },
    { name: "30", value: 100, fill: themeColors.black },
  ];

  useEffect(() => {
    const calculatePercentile = async () => {
      const docRef = doc(db, "users", res.user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data().test;
        if (Module.length > 0) {
          // console.log("....in outer loop ");
          for (let y = 0; y < Module.length; y++) {
            const filter = data.filter((m) => m.title === Module[y]);
            let score = 0;
            let total = 0;
            let percent = 0;
            for (let x = 0; x < filter.length; x++) {
              score = score + filter[x].score;
              total = total + filter[x].outOf;
            }
            percent = (score / total) * 100;
            array[y] = percent;
          }
          console.log(array);
          setPercentage(array);
          setPercent([
            {
              name: "hi",
              value: parseInt(array[0] + array[2] + array[1]),
              fill: themeColors.white,
            },
            {
              name: "hello",
              value: parseInt(300 - (array[2] + array[0] + array[1])),
              fill: themeColors.black,
            },
          ]);
          setAptPer([
            { name: "hi", value: parseInt(array[0]), fill: themeColors.white },
            {
              name: "hello",
              value: parseInt(100 - array[0]),
              fill: themeColors.black,
            },
          ]);
          setCompPer([
            { name: "hi", value: parseInt(array[1]), fill: themeColors.white },
            {
              name: "hello",
              value: parseInt(100 - array[1]),
              fill: themeColors.black,
            },
          ]);
          setCommPer([
            { name: "hi", value: parseInt(array[2]), fill: themeColors.white },
            {
              name: "hello",
              value: parseInt(100 - array[2]),
              fill: themeColors.black,
            },
          ]);
        }
        // console.log(studentEnrolledData);
      } else {
        console.log("No such document!");
      }
    };
    calculatePercentile();
    // console.log("percent", percent,aptPer,commPer,commPer);
    // console.log("val", value);
  }, []);

  return (
    <div className="d-flex flex-column gap-3">
      <div className="d-flex justify-content-end">
        {/* <div style={{fontSize:"34px"}}>{title} </div> */}
        {!legendNone && (
          <div className="d-flex flex-column">
            <div className="d-flex gap-2 align-items-center">
              <div
                style={{
                  width: "35px",
                  height: "20px",
                  backgroundColor: themeColors.primary,
                }}
              ></div>
              <span> Correct</span>
            </div>
            <div className="d-flex gap-2 align-items-center">
              <div
                style={{
                  width: "35px",
                  height: "20px",
                  backgroundColor: themeColors.gray,
                }}
              ></div>
              <span> Incorrect</span>
            </div>
          </div>
        )}
      </div>
      <div className="d-flex gap-2 justify-content-between align-items-end ">
        {array[0]+array[1]+array[2] === 0 ? (
          <div className="d-flex flex-column justify-content-center align-items-center shadow-lg shadow-gray-500 m-0 p-0 pb-2">
            <PieCharts data={value} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(
                ((array[0] + array[1] + array[2]) / 300) * 100
              ).toFixed(2)}
              %
            </p>

            <p className="w-75 text-center">{Test[0]?.title}</p>
          </div>
        ) : (
          <div className="d-flex flex-column justify-content-center align-items-center shadow-lg shadow-gray-500 m-0 p-0 pb-2">
            <PieCharts data={percent} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(
                ((array[0] + array[1] + array[2]) / 300) * 100
              ).toFixed(2)}
              %
            </p>

            <p className="w-75 text-center">{Test[0]?.title}</p>
          </div>
        )}

        <div className="d-flex flex-wrap shadow-lg shadow-gray-500">
          {array[0]===0 ? (<div className="d-flex flex-column justify-content-center align-items-center shadow-lg shadow-gray-500 m-0 p-0 pb-2">
            <PieCharts data={value} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(
                ((array[0] + array[1] + array[2]) / 300) * 100
              ).toFixed(2)}
              %
            </p>

            <p className="w-75 text-center">{Test[0]?.aptitudeTest[0]?.slug}</p>
          </div>):(<div
            className="d-flex flex-column justify-content-center align-items-center m-0 p-0 pb-2"
            onClick={() => {
              localStorage.setItem("moduleno", Test[0]?.aptitudeTest[0]?.slug);
              localStorage.setItem("module", Test[0]?.aptitudeTest[0]?.name);
              localStorage.setItem("enrolled", studentEnrolledData?.text2);
              router.push(
                `/student-dashboard/test/aptitude/${Test[0]?.aptitudeTest[0]?.slug}`
              );
            }}
          >
            <PieCharts data={aptPer} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(array[0]).toFixed(2)}%
            </p>

            <div>{Test[0]?.aptitudeTest[0].name}</div>
          </div>)}

          {array[1]===0?(<div className="d-flex flex-column justify-content-center align-items-center shadow-lg shadow-gray-500 m-0 p-0 pb-2">
            <PieCharts data={value} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(
                ((array[0] + array[1] + array[2]) / 300) * 100
              ).toFixed(2)}
              %
            </p>

            <p className="w-75 text-center">{Test[0]?.computerTest[0]?.slug}</p>
          </div>):(<div
            className="d-flex flex-column justify-content-center align-items-center m-0 p-0 pb-2"
            onClick={() => {
              localStorage.setItem("moduleno", Test[0]?.computerTest[0]?.slug);
              localStorage.setItem("module", Test[0]?.computerTest[0]?.name);
              localStorage.setItem("enrolled", studentEnrolledData?.text2);
              router.push(
                `/student-dashboard/test/computer/${Test[0]?.computerTest[0]?.slug}`
              );
            }}
          >
            <PieCharts data={compPer} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(array[1]).toFixed(2)}%
            </p>

            <div>{Test[0]?.computerTest[0]?.name}</div>
          </div>)}

          {array[2]===0?(<div className="d-flex flex-column justify-content-center align-items-center shadow-lg shadow-gray-500 m-0 p-0 pb-2">
            <PieCharts data={value} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(
                ((array[0] + array[1] + array[2]) / 300) * 100
              ).toFixed(2)}
              %
            </p>

            <p className="w-75 text-center">{Test[0]?.communicationTest[0]?.slug}</p>
          </div>):(<div
            className="d-flex flex-column justify-content-center align-items-center m-0 p-0 pb-2"
            onClick={() => {
              localStorage.setItem(
                "moduleno",
                Test[0]?.communicationTest[0]?.slug
              );
              localStorage.setItem(
                "module",
                Test[0]?.communicationTest[0]?.name
              );
              localStorage.setItem("enrolled", studentEnrolledData?.text2);
              router.push(
                `/student-dashboard/test/communication/${Test[0]?.communicationTest[0]?.slug}`
              );
            }}
          >
            <PieCharts data={commPer} width={width} height={height} />
            <p className="w-75 text-center">
              {parseFloat(array[2]).toFixed(2)}%
            </p>

            <div>{Test[0]?.communicationTest[0]?.name}</div>
          </div>)}
        </div>
      </div>
    </div>
  );
};

export default Score;
