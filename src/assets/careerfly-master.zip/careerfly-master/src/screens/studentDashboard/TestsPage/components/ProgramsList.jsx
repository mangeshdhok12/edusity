import { useMediaQuery } from "@mui/material";
import { doc, getDoc } from "firebase/firestore";
import { useRouter } from "next/router";
import React, { useState, useEffect } from "react";
import ProgressBar from "react-bootstrap/ProgressBar";
import { useStateContext } from "../../../../context/StateContext";
import { db } from "../../../../lib/firebase";
import { themeColors } from "../../../../themes/colors";
// import ProgressBar from './ProgressBar';

const ProgramList = ({ props }) => {
  const isMobileScreen = useMediaQuery("(max-width: 767px)")
  const { setCurrentModuleTest, studentEnrolledData } = useStateContext();
  const res = JSON.parse(localStorage.getItem("CareerFlyUser"));
  const [percent, setPercent] = useState();
  const router = useRouter();
  let Module = [];
  let array = [];
  useEffect(() => {
    const calculatePercentile = async () => {
      const docRef = doc(db, "users", res.user.uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data().test;
        // console.log("....in outer loop ");

        if (Module.length > 0) {
          // console.log("....in inner loop ");
          for (let y = 0; y < Module.length; y++) {
            const filter = data.filter((m) => m.title === Module[y]);
            let score = 0;
            let total = 0;
            let percent = 0;
            for (let x = 0; x < filter.length; x++) {
              score = score + filter[x].score;
              total = total + filter[x].outOf;
            }
            percent = (score / total) * 100;
            array[y] = percent;
          }
          // console.log("check", array);
          setPercent(array);
        }
      } else {
        console.log("No such document!");
      }
    };
    calculatePercentile();
  }, []);

  return (
    <div className="d-flex flex-column gap-5 mt-5" style={{marginBottom:isMobileScreen?"20px":"5px"}}>
      <div>List of Program Modules</div>
      <div className="">
        {props.data.courses
          .filter((c) => c.slug === localStorage.getItem("enrolled"))
          ?.map((item, i) => {
            return (
              <div className="d-flex gap-5 flex-wrap">
                {item.moduleTest?.map((item2, j) => {
                  Module.push(item2.name);
                  return (
                    <div
                      key={j}
                      className="d-flex flex-column gap-3 px-4 py-3"
                      style={{
                        backgroundColor: themeColors.backgroundColor,
                        borderRadius: "15px",
                        cursor: "pointer",
                        width: "300px",
                      }}
                      onClick={() => {
                        setCurrentModuleTest(item2.slug);

                        localStorage.setItem("moduleno", item2.slug);
                        localStorage.setItem("module", item2.name);
                        localStorage.setItem(
                          "enrolled",
                          studentEnrolledData?.text2
                        );
                        router.push(
                          `/student-dashboard/test/moduleTest/${item2.slug}`
                        );
                      }}
                    >
                      <div className="d-flex justify-content-between px-1">
                      <div>{item2.name}</div>
                      {percent && <div>{parseFloat(percent[j]).toFixed(2)}%</div>}

                      </div>
                      {percent && (
                        <div>
                          <ProgressBar now={percent[j]} />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
      </div>
    </div>
  );
};

export default ProgramList;
