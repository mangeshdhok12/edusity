import React, { useEffect } from "react";
import { Container } from "react-bootstrap";
import ProgramList from "./components/ProgramsList";
import Score from "./components/Score";

const Test = ({ data }) => {
  return (
    <Container>
      <div style={{ marginTop: "115px" }}>
        <p style={{ fontSize: "36px" }}>
          <b>Tests - </b>Score
        </p>
        <div>
          <Score test={data} title={"SCORE"} />
        </div>
        <div>
          <ProgramList props={{ data }} />
        </div>
      </div>
    </Container>
  );
};
export default Test;
