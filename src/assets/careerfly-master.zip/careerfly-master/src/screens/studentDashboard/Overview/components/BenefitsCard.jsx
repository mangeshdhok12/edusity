import React from "react";
import Image from "next/image";
import { themeColors } from "../../../../themes/colors";

export const BenefitsCard = ({ title, img }) => {
  return (
    <div
      style={{
        width: "210px",
        height: "75px",
        borderRadius: "10px",
        backgroundColor: themeColors.studentDashboardBg,
        position: "relative",
        display: "flex",
        justifyContent: "start",
        alignItems: "center",
      }}
    >
      <div
        style={{
          height: "75px",
          position: "absolute",
          right: 0,
        }}
      >
        <Image
          objectPosition="80px -35px"
          src={img}
          width={140}
          height={75}
          placeholder="blur"
          objectFit="cover"
          blurDataURL={img}
          alt={title}
          style={{ borderRadius: "10px" }} />
      </div>
      <p
        className="px-4"
        style={{
          fontSize: "18px",
          fontWeight: "bold",
          color: "white",
          margin: 0,
        }}
      >
        {title}
      </p>
    </div>
  );
};
