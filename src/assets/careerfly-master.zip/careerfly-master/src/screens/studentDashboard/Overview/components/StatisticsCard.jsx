import React from "react";
import ProgressBar from 'react-customizable-progressbar';

export const StatisticsCard = ({ title, bg, color, percent }) => {
  return (
    <div className="d-flex justify-content-between gap-4 p-3" style={{ backgroundColor: bg, color: color, borderRadius: "10px" }}>
      <div className="d-flex flex-column justify-content-center align-items-start gap-1">
        <p className="m-0 " style={{ fontSize: "18px", fontWeight: "bold" }}> {title} </p>
        <p className="m-0 " style={{ fontSize: "13px", fontWeight: "500" }}> {percent}% achieved </p>
      </div>
      <div className="my-3" style={{ width: "1px", backgroundColor: "#fff" }}></div>
      <ProgressBar className="" strokeWidth={8} trackStrokeWidth={8} strokeColor={"#f9896b"} progress={percent} radius={30}>
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
          }}>
          {percent}
        </div>
      </ProgressBar>
    </div>
  );
};
