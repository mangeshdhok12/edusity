import React from "react";
import LecturCard from "./components/LectureCard";
import StudentDetails from "./components/StudentDetails";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper";
import Progressbar from "react-customizable-progressbar";
import OverviewAreaChart from "./components/OverviewAreaChart";
import Image from "next/image";
import Score from "../TestsPage/components/Score";
import { themeColors } from "../../../themes/colors";
import { Container } from "react-bootstrap";
import Carousel from "react-multi-carousel";
import Marquee from "react-fast-marquee";
import { LineChart } from "../../../utils/LineChart";
import { useStateContext } from "../../../context/StateContext";
import { useMediaQuery } from 'react-responsive'


const benefitsCardItems = [
  {
    title: "Computer Skills",
    img: "/assets/studentdashboardAssets/CompositeLayer1.svg",
  },
  {
    title: "Communication",
    img: "/assets/studentdashboardAssets/CompositeLayer2.svg",
  },
  {
    title: "Latest Tools",
    img: "/assets/studentdashboardAssets/CompositeLayer3.svg",
  },
];
const statisticsCardItems = [
  {
    title: "Weekly Target",
    percent: 25,
  },
  {
    title: "Monthly Target",
    percent: 50,
  },
];
const lectureCardItems = [
  {
    title: "Fundamentals of Taxation in the US",
    author: "Mike Taylor",
    image: "/assets/studentdashboardAssets/lectureImg.png",
    lock: false,
  },
  {
    title: "Fundamentals of Taxation in the US",
    author: "Mike Taylor",
    image: "/assets/studentdashboardAssets/lectureImg.png",
    lock: true,
  },
  {
    title: "Fundamentals of Taxation in the US",
    author: "Mike Taylor",
    image: "/assets/studentdashboardAssets/lectureImg.png",
    lock: false,
  },
  {
    title: "Fundamentals of Taxation in the US",
    author: "Mike Taylor",
    image: "/assets/studentdashboardAssets/lectureImg.png",
    lock: false,
  },
  {
    title: "Fundamentals of Taxation in the US",
    author: "Mike Taylor",
    image: "/assets/studentdashboardAssets/lectureImg.png",
    lock: false,
  },
];

const AttendanceCard = ({ days }) => {
  return (
    <div
      className="d-flex flex-column justify-content-evenly align-items-center flex-wrap gap-2 py-3"
      style={{
        backgroundColor: "#fff",
        borderRadius: "10px",
        padding: "20px",
      }}
    >
      <p>Last 30 Days Attendance</p>
      <div
        className="d-flex justify-content-center text-center"
        style={{
          filter:
            "drop-shadow(0px 11.410014152526855px 49.78915023803711px #aac4e7)",
        }}
      >
        <Progressbar
          radius={60}
          progress={20}
          trackStrokeWidth={12}
          strokeColor={
            "linear-gradient(-141deg, #d320c1 0.52%, #c624c6 32.02%, #1461ff 97.08%)"
          }
        >
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              fontSize: "20px",
              fontWeight: "bold",
            }}
          >
            {days}
            <div style={{ fontSize: "6px" }}>Total Days</div>
          </div>
        </Progressbar>
      </div>

      <div className="mt-3" style={{ fontSize: "12px" }}>
        Course Report
      </div>
    </div>
  );
};

const OverView = ({data}) => {
  const isMobile = useMediaQuery({ query: '(max-width: 768px)' })

  console.log("test>",data)
  const { studentEnrolledData } = useStateContext();

  const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 5,
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 3,
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 2,
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1,
    },
  };

  return (
    <div className={isMobile?"d-flex flex-column-reverse justify-content-end":"d-flex justify-content-end"}>
      {studentEnrolledData?.text2 ? (
        <Container>
          <div
            style={{ width: "100%" }}
            className="d-flex w-100 justify-content-center"
          >
            <div
              className="d-flex flex-column gap-2 justify-content-start gap-5 px-5 py-4"
              style={{
                backgroundColor: "#fafafa",
                width: "100%",
                // justifyContent:isMobile?"center":"start"
              }}
            >
              <div style={{ marginTop: "105px" }}>
                <p
                  style={{
                    fontSize: "16px",
                    fontWeight: "bolder",
                  }}
                  className="w-50"
                >
                  Candidate Score
                </p>
                <div className="w-100">
                  <Score legendNone test={data} />
                </div>
              </div>
              <div className="d-flex justify-content-between">
                <div className="d-flex flex-column gap-4 justify-content-start w-100">
                  <p>
                    <b>Total classes</b>
                  </p>
                  <p style={{ color: "blue" }}>Classes this month</p>

                  <div style={{ display: "flex", justifyContent: "center" }}>
                    <div
                      style={{
                        backgroundColor: "#AE4B45",
                        padding: "15px",
                        textAlign: "center",
                        borderRadius: "8px",
                      }}
                    >
                      <p style={{ color: "white" }}>
                        <b>Placement Status</b>
                      </p>
                      <button
                        style={{
                          paddingLeft: "22px",
                          paddingRight: "22px",
                          border: "0",
                          borderRadius: "10px",
                        }}
                      >
                        Yes
                      </button>
                      <button
                        style={{
                          paddingLeft: "22px",
                          paddingRight: "22px",
                          border: "0",
                          borderRadius: "10px",
                          marginLeft: "15px",
                        }}
                      >
                        No
                      </button>
                    </div>
                  </div>
                </div>
                <div>
                  <p
                    className="px-3"
                    style={{
                      fontSize: "16px",
                      fontWeight: "bolder",
                    }}
                  >
                    Attendance
                  </p>
                  <AttendanceCard days={23} />
                </div>
              </div>
              <div>
                <p>Suggested Programs</p>

                <Marquee pauseOnHover>
                  <div className="d-flex flex-wrap gap-3">
                    {lectureCardItems?.map((items, i) => (
                      <div className="ms-3">
                        <LecturCard
                          key={i}
                          title={items.title}
                          author={items.author}
                          image={items.image}
                          lock={items.lock}
                        />
                      </div>
                    ))}
                  </div>
                </Marquee>
              </div>
            </div>
          </div>
        </Container>
      ) : (
        <div className="m-auto" style={{ fontSize: "30px" }}>
          <div className="d-flex justify-content-center">
            <Image
              width={100}
              height={100}
              alt="no data"
              src="/assets/studentdashboardAssets/empty-box.png"
            />
          </div>
          <p className="mt-3">--- No data to show ---</p>
        </div>
      )}

      <div>
        <StudentDetails />
      </div>
    </div>
  );
};

export default OverView;
