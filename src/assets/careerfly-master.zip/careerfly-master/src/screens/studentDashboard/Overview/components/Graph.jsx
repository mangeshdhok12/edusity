import React, { PureComponent, useEffect, useRef } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';


const initialData = [
	{ name: '2018-12-22', value: 32.51 },
	{ name: '2018-12-29', value: 29.92 },
	{ name: '2018-12-29', value: 22.92 },
	{ name: '2018-12-29', value: 24.92 },
	{ name: '2018-12-29', value: 35.92 },
	{ name: '2018-12-29', value: 27.92 },
	{ name: '2018-12-29', value: 31.92 },
	{ name: '2018-12-29', value: 23.92 },
	{ name: '2018-12-29', value: 25.92 },
	{ name: '2018-12-29', value: 21.92 },
	{ name: '2018-12-30', value: 22.68 },
	{ name: '2018-12-31', value: 42.67 },
];
const Ylabel=['Class One','Class Two','Class Two']


export default class Graph extends PureComponent {
	render() {

	return (
		<div style={{width:"400px",height:"200px"}}>
		<ResponsiveContainer width="100%" height="100%">
        <LineChart
          width={500}
          height={300}
          data={initialData}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis  dataKey="name" tick={false} />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line type="monotone" dataKey="value" stroke="#4CDFE8"   activeDot={{ r: 8 }} />
        </LineChart>
      </ResponsiveContainer>
	  </div>
	);
}
}