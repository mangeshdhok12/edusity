import Image from "next/image";
import React, { useState } from "react";
import { BsPauseFill, BsFillPlayFill } from "react-icons/bs";
import { themeColors } from "../../../../themes/colors";

const LecturCard = ({ title, image, author, lock }) => {
  const [btn, setBtn] = useState(false);

  return (
    <div style={{ opacity: lock ? "0.6" : "" }}>
      <div
        className="d-flex flex-column flex-wrap gap-2 p-3"
        style={{
          backgroundColor: "#f2e9ff",
          borderRadius: "12px",
        }}
      >
        <div className="d-flex justify-content-between gap-5 align-items-start">
          <div>
            <Image
              src={image}
              alt={title}
              placeholder="blur"
              blurDataURL={image}
              width={70}
              height={70}
              objectFit="contain"
              style={{ borderRadius: "10px" }}
            />
          </div>
          <div
            className="p-1"
            style={{
              cursor: "pointer",
              borderRadius: "20px",
              backgroundColor: themeColors.primary,
            }}
            onClick={() => {
              setBtn(!btn);
            }}
          >
            {lock ? (
              <Image
                src="/assets/studentdashboardAssets/lock.svg"
                alt="pauseIcon"
                placeholder="blur"
                blurDataURL="/assets/studentdashboardAssets/lock.svg"
                width={15}
                height={15}
                objectFit="contain"
              />
            ) : btn ? (
              <BsPauseFill color="white" size={15} />
            ) : (
              <BsFillPlayFill color="white" size={15} />
            )}
          </div>
        </div>

        <div
          className="d-flex flex-column gap-2 align-items-start"
          style={{ fontSize: "9px" }}
        >
          <div>{title}</div>
          <div>By {author}</div>
        </div>
      </div>
    </div>
  );
};

export default LecturCard;
