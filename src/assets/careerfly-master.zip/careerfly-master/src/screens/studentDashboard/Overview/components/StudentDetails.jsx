import React, { useEffect, useState } from "react";
import Image from "next/image";
import { BsChatDots, BsBell } from "react-icons/bs";
import { themeColors } from "../../../../themes/colors";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import DangerousIcon from "@mui/icons-material/Dangerous";
import { getAuth, updateProfile } from "firebase/auth";
import { getDoc, doc } from "firebase/firestore";
import { db, storage } from "../../../../lib/firebase";
import firebase from "firebase/compat/app";
import { CircularProgress } from "@mui/material";
import { toast, ToastContainer } from "react-toastify";
import { useStateContext } from "../../../../context/StateContext";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "#dfe4ea",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  borderRadius: "7px",
};

const StudentDetails = () => {
  const [user, setUser] = useState();
  const [photoLoad, setPhotoLoad] = useState(false);
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [name, setName] = useState("");
  const [file, setFile] = useState(null);
  const [url, setURL] = useState("");
  const [showUpload, setShowUpload] = useState(false);

  const { studentEnrolledData } = useStateContext();

  async function getUser() {
    const res = JSON.parse(localStorage.getItem("CareerFlyUser"));
    const docRef = doc(db, "users", res.user.uid);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      setUser(docSnap.data());
    } else {
      console.log("No such document!");
    }
  }

  useEffect(() => {
    getUser();
  }, []);

  function handleChange(e) {
    e.preventDefault();
    if (e.target.files[0]) {
      setFile(e.target.files[0]);
      setShowUpload(true);
    }
  }

  async function uploadPhoto() {
    setURL("");
    if (file) {
      setPhotoLoad(true);
      const path = `/images/${file.name}`;
      const ref = storage.ref(path);
      ref.put(file);
      const photourl = await ref.getDownloadURL();
      setURL(photourl);
      setFile(null);
      setPhotoLoad(false);
    }
  }

  const auth = getAuth();

  async function updateProfile(e) {
    e.preventDefault();

    const userDocRef = db
      .collection("users")
      .doc(firebase.auth().currentUser.uid);

    if (name) {
      userDocRef.update({
        name: name,
      });
      toast("name successfully updated");
    }
    if (url) {
      userDocRef.update({
        photo: url,
      });
      toast("profile pic successfully updated");
    }
  }

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mx-3">
        <div style={{ marginTop: "120px" }}>
          <p
            style={{
              fontSize: "18px",
              fontweight: "bold",
            }}
          >
            Hii
          </p>
          <p>Good Morning</p>
        </div>
        <div className="d-flex gap-4">
          <div
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              border: "1px solid #efeeee",
              borderRadius: "10px",
            }}
          >
            <BsChatDots size={21} />
          </div>
          <div
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              border: "1px solid #efeeee",
              borderRadius: "10px",
            }}
          >
            <BsBell size={21} />
          </div>
          <div
            style={{
              width: "10px",
              height: "10px",
              backgroundColor: "red",
              borderRadius: "50%",
              position: "absolute",
              right: 5,
            }}
          ></div>
        </div>
      </div>
      <div className="">
        <div className="d-flex justify-content-center mt-5">
          <Image
            style={{ borderRadius: "50%" }}
            alt="placeholder"
            src={user?.photo}
            width={94}
            height={94}
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/Placeholder_Rad.png"
          />
        </div>

        <p
          className="mt-3"
          style={{
            fontSize: "18px",
            fontWeight: "bold",
            margin: 0,
            textAlign: "center",
          }}
        >
          {user?.name}
        </p>
        <p className="text-center">
          {studentEnrolledData?.text2 ? (
            studentEnrolledData?.text2.replaceAll("-", " ").toUpperCase()
          ) : (
            <p>-- No course enrolled --</p>
          )}
        </p>
      </div>
      <div className="d-flex justify-content-evenly mt-5">
        <div className="text-center">
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            Student
          </p>
          <p>Status</p>
        </div>
        <div className="text-center">
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            7
          </p>
          <p>Days / Week</p>
        </div>
        <div className="text-center">
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            1
          </p>
          <p>Program</p>
        </div>
      </div>
      <div className="d-flex justify-content-evenly mt-3">
        <button
          style={{
            backgroundColor: themeColors.studentDashboardBg,
            width: "130px",
            height: "40px",
            borderRadius: "10px",
            color: "white",
            border: "none",
          }}
        >
          View Profile
        </button>
        <button
          style={{
            width: "130px",
            height: "40px",
            borderRadius: "10px",
            color: "#11243D",
            border: "none",
            border: "1px solid #E6E6EB",
          }}
          onClick={handleOpen}
        >
          Edit Profile
        </button>
        <Modal
          open={open}
          onClose={handleClose}
          aria-labelledby="modal-modal-title"
          aria-describedby="modal-modal-description"
        >
          <form id="editProfile" onSubmit={updateProfile}>
            <Box sx={style}>
              <DangerousIcon
                onClick={() => window.location.reload()}
                style={{
                  position: "absolute",
                  right: "0",
                  top: "3%",
                  cursor: "pointer",
                  width: "50px",
                  color: "brown",
                }}
              />
              <Typography id="modal-modal-description">
                <h5>Choose your profile image :</h5>
                <input
                  type="file"
                  onChange={handleChange}
                  style={{ marginTop: "10px" }}
                />
                {showUpload && (
                  <button
                    onClick={uploadPhoto}
                    className="px-3 my-4 py-2"
                    style={{
                      border: "none",
                      borderRadius: "6px",
                      backgroundColor: "#0984e3",
                      color: "white",
                      fontWeight: "bold",
                      textAlign: "center",
                      marginLeft: "25%",
                      marginRight: "25%",
                    }}
                  >
                    Upload
                  </button>
                )}
                {photoLoad && <CircularProgress />}
              </Typography>
              <Typography id="modal-modal-title" variant="h6" component="h2">
                Name : &nbsp;
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                  }}
                  style={{
                    marginTop: "15px",
                    borderRadius: "6px",
                    border: "1px solid gray",
                  }}
                />
              </Typography>
              <button
                className="px-3 my-4 py-2"
                style={{
                  border: "none",
                  borderRadius: "6px",
                  backgroundColor: "#0984e3",
                  color: "white",
                  fontWeight: "bold",
                  textAlign: "center",
                  marginLeft: "25%",
                  marginRight: "25%",
                }}
              >
                Update profile
              </button>
            </Box>
          </form>
        </Modal>
      </div>
      <div className="d-flex justify-content-evenly mt-5 px-3 gap-3">
        <div
          className="py-3"
          style={{
            width: "157px",
            height: "193px",
            backgroundColor: "#F2E9FF",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: "10px",
          }}
        >
          <Image
            alt="lock"
            src="/assets/studentdashboardAssets/lock.png"
            width={54}
            height={76}
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/lock.png"
          />
          <p
            style={{
              fontSize: "22px",
              fontWeight: "bold",
              color: "#51459E",
              marginTop: "2rem",
            }}
          >
            Certificate
          </p>
        </div>
        <div
          className=""
          style={{
            width: "157px",
            height: "193px",
            backgroundColor: "#FEF3F0",
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
            borderRadius: "10px",
          }}
        >
          <Image
            className=""
            alt="lock"
            src="/assets/studentdashboardAssets/lock.png"
            width={54}
            height={76}
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/lock.png"
          />
          <p
            className="m-0 p-0"
            style={{
              fontSize: "22px",
              fontWeight: "bold",
              color: "#AC6755",
              marginTop: "2rem",
              textAlign: "center",
            }}
          >
            Interview Prepration
          </p>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default StudentDetails;
