import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React, { useState } from "react";
import { FiMapPin } from "react-icons/fi";
import { IoIosArrowDown } from "react-icons/io";
import { IoBookmarkOutline, IoBookmark } from "react-icons/io5";

const TrainerCard = ({ name, video, address, linkedIn, time, isAvailable }) => {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");

  const [bookmark, setBookmark] = useState(false);

  return (
    <div
      className="d-flex flex-wrap p-3 my-4 w-100 justify-content-between align-items-center"
      style={{ backgroundColor: "#f9f9f9" }}
    >
      <div className={isMobileScreen?"d-flex flex-column gap-4 justify-content-between":"d-flex gap-4 justify-content-between"}>
        <div>
        <iframe width="300" height="175" src={video} title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div className="d-flex flex-column flex-wrap gap-4">
          <div className="d-flex gap-5">
            <div style={{ fontSize: "20px" }}>{name}</div>
            <div>
              <button
                style={{
                  color: "white",
                  outline: "none",
                  border: "none",
                  borderRadius: "12px",
                  padding: "5px 12px",
                  backgroundColor: "#81ddbb",
                }}
              >
                Verified
              </button>
            </div>
          </div>
          <div>
            <FiMapPin /> {address}
          </div>
          <div className="d-flex gap-5">
            <div>{linkedIn}</div>{" "}
            <div>
              <button
                style={{
                  color: "white",
                  outline: "none",
                  border: "none",
                  borderRadius: "12px",
                  padding: "5px 12px",
                  backgroundColor: "#ffbc6e",
                }}
              >
                {isAvailable ? "Available" : "Unavailable"}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="d-flex gap-4 justify-content-between">
        <div className="d-flex align-items-end">
          <div>
            Details <IoIosArrowDown />
          </div>
        </div>
        <div style={{ borderRight: "2px solid #000" }}></div>
        <div className={isMobileScreen?"d-flex flex-column gap-1":"d-flex flex-column gap-4"}>
          <div className="d-flex justify-content-between">
            <div>Time</div>
            <div
              onClick={() => {
                setBookmark(!bookmark);
              }}
            >
              {bookmark ? (
                <IoBookmark size={20} />
              ) : (
                <IoBookmarkOutline size={20} />
              )}
            </div>
          </div>
          <div className="">Today {time}</div>
          <div>
            <button
              style={{
                color: "white",
                outline: "none",
                border: "none",
                borderRadius: "12px",
                padding:isMobileScreen?"10px 25px": "21px 50px",
                backgroundColor: "#81ddbb",
              }}
            >
              {" "}
              JOIN NOW{" "}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default TrainerCard;
