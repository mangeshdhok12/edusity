import { useMediaQuery } from "@mui/material";
import React from "react";
import { Container } from "react-bootstrap";
import TrainerCard from "./components/TrainerCard";

const trainerDetails = [
  {
    name: "Nishank Jha",
    video: "https://www.youtube.com/embed/s6JD9UpNjIE",
    address: "Jhandewala, Delhi",
    linkedIn: "linkedin.com",
    isAvailable: true,
    time: "10:45 AM",
  },
  {
    name: "Nishank Jha",
    video: "https://www.youtube.com/embed/5xiN1AGEVSQ",
    address: "Jhandewala, Delhi",
    linkedIn: "linkedin.com",
    isAvailable: false,
    time: "10:45 AM",
  },
  {
    name: "Nishank Jha",
    video: "https://www.youtube.com/embed/s6JD9UpNjIE",
    address: "Jhandewala, Delhi",
    linkedIn: "linkedin.com",
    isAvailable: true,
    time: "10:45 AM",
  },
  {
    name: "Nishank Jha",
    video: "https://www.youtube.com/embed/5xiN1AGEVSQ",
    address: "Jhandewala, Delhi",
    linkedIn: "linkedin.com",
    isAvailable: true,
    time: "10:45 AM",
  },
];

const Trainer = () => {
const isMobileScreen = useMediaQuery("(max-width: 767px)");

  return (
    <Container style={{ marginTop: "110px" }}>
      <div>
        <div className="d-flex justify-content-between align-items-center mx-5">
          <h2>OUR TRAINERS</h2>
          <div>
            Welcome Back! <b>Priyank</b>
          </div>
        </div>
        <div className="d-flex flex-column">
          {trainerDetails.map((item, i) => {
            return (
              <div className={isMobileScreen ? "p-1" : "mx-4 p-1"} key={i}>
                <TrainerCard
                  name={item.name}
                  video={item.video}
                  address={item.address}
                  linkedIn={item.linkedIn}
                  isAvailable={item.isAvailable}
                  time={item.time}
                />
              </div>
            );
          })}
        </div>
      </div>
    </Container>
  );
};

export default Trainer;
