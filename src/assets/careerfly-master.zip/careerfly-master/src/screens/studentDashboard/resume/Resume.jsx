import React, { useState, useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Pagination } from "swiper";
import Image from "next/image";
import { Container } from "react-bootstrap";
import { toast, ToastContainer } from "react-toastify";
import { CircularProgress, useMediaQuery } from "@mui/material";

const Resume = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 768px)");

  const [loader, sertLoader] = useState(false);
  const [url, setUrl] = useState();
  const hiddenFileInput = React.useRef(null);
  const [file, setFile] = useState();
  const [isSelected, setIsSelected] = useState(false);
  const [items, setItems] = useState([]);

  useEffect(() => {
    const items = JSON.parse(localStorage.getItem("CareerFlyUser"));
    if (items) {
      setItems(items);
    }
    if (url) {
      sertLoader(false);
      toast("resume uploaded sucessfully");
      handleSubmit();
    }
  }, [url]);

  const handleChange = (e) => {
    sertLoader(true);
    var file = e.target.files[0];
    var reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = function (e) {
      var rawLog = reader.result.split(",")[1];
      var dataSend = {
        dataReq: {
          data: rawLog,
          name: items?.user.displayName + items?.user.uid,
          type: file.type,
        },
        fname: "uploadFilesToGoogleDrive",
      };
      fetch(
        "https://script.google.com/macros/s/AKfycbx0u0B9QSA120ZG0vgqdls9R5cJyi63SuFIAJixSes-RPEeS4WWYHXpTX6LIRBQGUYPXw/exec",
        { method: "POST", body: JSON.stringify(dataSend) }
      )
        .then((res) => res.json())
        .then((a) => {
          setUrl(a?.url);
        })
        .catch((e) => console.log(e));
    };
    setFile(e.currentTarget.files[0]);
    setIsSelected(true);
  };

  const handleClick = (e) => {
    hiddenFileInput.current.click();
  };

  const handleSubmit = async () => {
    const form = {
      name: items?.user.displayName,
      email: items?.user.email,
      url: url,
    };
    const response = await fetch("/api/resume-dashboard", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "content-Type": "application/json",
      },
      body: JSON.stringify(form),
    });
    const content = await response.json();
  };

  return (
    <Container style={{ marginTop: isMobileScreen ? "70px" : "110px" }}>
      <div className="mt-5">
        <div className={isMobileScreen?"d-flex flex-column justify-content-between align-items-center flex-wrap":"d-flex justify-content-between align-items-center flex-wrap"}>
          <div className={isMobileScreen ? "" : "mx-5"}>
            <iframe
              width={isMobileScreen ? "100%" : "500"}
              height={isMobileScreen ? "200" : "315"}
              src={data?.globalModels[0].sampleResume[0].link}
              title="YouTube video player"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowfullscreen
              className="rounded-5"
            ></iframe>
          </div>

          <div className="d-flex flex-column justify-content-center align-items-center gap-5">
            <button
              onClick={(e) => handleClick(e)}
              className="px-5 py-3 fs-5 rounded-3 mx-5"
            >
              Upload Resume
            </button>
            {loader ? <CircularProgress /> : null}
          </div>
          <input
            style={{ display: "none" }}
            type="file"
            name="file"
            ref={hiddenFileInput}
            accept="application/pdf"
            id="customFile"
            onChange={(e) => handleChange(e)}
          ></input>
        </div>
        <div>
          <h5 className="fw-bold fs-4 mt-3 ml-5">Sample Resume</h5>
          <div style={{ marginTop:isMobileScreen?"10px":"40px" }}>
            <Swiper
              autoplay={{ delay: 2500 }}
              modules={[Autoplay, Pagination]}
              slidesPerView={isMobileScreen ? 3 : 3}
              spaceBetween={isMobileScreen ? 10 : 0}
            >
              {data?.globalModels[0]?.sampleResume?.map((item, i) => (
                <SwiperSlide className="m-0" key={i}>
                  <a
                    href={item?.doc[0].url}
                    target="_blank"
                    style={{ textDecoration: "none", color: "Black" }}
                  >
                    <Image
                      placeholder="blur"
                      blurDataURL={item.image.url}
                      alt="sample resume"
                      src={item.image.url}
                      width={isMobileScreen ? 100 : 300}
                      height={isMobileScreen ? 160 : 400}
                      objectFit="contain"
                      className="rounded-3"
                    />
                  </a>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>
        </div>
      </div>
      <ToastContainer />
    </Container>
  );
};

export default Resume;
