import { Container, useMediaQuery } from "@material-ui/core";
import React,{useEffect} from "react";
import OrderSummary from "./components/OrderSummary";
import PayDetails from "./components/PayDetails";
import { useStateContext } from "../../context/StateContext";
import Program from "./components/Program";
import { useRouter } from "next/router";

const PaymentGateway = () => {
  const orderDetails=JSON.parse(localStorage.getItem("orderData"))

  const router=useRouter()
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div style={{ backgroundColor: "#f9f9f9", marginTop: "30px" }}>
      <Container>
        <div
          className={
            isMobileScreen
              ? "d-flex flex-column"
              : "d-flex justify-content-evenly"
          }
        >
          <div>
            <Program orderDetails={orderDetails} />
          </div>
          <div className="d-flex flex-column justify-content-between mx-2 mb-5">
            <OrderSummary orderData={orderDetails} />
            <PayDetails orderData={orderDetails} />
          </div>
        </div>
      </Container>
    </div>
  );
};

export default PaymentGateway;
