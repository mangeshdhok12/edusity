import React, { useEffect, useState } from "react";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  useMediaQuery,
} from "@mui/material";
import { themeColors } from "../../../themes/colors";
import Image from "next/image";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import FeeStructure from "./FeeStructure";
import { RiArrowDownSFill } from "react-icons/ri";

const Program = ({orderDetails}) => {
  // const [orderDetails, setOrderDetails] = useState();
  // useEffect(() => {
  //   const localorderDetails = JSON.parse(localStorage.getItem("orderData"));
  //   if (localorderDetails) {
  //     setOrderDetails(localorderDetails);
  //   }
  //   // console.log(localorderDetails)
  // }, [setOrderDetails]);
  


  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div
      className={isMobileScreen ? "p-3 mt-5 ms-auto me-auto" : "mt-5"}
      style={{
        backgroundColor: themeColors.white,
        borderRadius: "0 0 12px 12px",
        padding: "10px",
      }}
    >
      <h5
        className="px-3 py-2"
        style={{
          color: "white",
          backgroundColor: `${themeColors.primary}`,
          borderRadius: "5px",
        }}
      >
        {orderDetails.courseImage ? <>Program</> : <>Plan</>}
      </h5>
      <div className={isMobileScreen ? "d-flex flex-column" : "d-flex p-3"}>
        <div>
          <div
            className={
              isMobileScreen
                ? "d-flex flex-column"
                : "d-flex justify-content-center"
            }
          >
            {orderDetails.courseImage ? (
              <div className="d-flex flex-column justify-content-start">
                <Image
                  src={orderDetails.courseImage}
                  alt="Course Image"
                  width={800}
                  height={600}
                  objectFit="contain"
                />
              </div>
            ) : null}

            <div className={isMobileScreen ? "mt-3" : "mx-3"}>
              <strong style={{ fontSize: "1.2rem" }}>
                {orderDetails.courseTitle}
              </strong>
              {orderDetails.courseDescription ? (
                <p>{orderDetails.courseDescription}</p>
              ) : null}
            </div>
          </div>
          {isMobileScreen ? (
            <div>
              <Accordion>
                <AccordionSummary
                  expandIcon={
                    <div
                      className="d-flex justify-content-center"
                      style={{ borderRadius: "50%", backgroundColor: "black" }}
                    >
                      <RiArrowDownSFill size={20} color="white" />
                    </div>
                  }
                >
                  <h4>
                    <b>
                      This {orderDetails.courseImage ? <>Program</> : <>Plan</>}{" "}
                      includes:
                    </b>
                  </h4>
                </AccordionSummary>
                <AccordionDetails>
                  <div className="d-flex flex-column">
                    {orderDetails.courseProgram?.map((programs, i) => (
                      <div>
                        <div>
                          <CheckCircleRoundedIcon
                            style={{ color: themeColors.primary }}
                          />
                          <strong style={{ marginLeft: "7px" }}>
                            {programs}
                          </strong>
                        </div>
                      </div>
                    ))}
                  </div>
                </AccordionDetails>
              </Accordion>
            </div>
          ) : (
            <div>
              <strong style={{ fontSize: "1.2rem" }}>
                This {orderDetails.courseImage ? <>Program</> : <>Plan</>}{" "}
                includes:
              </strong>
              <div className="d-flex">
                <ul className="mt-4" style={{ listStyle: "none" }}>
                  {orderDetails?.courseProgram?.map((programs, i) => (
                    <div key={i}>
                      {i < orderDetails.courseProgram?.length / 2 ? (
                        <li>
                          <CheckCircleRoundedIcon
                            style={{ color: themeColors.primary }}
                          />
                          <strong style={{ marginLeft: "7px" }}>
                            {programs}
                          </strong>
                        </li>
                      ) : undefined}
                    </div>
                  ))}
                </ul>
                <ul className="mt-4" style={{ listStyle: "none" }}>
                  {orderDetails.courseProgram?.map((programs, i) => (
                    <div>
                      {i >= orderDetails.courseProgram?.length / 2 ? (
                        <li>
                          <CheckCircleRoundedIcon
                            style={{ color: themeColors.primary }}
                          />
                          <strong style={{ marginLeft: "7px" }}>
                            {programs}
                          </strong>
                        </li>
                      ) : undefined}
                    </div>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
        <div>
          {orderDetails.courseImage ? (
            <FeeStructure orderDetails={orderDetails} />
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default Program;
