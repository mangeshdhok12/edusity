import React from "react";
import { useMediaQuery } from "@mui/material";
import { themeColors } from "../../../themes/colors";

const OrderSummary = ({ orderData }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div
      className={isMobileScreen ? "mt-5 px-2 py-5" : "mt-5 px-3 py-5"}
      style={{
        border: `2px solid ${themeColors.primary}`,
        flexWrap: "wrap",
        whiteSpace: isMobileScreen ? undefined : "nowrap",
        borderRadius: "0 0 8px 8px",
        backgroundColor: "white",
      }}
    >
      <h6>
        <b>Order Summary</b>
      </h6>
      <h4>
        <b>{orderData.courseTitle}</b>
      </h4>
      <span style={{ color: themeColors.textSecondary }}>
        <p className="d-flex justify-content-between">
          Date: <p style={{ color: "black" }}>{orderData.date}-{orderData.time}</p>
        </p>
      </span>
    </div>
  );
};

export default OrderSummary;
