import React, { useState } from "react";
import { TextField } from "@mui/material";
import { themeColors } from "../../../themes/colors";
import Button from "../../../components/button/Button";
import { currency } from "../../../themes/currency";
import { useStateContext } from "../../../context/StateContext";

const PayDetails = ({ orderData }) => {
  const { userData } = useStateContext();
  const [disComp,setDisComp]=useState(false)
  const [coupon, setCoupon] = useState();
  const [couponCode, setCouponCode] = useState();
  const [correctCc, setCorrectCc] = useState();

  const displayRazorpay = async () => {
    const initializeRazorpay = () => {
      return new Promise((resolve) => {
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";

        script.onload = () => {
          resolve(true);
        };
        script.onerror = () => {
          resolve(false);
        };

        document.body.appendChild(script);
      });
    };

    const makePayment = async () => {
      const res = await initializeRazorpay();

      if (!res) {
        alert("Razorpay SDK Failed to load");
        return;
      }


      const couponDiscount = orderData?.couponDiscount?.split("%")[0];
      const orderCouponCode = orderData?.couponCode;
      let price = orderData.coursePrice;
  
      if (couponCode === orderCouponCode) {
        setCorrectCc(true);
        price =
          orderData.coursePrice -
          (orderData.coursePrice * couponDiscount) / 100;
          console.log("if",price)
      } else {
        if (couponCode) {
          setCorrectCc(false);
          price = orderData.coursePrice;
          console.log("else", price);
        }
      }

      var options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY,
        name: userData?.name,
        currency: currency?.name,
        amount: price * 100,
        description: "Thankyou for your purchase !",
        prefill: {
          name: userData?.name,
          email: userData?.email,
          contact: userData?.phone,
        },
      };

      const paymentObject = new window.Razorpay(options);
      paymentObject.open();
    };
    makePayment();
  };

  return (
    <div
      className="mt-3 px-3 py-3"
      style={{
        border: `2px solid ${themeColors.primary}`,
        whiteSpace: "nowrap",
        backgroundColor: "white",
        borderRadius: "8px 8px 0 0",
      }}
    >
      <div style={{ color: themeColors.textSecondary }}>
        <div>
          <div className="d-flex justify-content-between">
            <p>Total: </p>
            <div>
              <p style={{ color: "black", textAlign: "right" }}>
                <b>
                  {currency.symbol}
                  {orderData?.coursePrice} /-
                </b>
              </p>
              <span className="d-flex" style={{ lineHeight: "0.5px" }}>
                <p
                  style={{
                    textDecoration: "line-through",
                    textDecorationThickness: "2px",
                  }}
                >
                  {orderData?.courseMRP}
                </p>
                &nbsp;
                <p style={{ color: themeColors.primary }}>
                  <b> {orderData?.courseDiscount} OFF</b>
                </p>
              </span>
            </div>
          </div>
          <p className="d-flex justify-content-between">
            <p>Included Taxes:</p> <p>+GST</p>
          </p>
          <div>
            <div
              className="d-flex justify-content-center"
              onClick={() => {
                if (coupon) {
                  setCorrectCc(null);
                  setCouponCode("");
                  setCoupon(false);
                  return;
                }
                setCoupon(true);
              }}
            >
              <Button bgColor="lightgray" color="black" title="Add Coupon" />
            </div>
            <div className="d-flex justify-content-center mt-3">
              {coupon ? (
                <div>
                  <TextField
                    onChange={(e) => setCouponCode(e.currentTarget.value)}
                    placeholder="code here"
                  />
                </div>
              ) : undefined}
            </div>
          </div>

          {couponCode && (
            <div
              className="d-flex justify-content-center mt-2"
              onClick={() => setDisComp(true)}
            >
              <Button title="Apply Code" />
            </div>
          )}
          {disComp ? (
            <div>
              {couponCode === orderData?.couponCode ? (
                <>
                  <p style={{ color: "green" }} className="text-center mt-3">
                    Code applied, Off {`${orderData?.couponDiscount}`}
                  </p>
                  <div className="d-flex justify-content-between">
                    <p>Sub Total: </p>
                    <div>
                      <p style={{ color: "black", textAlign: "right" }}>
                        <b>
                          {currency.symbol}
                          {orderData?.coursePrice -
                            (orderData?.coursePrice *
                              orderData?.couponDiscount?.split("%")[0]) /
                              100}/-
                        </b>
                      </p>
                      <span className="d-flex" style={{ lineHeight: "0.5px" }}>
                        <p
                          style={{
                            textDecoration: "line-through",
                            textDecorationThickness: "2px",
                          }}
                        >
                          {orderData?.coursePrice}
                        </p>
                        &nbsp;
                        <p style={{ color: themeColors.primary }}>
                          <b> {orderData?.couponDiscount} OFF</b>
                        </p>
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <p style={{ color: "red" }} className="text-center mt-3">
                  Invalid code !
                </p>
              )}
            </div>
          ) : null}

          <div
            onClick={displayRazorpay}
            className="mt-3 d-flex justify-content-center align-content-center"
          >
            <Button title="Pay Now" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default PayDetails;
