import React from "react";
import {
  Accordion,
  useMediaQuery,
  AccordionDetails,
  AccordionSummary,
} from "@mui/material";
import { themeColors } from "../../../themes/colors";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import { RiArrowDownSFill } from "react-icons/ri";

const FeeStructure = ({ orderDetails }) => {
  // console.log(orderDetails)
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div>
      {isMobileScreen ? (
        <div>
          <Accordion>
            <AccordionSummary
              expandIcon={
                <div
                  className="d-flex justify-content-center"
                  style={{ borderRadius: "50%", backgroundColor: "black" }}
                >
                  <RiArrowDownSFill size={20} color="white" />
                </div>
              }
            >
              <div>
                <h4
                  className={
                    isMobileScreen
                      ? "d-flex flex-column align-items-center"
                      : "px-3 py-4 mb-2"
                  }
                >
                  <b>Additional Benefits</b>
                </h4>
              </div>
            </AccordionSummary>

            <AccordionDetails>
              <div>
                <div className="d-flex justify-content-center">
                  <span
                    className="px-4 py-1 text-center"
                    style={{
                      width: "150px",
                      fontSize: "20px",
                      borderRadius: "5px",
                      color: "white",
                      backgroundColor: themeColors.primary,
                    }}
                  >
                    <b>Free</b>
                  </span>
                </div>
                <div className="mt-3">
                  {orderDetails.courseBenifits?.map((benefits) => (
                    <div className="px-2">
                      <CheckCircleRoundedIcon color="success" />
                      <strong style={{ marginLeft: "5px" }}>{benefits}</strong>
                    </div>
                  ))}
                </div>
              </div>
            </AccordionDetails>
          </Accordion>
        </div>
      ) : (
        <div
          style={{
            backgroundColor: themeColors.white,
            border: `3px solid #ffcccc`,
            borderRadius: "12px",
            width: "270px",
          }}
        >
          <div
            style={{
              textAlign: "center",
              backgroundColor: "#ffcccc",
              borderRadius: "8px",
            }}
          >
            <h4 className="px-3 py-4 mb-2" style={{ lineHeight: "40px" }}>
              <b>Additional Benefits</b>
            </h4>
          </div>
          <div className="d-flex justify-content-center">
            <span
              className="px-4 py-1 text-center"
              style={{
                marginTop: "-30px",
                width: "150px",
                fontSize: "20px",
                borderRadius: "30px",
                color: "white",
                backgroundColor: themeColors.primary,
              }}
            >
              <b>Free</b>
            </span>
          </div>
          <div className="mt-3">
            {orderDetails.courseBenifits?.map((benefits) => (
              <div className="px-2">
                <CheckCircleRoundedIcon color="success" />
                <strong style={{ marginLeft: "5px" }}>{benefits}</strong>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FeeStructure;
