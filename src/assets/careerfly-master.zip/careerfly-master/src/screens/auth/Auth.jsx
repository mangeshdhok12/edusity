import { useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import { Container } from "react-bootstrap";
import Button from "../../components/button/Button";
import { themeColors } from "../../themes/colors";
import LogIn from "./components/logIn/LogIn";
import TrainerLogin from "./components/logIn/Trainer-login";
import Register from "./components/register/Register";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const Auth = () => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const [openRegister, setOpenRegister] = useState(false);
  const [value, setValue] = useState(0);

  const handleTrainerLogin = () => {
    console.log("object");
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div
      style={{ backgroundColor: themeColors.backgroundColor }}
      className="d-flex justify-content-center"
    >
      <div
        style={{
          backgroundImage: `url("${process.env.NEXT_PUBLIC_URL}/auth/Login Page.png")`,
          backgroundRepeat: "no-repeat",
          width: "1920px",
          height: "750px",
        }}
      >
        <Container>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: isMobileScreen ? "center" : "end",
                marginTop: isMobileScreen ? "50px" : "70px",
              }}
            >
              <div
                className="d-flex flex-row justify-content-center flex-wrap align-items-center "
                style={{
                  padding: isMobileScreen ? "30px 20px" : "10px 10px ",
                  borderRadius: "24px",
                }}
              >
                {/* <div style={{ marginLeft: "2px" }}>
                  <Button
                    title={openRegister ? "Sign in" : "Student Sign up"}
                    onClick={() => setOpenRegister(!openRegister)}
                  />
                </div> */}
                {/* <div style={{ marginLeft: "2px" }}>
                  <Button title={"Partner Login"} />
                </div> */}
                {/* <div
                  style={{
                    marginLeft: "2px",
                    marginTop: isMobileScreen ? "2px" : "",
                  }}
                >
                  <Button
                    title={"Trainer Login"}
                    onClick={handleTrainerLogin}
                  />
                </div> */}
              </div>
            </div>

            <div className="d-flex justify-content-end">
              <Box sx={{ width: "43%" }}>
                <Box>
                  <Tabs
                    value={value}
                    onChange={handleChange}
                    aria-label="role based login"
                    sx={{
                      "& .MuiTabs-indicator": {
                        display: "none",
                      },
                    }}
                  >
                    <Tab
                      label={openRegister ? "Sign in" : "Student Sign up"}
                      {...a11yProps(0)}
                      style={{
                        borderRadius: "5px",
                        backgroundColor: "#B3554F",
                        color: "#FFFFFF",
                        padding: "0px 15px",
                        marginRight: "10px",
                      }}
                      onClick={() => setOpenRegister(!openRegister)}
                    />
                    <Tab
                      label="Partner Login"
                      {...a11yProps(1)}
                      style={{
                        borderRadius: "5px",
                        backgroundColor: "#B3554F",
                        color: "#FFFFFF",
                        padding: "0px 15px",
                        marginRight: "10px",
                      }}
                    />
                    <Tab
                      label="Trainer Login"
                      {...a11yProps(2)}
                      style={{
                        borderRadius: "5px",
                        backgroundColor: "#B3554F",
                        color: "#FFFFFF",
                        padding: "0px 15px",
                      }}
                    />
                  </Tabs>
                </Box>
                <TabPanel value={value} index={0}>
                  {openRegister ? (
                    <Register setOpenRegister={setOpenRegister} />
                  ) : (
                    <LogIn
                      openRegister={openRegister}
                      setOpenRegister={setOpenRegister}
                    />
                  )}
                </TabPanel>
                <TabPanel value={value} index={1}>
                  Item Two
                </TabPanel>
                <TabPanel value={value} index={2}>
                  <TrainerLogin />
                </TabPanel>
              </Box>
            </div>
          </div>
        </Container>
      </div>
    </div>
  );
};

export default Auth;
