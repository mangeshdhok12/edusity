import { CircularProgress, useMediaQuery } from "@mui/material";
import { signInWithEmailAndPassword } from "firebase/auth";
import React, { useState } from "react";
import { useRouter } from "next/router";
import Button from "../../../../components/button/Button";
import { db, auth } from "../../../../lib/firebase";
import { addDoc, query, collection, getDocs, where } from "firebase/firestore";
import { useStateContext } from "../../../../context/StateContext";

const TrainerLogin = () => {
  const { setTrainerId, trainerId } = useStateContext();

  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const trainer = [];

  const handleLoginForm = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      await signInWithEmailAndPassword(auth, email, password);
      const docSnap = await getDocs(collection(db, "Trainer"));
      docSnap.forEach((doc) => {
        trainer.push(doc.data().email);
      });
      const existingTrainer = trainer.includes(email);
      if (!existingTrainer) {
        const addedData = await addDoc(collection(db, "Trainer"), {
          email: email,
          Classes: "",
          Contact: "",
          DailyTask: [],
          Experience: "",
          LinkedLink: "",
          Name: "",
          Position: "",
          Program: "",
          address: "",
          photoUrl: "",
        });
        localStorage.setItem("TrainerId", addedData.id);
        router.push("/trainer-dashboard/overview");
      } else {
        const q = query(collection(db, "Trainer"), where("email", "==", email));
        const querySnapshot = await getDocs(q);
        querySnapshot.forEach((doc) => {
          localStorage.setItem("TrainerId", doc.id);
        });
        router.push("/trainer-dashboard/overview");
      }
      setLoading(false);
    } catch (error) {
      console.log(error.message);
      setError("Some error Occures Please check your email and try again");
      setLoading(false);
    }
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: isMobileScreen ? "center" : "end",
          marginTop: isMobileScreen ? "" : "",
        }}
      >
        <div
          className="d-flex flex-column justify-content-end w-100"
          style={{
            backgroundColor: "white",
            borderRadius: "20px",
            padding: "20px",
            width: isMobileScreen ? "90%" : "30%",
          }}
        >
          <div className="d-flex flex-column align-items-center ">
            <h2>Sign In</h2>
          </div>

          <form>
            <div className="form-outline mb-4">
              <label className="form-label">Email address</label>
              <input
                type="email"
                id="form2Example1"
                className="form-control"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="form-outline mb-4">
              <label className="form-label">Password</label>
              <input
                type="password"
                id="form2Example2"
                className="form-control"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {loading && (
              <div className="d-flex justify-content-center">
                <CircularProgress className="mb-2 mt-1" />
              </div>
            )}

            {error && (
              <p style={{ color: "red", textAlign: "center" }}>{error}</p>
            )}
            <div className="d-flex justify-content-center">
              <Button title="Log In" onClick={(e) => handleLoginForm(e)} />
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default TrainerLogin;
