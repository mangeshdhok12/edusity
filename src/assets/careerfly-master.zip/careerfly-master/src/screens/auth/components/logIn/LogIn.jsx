import { CircularProgress, Modal, useMediaQuery } from "@mui/material";
import {
  GoogleAuthProvider,
  RecaptchaVerifier,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signInWithPhoneNumber,
  signInWithPopup,
} from "firebase/auth";
import React, { useState } from "react";
import { useRouter } from "next/router";
import Button from "../../../../components/button/Button";
import { storage, db, auth, provider } from "../../../../lib/firebase";
import Image from "next/image";
import { setDoc, doc } from "firebase/firestore";
import { ref, uploadBytesResumable } from "firebase/storage";
import { useStateContext } from "../../../../context/StateContext";

const LogIn = ({ openRegister, setOpenRegister }) => {
  const { setGoogleLogin } = useStateContext();
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [otpRequest, setOtpRequest] = useState(false);
  const [phoneDetail, setPhoneDetail] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");
  const [forgetPassword, setForgetPassword] = useState(false);
  const [resetPasswordLink, setResetPasswordLink] = useState(false);

  const handleLoginForm = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      const result = await signInWithEmailAndPassword(auth, email, password);
      localStorage.setItem("CareerFlyUser", JSON.stringify(result));
      setOpenRegister(false);
      router.push("/student-dashboard/overview");
    } catch (error) {
      setError(error.message.split("(auth/")[1].split(").")[0]);
      setLoading(false);
    }
  };

  const handleLoginUsingGoogle = async () => {
    setLoading(true);
    setError(false);
    try {
      const result = await signInWithPopup(auth, provider);
      const credentials = GoogleAuthProvider.credentialFromResult(result);
      const token = credentials.accessToken;
      const user = result.user;
      console.log("user--", user);
      const userDetails = {
        name: user.displayName,
        email: user.email,
        number: null,
        photo: user.photoURL,
        address: null,
        enrolledCourses: 0,
        test: [],
      };
      await setDoc(doc(db, "users", result.user.uid), userDetails);
      const storageRef = ref(storage, `/files/${result?.user.uid}`);
      await uploadBytesResumable(storageRef, user.photoURL);
      localStorage.setItem("CareerFlyUser", JSON.stringify(result));
      if (token && user) {
        setGoogleLogin(true);
        router.push("/student-dashboard/overview");
      }
    } catch (error) {
      setLoading(false);
    }
  };

  const handleLoginUsingPhone = () => {
    setPhoneDetail(true);
  };

  const handleOtpRequest = async (e) => {
    e.preventDefault();

    if (phoneNumber.length < 10) {
      setError("Please enter a valid phone number");
      setLoading(false);
      return;
    }
    if (phoneNumber.length >= 10) {
      window.recaptchaVerifier = new RecaptchaVerifier(
        "recaptcha-container",
        {
          size: "normal",
          callback: (response) => {},
          "expired-callback": () => {},
        },
        auth
      );
      const appVerifier = window.recaptchaVerifier;
      signInWithPhoneNumber(auth, `+91${phoneNumber}`, appVerifier).then(
        (confirmationResult) => {
          window.confirmationResult = confirmationResult;

          setOtpRequest(true);
        }
      );
    }
  };

  const handleVarifyOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      if (otp.length < 6 || otp.length > 6) {
        setError("Please enter a valid OTP");
        setLoading(false);
        return;
      } else {
        const result = await window.confirmationResult.confirm(otp);
        localStorage.setItem("CareerFlyUser", JSON.stringify(result));
        setOpenRegister(false);
        router.push("/student-dashboard/overview");
      }
    } catch (error) {
      setError(error.message.split("(auth/")[1].split(").")[0]);
      setLoading(false);
    }
  };
  const handleSignUp = () => {
    if (!openRegister) {
      setOpenRegister(true);
    }
  };

  const handleForgotPassword = () => {
    setForgetPassword(true);
  };

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      await sendPasswordResetEmail(auth, email);
      setLoading(false);
      setResetPasswordLink(true);
    } catch (error) {
      setError(error.message.split("(auth/")[1].split(").")[0]);
      setLoading(false);
    }
  };

  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: isMobileScreen ? "center" : "end",
          marginTop: isMobileScreen ? "" : "",
        }}
      >
        <div
          className="d-flex flex-column justify-content-end w-100"
          style={{
            backgroundColor: "white",
            borderRadius: "20px",
            padding: "20px",
            width: isMobileScreen ? "90%" : "30%",
          }}
        >
          <div className="d-flex flex-column align-items-center ">
            <h2>Sign In</h2>
            <div className="d-flex gap-4 my-2 ">
              <div>
                <Image
                  src={"/auth/phone-call.png"}
                  width={"30px"}
                  height={"30px"}
                  alt="CareerFly"
                  style={{ cursor: "pointer" }}
                  objectFit="cover"
                  onClick={() => handleLoginUsingPhone()}
                />
              </div>
              <div>
                {" "}
                <Image
                  src={"/auth/google_icon_img.svg"}
                  width={"30px"}
                  height={"30px"}
                  alt="CareerFly"
                  style={{ cursor: "pointer" }}
                  objectFit="cover"
                  onClick={() => handleLoginUsingGoogle()}
                />
              </div>
            </div>
          </div>
          <div className="d-flex justify-content-center">or</div>

          {phoneDetail ? (
            <form className="d-flex flex-column">
              <div className="form-outline mb-4">
                <label style={{ color: "white" }} className="form-label">
                  Phone Number
                </label>
                <input
                  type="phone"
                  placeholder="Enter your phone number"
                  id="form2Example1"
                  className="form-control w-100"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                />
              </div>
              {otpRequest && (
                <div className="form-outline mb-4">
                  <label className="form-label">OTP</label>
                  <input
                    type="number"
                    placeholder="Enter your OTP"
                    id="form2Example1"
                    className="form-control"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                </div>
              )}
              {!otpRequest && <div id="recaptcha-container" />}

              {!otpRequest && (
                <div className="m-auto pt-4">
                  <Button
                    title="Send OTP"
                    onClick={(e) => handleOtpRequest(e)}
                  />
                </div>
              )}

              {otpRequest && (
                <div className="d-flex justify-content-center">
                  <Button
                    title="Verify OTP"
                    onClick={(e) => handleVarifyOtp(e)}
                  />
                </div>
              )}
            </form>
          ) : (
            <form>
              <div className="form-outline mb-4">
                <label className="form-label">Email address</label>
                <input
                  type="email"
                  id="form2Example1"
                  className="form-control"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="form-outline mb-4">
                <label className="form-label">Password</label>
                <input
                  type="password"
                  id="form2Example2"
                  className="form-control"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              {loading && (
                <div className="d-flex justify-content-center">
                  <CircularProgress className="mb-2 mt-1" />
                </div>
              )}
              {error === "too-many-requests" && (
                <p style={{ color: "red", textAlign: "center" }}>
                  Too many failed attempts, Please try again later.
                </p>
              )}
              {error === "wrong-password" && (
                <p style={{ color: "red", textAlign: "center" }}>
                  Invalid Credentials !
                </p>
              )}
              <div className="d-flex justify-content-center">
                <Button title="Log In" onClick={(e) => handleLoginForm(e)} />
              </div>
              <div className="d-flex justify-content-center mt-2">
                <p
                  style={{ cursor: "pointer", color: "blue" }}
                  onClick={() => handleForgotPassword()}
                >
                  Forgot Password ?
                </p>
              </div>
              <div className="text-center mt-3 ">
                <p>
                  {"Don't have account ? "}
                  <span
                    style={{ cursor: "pointer", color: "blue" }}
                    onClick={() => handleSignUp()}
                  >
                    sign up
                  </span>
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
      <Modal
        open={forgetPassword}
        onClose={() => setForgetPassword(false)}
        aria-labelledby="simple-modal-title"
        aria-describedby="simple-modal-description"
      >
        <div
          style={{
            backgroundColor: "white",
            borderRadius: "20px",
            padding: "20px",
            width: "30%",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            position: "absolute",
          }}
        >
          <div className="d-flex flex-column align-items-center ">
            <h2>Forgot Password</h2>
            <div className="d-flex flex-column align-items-center ">
              <form>
                <div className="form-outline mb-4">
                  <label className="form-label">Email address</label>
                  <input
                    type="email"
                    id="form2Example1"
                    className="form-control"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="d-flex justify-content-center">
                  <Button
                    title="Reset Password"
                    onClick={(e) => handlePasswordReset(e)}
                  />
                </div>
                {resetPasswordLink && (
                  <div className="d-flex justify-content-center flex-column gap-2">
                    <p style={{ color: "green" }}>
                      Reset Password Link Sent to your Email, Please check your
                      email, After reset your password, you can login with your
                      new password.
                    </p>
                    <p
                      style={{ cursor: "pointer", color: "blue" }}
                      onClick={() => setForgetPassword(false)}
                    >
                      Go Back to Login
                    </p>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default LogIn;
