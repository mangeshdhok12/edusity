import { CircularProgress, useMediaQuery } from "@mui/material";
import {
  createUserWithEmailAndPassword,
  RecaptchaVerifier,
  signInWithPhoneNumber,
} from "firebase/auth";
import { setDoc, doc } from "firebase/firestore";
import { useRouter } from "next/router";
import React, { useState } from "react";
import Button from "../../../../components/button/Button";
import { db, auth } from "../../../../lib/firebase";
import Image from "next/image";

const Register = ({ setOpenRegister }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [otpRequest, setOtpRequest] = useState(false);
  const [phoneDetail, setPhoneDetail] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState("");

  const handleRegisterForm = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      localStorage.setItem("CareerFlyUser", JSON.stringify(res));

      const userDetails = {
        name,
        email,
        number: null,
        photo: null,
        address: null,
        enrolledCourses: 0,
        test: [],
      };
      await setDoc(doc(db, "users", res.user.uid), userDetails);
      setOpenRegister(false);
      router.push("/profile");
    } catch (error) {
      setLoading(false);
      setError(error.message);
    }
  };
  const handleLoginUsingPhone = () => {
    setPhoneDetail(true);
  };
  const handleOtpRequest = async (e) => {
    e.preventDefault();

    if (phoneNumber.length < 10) {
      setError("Please enter a valid phone number");
      setLoading(false);
      return;
    }
    if (phoneNumber.length >= 10) {
      window.recaptchaVerifier = new RecaptchaVerifier(
        "recaptcha-container",
        {
          size: "normal",
          callback: (response) => {},
          "expired-callback": () => {},
        },
        auth
      );
      const appVerifier = window.recaptchaVerifier;
      signInWithPhoneNumber(auth, `+91${phoneNumber}`, appVerifier).then(
        (confirmationResult) => {
          window.confirmationResult = confirmationResult;

          setOtpRequest(true);
        }
      );
    }
  };
  const handleVarifyOtp = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      if (otp.length < 6 || otp.length > 6) {
        setError("Please enter a valid OTP");
        setLoading(false);
        return;
      } else {
        const result = await window.confirmationResult.confirm(otp);
        localStorage.setItem("CareerFlyUser", JSON.stringify(result));
        setOpenRegister(false);
        router.push("/profile");
      }
    } catch (error) {
      setError(error.message.split("(auth/")[1].split(").")[0]);
      setLoading(false);
    }
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
        }}
      >
        <div
          className="d-flex flex-column justify-content-end w-100"
          style={{
            backgroundColor: "white",
            borderRadius: "20px",
            padding: "20px",
            width: isMobileScreen ? "90%" : "30%",
          }}
        >
          <div className="d-flex flex-column align-items-center">
            <h2>Sign Up</h2>
            <div className="d-flex gap-4 my-2">
              <Image
                src={"/auth/phone-call.png"}
                width={"30px"}
                height={"30px"}
                alt="CareerFly"
                style={{ cursor: "pointer" }}
                objectFit="cover"
                onClick={() => handleLoginUsingPhone()}
              />
              <Image
                src={"/auth/google_icon_img.svg"}
                width={"30px"}
                height={"30px"}
                alt="CareerFly"
                style={{ cursor: "pointer" }}
                objectFit="cover"
              />
            </div>
          </div>
          <div className="d-flex justify-content-center mb-2">or</div>
          {phoneDetail ? (
            <form>
              <div className="form-outline mb-4">
                <label
                  style={{ color: "white" }}
                  className="form-label"
                  for="form2Example1"
                >
                  Phone Number
                </label>
                <input
                  type="phone"
                  placeholder="Enter your phone number"
                  id="form2Example1"
                  className="form-control w-100"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                />
              </div>
              <div className="d-flex justify-content-center">
                <Button title="Send OTP" onClick={(e) => handleOtpRequest(e)} />
              </div>
              {otpRequest && (
                <div className="form-outline mb-4">
                  <label className="form-label" for="form2Example1">
                    OTP
                  </label>
                  <input
                    type="number"
                    placeholder="Enter your OTP"
                    id="form2Example1"
                    className="form-control"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                  />
                </div>
              )}
              {otpRequest && (
                <div className="d-flex justify-content-center">
                  <Button
                    title="Verify OTP"
                    onClick={(e) => handleVarifyOtp(e)}
                  />
                </div>
              )}
              {!otpRequest && <div id="recaptcha-container"></div>}
            </form>
          ) : (
            <form>
              <div className="form-outline mb-4">
                <label className="form-label" for="form2Example1">
                  Name
                </label>
                <input
                  type="text"
                  id="form2Example1"
                  className="form-control"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <div className="form-outline mb-4">
                <label className="form-label" for="form2Example1">
                  Email address
                </label>
                <input
                  type="email"
                  id="form2Example1"
                  className="form-control"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="form-outline mb-4">
                <label className="form-label" for="form2Example2">
                  Password
                </label>
                <input
                  type="password"
                  id="form2Example2"
                  className="form-control"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div>
                {error && (
                  <p style={{ color: "red", textAlign: "center" }}>
                    Email already exists !
                  </p>
                )}
              </div>
              {loading && (
                <div className="d-flex justify-content-center">
                  <CircularProgress className="mb-3 mt-1" />
                </div>
              )}
              {error === "too-many-requests" && (
                <p style={{ color: "red", textAlign: "center" }}>
                  Too many failed attempts, Please try again later.
                </p>
              )}

              <div className="d-flex justify-content-center">
                <Button
                  title="Sign up"
                  onClick={(e) => handleRegisterForm(e)}
                />
              </div>
              <div className="text-center mt-4">
                <p>
                  Already have account ?&nbsp;
                  <span
                    style={{ cursor: "pointer", color: "blue" }}
                    onClick={() => {
                      setOpenRegister(false);
                    }}
                  >
                    Login
                  </span>
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default Register;
