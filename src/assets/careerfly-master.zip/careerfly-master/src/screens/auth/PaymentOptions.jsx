import { useMediaQuery } from '@mui/material';
import React, { useState } from 'react'
import Button from '../../../components/button/Button';
import {themeColors} from '../../../themes/colors'
import Card from './Card';
import NetBanking from './NetBanking';
import UPI from './UPI';
import Wallet from './Wallet';

const PaymentOptions = ({data})=>{

    const [value, setValue] = useState("");
    const [clicked, setClicked] = useState(0);
    const isMobileScreen = useMediaQuery("(max-width: 991px)");


    let element
    if(value == "Card"){
        element = <Card/>;
    } else if(value == "Net Banking"){
        element = <NetBanking data = {data}/>;
    }else if(value == "Wallets"){
        element = <Wallet data = {data}/>;
    }else if(value == "UPI"){
        element = <UPI/>;
    }
    return(
        <div className='my-5' style={{backgroundColor:themeColors.white}}>
        <div className='ps-3 p-2' style={{backgroundColor:themeColors.primary, color:themeColors.textLight}}>More Payment Options</div>
        <div className='d-flex' style={{flexWrap:"wrap", flexDirection:isMobileScreen?"column":"row"}}>
           <div className='mb-4'>
            {data.title.map((item, index)=>{
                return(
                    <div key={index} className='' style={{border:`1px solid ${themeColors.primary}`}}>
                        <div className='btn w-100 text-start' style ={{backgroundColor:( value === item) ? "#fff": themeColors.backgroundColor, outline:"none",color:themeColors.black, borderRadius:"0px"}} onClick={()=>{setValue(item)}}>{item}</div>
                    </div>
                )
            })}
           </div>
           <div className='d-flex' style={{alignItems:"center", justifyContent:"center"}}>
            {element}
           </div>

        </div>
    </div>

    )
}

export default PaymentOptions;