import React from "react";
import { Container } from "react-bootstrap";
import Alumni from "./components/Alumni";
import Banner from "./components/Banner";
import Partners from "./components/Partners";

const Placement = ({ data }) => {
  return (
    <>
      <Container>
        <Banner data={data} />
      </Container>{" "}
      <Container>
        <Alumni data={data} />
      </Container>
      <Partners data={data} />
    </>
  );
};
export default Placement;
