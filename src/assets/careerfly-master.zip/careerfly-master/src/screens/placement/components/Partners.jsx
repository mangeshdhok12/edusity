import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { Autoplay } from "swiper";
import { SwiperSlide, Swiper } from "swiper/react";
import { themeColors } from "../../../themes/colors";

const Partners = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div
      className="mb-5"
      style={{ backgroundColor: themeColors.backgroundColor }}
    >
      <div className="px-5 pt-4 mt-5">
        <h2 className="text-center">
          <b>Our Collaborated Partners</b>
        </h2>
      </div>

      <div style={{ padding: "20px" }}>
        <Swiper
          id="swiper1"
          className="swiper1"
          autoplay={{ delay: 2500 }}
          modules={[Autoplay]}
          slidesPerView={isMobileScreen ? 2 : 6}
        >
          {data.placements[0]?.partners
            ?.slice(0, Math.trunc(data.placements[0].partners.length / 2))
            .map((item, i) => {
              return (
                <div key={i}>
                  <SwiperSlide>
                    <div className="d-flex justify-content-center">
                      <Image
                        objectFit="contain"
                        placeholder="blur"
                        blurDataURL={item.url}
                        src={item.url}
                        height={90}
                        width={190}
                        alt="brands"
                      />
                    </div>
                  </SwiperSlide>
                </div>
              );
            })}
        </Swiper>
        <Swiper
          id="swiper2"
          className="swiper2"
          autoplay={{ delay: 2500 }}
          modules={[Autoplay]}
          slidesPerView={isMobileScreen ? 2 : 6}
        >
          {data.placements[0]?.partners
            ?.slice(
              Math.trunc(data.placements[0]?.partners.length / 2),
              Math.trunc(data.placements[0]?.partners.length)
            )
            ?.map((item, j) => {
              return (
                <div key={j}>
                  <SwiperSlide>
                    <div className="d-flex justify-content-center">
                      <Image
                        objectFit="contain"
                        placeholder="blur"
                        blurDataURL={item.url}
                        src={item.url}
                        height={90}
                        width={190}
                        alt="brands"
                      />
                    </div>
                  </SwiperSlide>
                </div>
              );
            })}
        </Swiper>
      </div>
    </div>
  );
};

export default Partners;
