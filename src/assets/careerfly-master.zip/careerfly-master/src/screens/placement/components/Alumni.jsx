import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { themeColors } from "../../../themes/colors";
import { AiFillLinkedin } from "react-icons/ai";
import { Col, Row } from "react-bootstrap";

const Alumni = ({ data, title = "Our Successful Alumni" }) => {
  const isMobileScreen = useMediaQuery("(max-width: 1167px)");
  return (
    <div className="w-100">
      <h1 className="px-5 py-3 text-center">{title}</h1>
      <Row>
        {data.placements[0].alumni.map((item, index) => {
          return (
            <Col
              className="col-sm-12 p-3"
              md={6}
              key={index}
              style={{
                width: "",
                border: `1px solid ${themeColors.primary}`,
                backgroundColor: themeColors.backgroundColor,
                boxShadow: "1px 1px 7px 1px lightgray",
                marginBottom: "20px",
              }}
            >
              <div
                className={"d-flex justify-content-start column"}
                style={{ flexWrap: isMobileScreen ? "wrap" : "" }}
              >
                <div
                  className={isMobileScreen ? "" : "me-4"}
                  style={{
                    borderRadius: "12px",
                  }}
                >
                  <Image
                    objectFit="contain"
                    placeholder="blur"
                    blurDataURL={item.image1?.url}
                    src={item.image1?.url}
                    height={300}
                    width={200}
                    alt="profiles"
                    style={{ marginTop: "-1px", borderRadius: "12px" }}
                  />
                  {item.link ? (
                    <div style={{ cursor: "pointer" }}>
                      <a
                        style={{ color: "black" }}
                        target="_blank"
                        href={item.link}
                        rel="noreferrer"
                      >
                        <AiFillLinkedin size={25} />
                      </a>
                    </div>
                  ) : undefined}
                </div>
                <div style={{ width: "100%" }}>
                  <h3 className="mt-1 fw-bold">{item.text1}</h3>
                  <h4>{item.text2}</h4>
                  {!isMobileScreen ? (
                    <p className="pt-1">{item.text3}</p>
                  ) : null}
                  <div>
                    <Image
                      objectFit="contain"
                      placeholder="blur"
                      blurDataURL={item.image2.url}
                      src={item.image2.url}
                      height={40}
                      width={100}
                      alt="careerfly"
                    />
                  </div>
                </div>
              </div>
              <div
                style={{
                  display: isMobileScreen ? "block" : "none",
                }}
              >
                <p className="pt-2">{item.text3}</p>
              </div>
            </Col>
          );
        })}
      </Row>
    </div>
  );
};

export default Alumni;
