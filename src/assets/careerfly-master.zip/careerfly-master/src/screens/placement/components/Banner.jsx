import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";
import { Autoplay, Navigation, Pagination } from "swiper";
import { Swiper, SwiperSlide } from "swiper/react";

function CoursesBanner({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 990px)");
  return (
    <div className="d-flex justify-content-center mt-5" style={{height:isMobileScreen?"200px":""}}>
      <Swiper
        spaceBetween={50}
        pagination={true}
        navigation={isMobileScreen ? false : true}
        modules={[Navigation, Autoplay, Pagination]}
        autoplay={{ delay: 7000 }}
      >
        {data.placements[0]?.banners?.map((item, i) => (
          <SwiperSlide className="d-flex justify-content-center" key={i}>
            <Image
              src={item.url}
              width={isMobileScreen? 400 : 1920}
              alt="careerfly"
              height={isMobileScreen? 150 : 500}
              objectFit="contain"
              layout="fixed"
              placeholder="blur"
              blurDataURL={item.url}
            />
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
}

export default CoursesBanner;
