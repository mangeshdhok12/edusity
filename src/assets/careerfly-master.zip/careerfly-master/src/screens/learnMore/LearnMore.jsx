import React from "react";
import { Container } from "react-bootstrap";
import BookCounselling from "./component/BookCounselling";
import FirstSlider from "./component/FirstSlider";
import VideoBanner from "./component/VideoBanner";

const LearnMore = ({ data }) => {
  return (
    <div>
      <VideoBanner data={data} />
      <Container>
        <FirstSlider data={data} />
        <BookCounselling data={data} />
      </Container>
    </div>
  );
};

export default LearnMore;
