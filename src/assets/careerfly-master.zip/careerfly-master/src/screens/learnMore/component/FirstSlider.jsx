import React from "react";
import Image from "next/image";
import { themeColors } from "../../../themes/colors";
import { useMediaQuery } from "@mui/material";

function FirstSlider({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const knowMore = {
    knowMoreData: data.knowMores[0].knowMoreData,
  };
  return (
    <div className="d-flex justify-content-center align-items-center">
      <div style={{ marginTop: "10px" }}>
        {knowMore.knowMoreData?.map((item, i) => {
          return (
            <div
              key={i}
              style={{
                height: isMobileScreen ? "700px" : undefined,
                marginTop: "30px",
                boxShadow: "1px 1px 7px 1px lightgray",
                borderRadius: "14px",
              }}
              className={
                isMobileScreen
                  ? "d-flex flex-column-reverse justify-content-evenly"
                  : `d-flex ${
                      i % 2 === 0 ? `flex-row-reverse` : `flex-row`
                    } justify-content-evenly`
              }
            >
              <div
                style={{
                  width: isMobileScreen ? "100%" : "40%",
                }}
                className="d-flex flex-column justify-content-center px-3 "
              >
                <h2>{item.heading}</h2>
                <p className="mt-3">{item.content}</p>
              </div>
              <div className="d-flex justify-content-center">
                <Image
                  src={item.image.url}
                  width={400}
                  height={400}
                  objectFit="contain"
                  alt="careerfly"
                  placeholder="blur"
                  blurDataURL={item.image.url}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default FirstSlider;
