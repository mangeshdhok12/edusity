import React from "react";
import { themeColors } from "../../../themes/colors";
import Button from "../../../components/button/Button";
import { useRouter } from "next/router";
import { useMediaQuery } from "@mui/material";

const BookCounselling = ({ data }) => {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  const knowMore = {
    heading: data.knowMores[0].description.heading,
    content: data.knowMores[0].description.content,
  };
  const router = useRouter();
  return (
    <div
      className="px-5 py-4 mb-5"
      style={{
        marginTop: "30px",
        boxShadow: "1px 1px 7px 1px lightgray",
        borderRadius: "14px",
      }}
    >
      <h2 className="text-center">{knowMore.heading}</h2>
      <p
        className="mt-3"
        style={{ fontSize: isMobileScreen ? "0.85rem" : "1rem" }}
      >
        {knowMore.content}
      </p>
      <div className="mt-4">
        <Button
          title="Book Counselling"
          IsCenter={true}
          onClick={() => router.push("/career-counselling")}
        />
      </div>
    </div>
  );
};

export default BookCounselling;
