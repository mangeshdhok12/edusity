import { useMediaQuery } from "@mui/material";
import React from "react";

const VideoBanner = ({ data }) => {
  const knowMore = {
    knowMoreData: data.knowMores[0].video.url,
  };
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div
      className={
        isMobileScreen
          ? "d-flex justify-content-center"
          : "d-flex justify-content-center"
      }
      style={{ marginTop: isMobileScreen ? "5rem" : "12rem" }}
    >
      <video
        loop
        playsInline
        autoPlay
        muted
        controls
        style={{ objectFit: "cover" }}
        width="100%"
        height={isMobileScreen ? "180px" : "600px"}
      >
        <source src={knowMore.knowMoreData} type="video/webm" />
      </video>
    </div>
  );
};

export default VideoBanner;
