import React from "react";
import { Container } from "react-bootstrap";
import Button from "../../components/button/Button";
import IntroSlider from "./components/IntroSlider";
import HeroBanner from "./components/HeroBanner";
import Achievers from "./components/Achievers";
import Courses from "./components/Courses";
import Alumni from "./components/Alumni";
import InfoDiv from "./components/InfoDiv";
import SuccessStep from "./components/SuccessStep";
import Eligibility from "./components/Eligibility";
import Link from "next/link";
import LoadingItems from "./components/LoadingItems";

const HomeScreen = ({ data }) => {
  const placementprogram = {
    heading: data.homepages[0]?.placementProgram.heading,
    contet: data.homepages[0]?.placementProgram.content,
    image: data.homepages[0]?.placementProgram.image,
  };
  return (
    <div
      style={{
        backgroundColor: "white",
        fontFamily: "Gill Sans",
      }}
    >
      <Container>
        <HeroBanner data={data} />
        <Achievers data={data} />
        <Alumni data={data} />
      </Container>
      <IntroSlider data={data} />
      <Container>
        <InfoDiv
          imageWidth={470}
          imageHeight={370}
          align="right"
          url={placementprogram.image.url}
          titleHeading={placementprogram?.heading}
          subtitleHeading={placementprogram?.contet}
          button={
            <Link href="/courses">
              <div>
                <Button fontSize="17px" title="ALL PROGRAMS" />
              </div>
            </Link>
          }
        />
        <Courses data={data} />
        <div>
          <SuccessStep data={data} />
        </div>
        <div>
          <LoadingItems data={data} />
        </div>
        <div className="mb-4">
          <Eligibility align="left" data={data} />
        </div>
      </Container>
    </div>
  );
};

export default HomeScreen;
