import { useMediaQuery } from "@mui/material";
import React from "react";

const SuccessStep = ({ data }) => {
  const successStepVideo = {
    video: data.homepages[0]?.successStepVideo,
  };

  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <div>
      <div
        className="d-flex flex-column align-items-center"
        style={{
          marginTop: "50px",
        }}
      >
        <video
          loop
          playsInline
          autoPlay
          muted
          width="100%"
          style={{
            objectFit: "contain",
          }}
        >
          <source src={successStepVideo.video?.url} type="video/webm" />
        </video>
      </div>
    </div>
  );
};

export default SuccessStep;
