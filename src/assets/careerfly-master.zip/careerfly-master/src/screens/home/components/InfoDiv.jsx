import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import React from "react";

function InfoDiv({
  imageWidth,
  imageHeight,
  rowAlign,
  align,
  url,
  titleHeading,
  subtitleHeading,
  button,
  handleNavigation,
}) {
  const isMobileScreen = useMediaQuery("(max-width: 990px)");

  const textAlign = align;

  let contentAlign;

  if (textAlign === "left") {
    contentAlign = "start";
  } else {
    contentAlign = "end";
  }

  return (
    <div
      style={{
        marginTop: "104px",
        padding: isMobileScreen ? "10px" : "10px 80px 10px 80px",
        boxShadow: "1px 1px 7px 1px lightgray",
        borderRadius: "14px",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: isMobileScreen ? "column" : rowAlign,
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <Image
            src={url}
            alt="career fly"
            placeholder="blur"
            blurDataURL={url}
            width={isMobileScreen ? 250 : imageWidth}
            height={isMobileScreen ? 250 : imageHeight}
            objectFit="contain"
          />
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "space-evenly",
            flexDirection: "column",
            height: isMobileScreen ? undefined : "330px",
            paddingRight: isMobileScreen ? undefined : "35px",
          }}
        >
          <div
            style={{
              fontSize: isMobileScreen ? "1.5rem" : "2rem",
              fontWeight: "600",
              textAlign: textAlign,
            }}
          >
            {titleHeading}
          </div>
          <div className="d-flex justify-content-evenly">
            <div
              style={{
                width: isMobileScreen ? undefined : "550px",
                fontSize: isMobileScreen ? "0.8" : undefined,
                margin: "2px 0",
                textAlign: textAlign,
              }}
            >
              {subtitleHeading}
            </div>
          </div>
          <div
            className={`d-flex justify-content-${contentAlign} mt-3`}
            onClick={handleNavigation}
          >
            {button}
          </div>
        </div>
      </div>
    </div>
  );
}

export default InfoDiv;
