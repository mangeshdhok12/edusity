import React from "react";
import { Container } from "react-bootstrap";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation, Pagination } from "swiper";
import Image from "next/image";
import Button from "../../../components/button/Button";
import { useMediaQuery } from "@mui/material";
import { useRouter } from "next/router";

function IntroSlider({ data }) {
  const router = useRouter();
  const introslider = {
    introSliderData: data.homepages[0]?.introSlider,
  };

  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <Container>
      <div style={{ marginTop: "60px" }}>
        <Swiper
          style={{
            boxShadow: "1px 1px 7px 1px lightgray",
            borderRadius: "14px",
          }}
          spaceBetween={50}
          pagination={true}
          navigation={isMobileScreen ? false : true}
          modules={[Navigation, Autoplay, Pagination]}
          autoplay={{ delay: 7000 }}
        >
          {introslider.introSliderData?.map((item, i) => (
            <SwiperSlide key={i}>
              <div
                className={
                  isMobileScreen
                    ? "d-flex flex-column-reverse justify-content-evenly"
                    : "d-flex justify-content-evenly"
                }
              >
                <div
                  style={{
                    padding: isMobileScreen ? "10px" : undefined,
                    width: isMobileScreen ? "100%" : "40%",
                  }}
                  className="d-flex flex-column justify-content-center"
                >
                  <h2 style={{ fontSize: "2rem" }}>
                    <b>{item.heading}</b>
                  </h2>
                  <p className="mt-3">{item.content}</p>
                  <div className="mt-3">
                    <Button
                      title="Know More"
                      onClick={() => router.push("/learnmore")}
                    />
                  </div>
                </div>
                <div className="d-flex justify-content-center">
                  <Image
                    src={item.image?.url}
                    width={500}
                    height={500}
                    objectFit="contain"
                    alt="careerfly"
                    placeholder="blur"
                    blurDataURL={item.image?.url}
                  />
                </div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </Container>
  );
}

export default IntroSlider;
