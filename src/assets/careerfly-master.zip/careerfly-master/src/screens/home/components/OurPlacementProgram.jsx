import React from "react";
import { Container } from "react-bootstrap";
import Button from "../../../components/button/Button";
import { homePageContent } from "../../../content/siteContent";
import InfoDiv from "./InfoDiv";

function OurPlacementProgram({ align }) {
  return (
    <Container>
      <InfoDiv
        imageWidth={470}
        imageHeight={470}
        align={align}
        rowAlign="row"
        url={homePageContent.placementProgram.image}
        titleHeading={homePageContent.placementProgram.heading}
        subtitleHeading={homePageContent.placementProgram.content}
        button={<Button fontSize="17px" title="Know More" IsCenter={"true"} />}
      />
    </Container>
  );
}

export default OurPlacementProgram;
