import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import React, {useState } from "react";
import { Container } from "react-bootstrap";
import Button from "../../../components/button/Button";
import { themeColors } from "../../../themes/colors";
import { RxLapTimer } from "react-icons/rx";
import { BsDownload } from "react-icons/bs";
import { useStateContext } from "../../../context/StateContext";
import { MdOutlineHighlight } from "react-icons/md";

function Courses({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");
  const { setQuoteOpen, setCc,setCcd,setRouteFrom,setCourse } = useStateContext();

  const defaultFilterText = isMobileScreen ? "All" : "All Programs";

  const [currentFilter, setCurrentFilter] = useState(defaultFilterText);

  return (
    <Container style={{ marginTop: "100px" }}>
      <h2>
        <b>Our trending programs</b>
      </h2>
      <div
        style={{
          overflowX: "auto",
        }}
        className={
          isMobileScreen ? "d-flex align-items-center" : "d-flex flex-wrap"
        }
      >
        <span
          onClick={(e) => {
            setCurrentFilter(e.currentTarget.innerText);
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.color = themeColors.primary;
            e.currentTarget.style.textDecoration = `3px underline`;
            e.currentTarget.style.textUnderlineOffset = `10px`;
            e.currentTarget.style.textDecorationColor = themeColors.primary;
          }}
          onMouseLeave={(e) => {
            if (currentFilter === defaultFilterText) {
              return;
            }
            e.currentTarget.style.color = "black";
            e.currentTarget.style.textDecoration = `none`;
            e.currentTarget.style.textUnderlineOffset = `10px`;
            e.currentTarget.style.textDecorationColor = undefined;
          }}
          className="d-flex align-items-center"
          style={{
            marginRight: "0.5rem",
            cursor: "pointer",
            color:
              currentFilter === defaultFilterText
                ? themeColors.primary
                : "black",
            textDecoration:
              currentFilter === defaultFilterText ? `3px underline` : "none",
            textUnderlineOffset:
              currentFilter === defaultFilterText ? `10px` : undefined,
            textDecorationColor:
              currentFilter === defaultFilterText
                ? themeColors.primary
                : "black",
          }}
        >
          {defaultFilterText}
        </span>
        {data.categories[0]?.subCategories?.map((item2, j) => (
          <div key={j}>
            <button
              onClick={(e) => {
                setCurrentFilter(e.currentTarget.innerText);
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = themeColors.primary;
                e.currentTarget.style.textDecoration = `3px underline`;
                e.currentTarget.style.textUnderlineOffset = `10px`;
                e.currentTarget.style.textDecorationColor = themeColors.primary;
              }}
              onMouseLeave={(e) => {
                if (item2.subcategoryName === currentFilter) {
                  return;
                }

                e.currentTarget.style.color = "black";
                e.currentTarget.style.textDecoration = `none`;
                e.currentTarget.style.textUnderlineOffset = `10px`;
                e.currentTarget.style.textDecorationColor = undefined;
              }}
              className="btn"
              style={{
                width: item2.subcategoryName.length > 18 ? "200px" : undefined,
                marginLeft: isMobileScreen ? "0.3rem" : "1rem",
                color:
                  item2.subcategoryName === currentFilter
                    ? themeColors.primary
                    : "black",
                textDecoration:
                  item2.subcategoryName === currentFilter
                    ? `3px underline`
                    : "none",
                textUnderlineOffset:
                  item2.subcategoryName === currentFilter ? `10px` : undefined,
                textDecorationColor:
                  item2.subcategoryName === currentFilter
                    ? themeColors.primary
                    : "black",
              }}
            >
              {item2.subcategoryName}
            </button>
          </div>
        ))}
      </div>
      <div className="d-flex">
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          {data.courses?.map((item, index) => {
            const industryIndex = item.subCategories?.findIndex(
              (item2) => item2.categories[0]?.categoryName === "Industry"
            );

            if (
              (index < 6 && currentFilter === defaultFilterText) ||
              item.subCategories[industryIndex]?.subcategoryName ===
                currentFilter
            ) {
              return (
                <div
                  className="d-flex flex-column justify-content-between"
                  key={index}
                  style={{
                    borderRadius: "10px",
                    width: "300px",
                    border: `1px solid ${themeColors.textLight}`,
                    boxShadow: "1px 1px 2px 1px gray",
                    marginTop: isMobileScreen ? "1.5rem" : "2rem",
                    marginLeft: isMobileScreen ? 0 : "2rem",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = "scale(1.02)";
                    e.currentTarget.style.boxShadow = "1px 2px 15px 3px gray";
                    e.currentTarget.style.transition = "all 0.3s ease-in-out";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = "scale(1)";
                    e.currentTarget.style.boxShadow = "1px 1px 2px 1px gray";
                    e.currentTarget.style.transition = "all 0.3s ease-in-out";
                  }}
                >
                  <div style={{ position: "relative" }}>
                    <div
                      style={{
                        position: "absolute",
                        zIndex: 100,
                        padding: "0 0.5em",
                        width: "40%",
                        fontSize: "1em",
                        marginLeft: "-15px",
                        lineHeight: "2em",
                        color: "#e6e2c8",
                        borderRadius: "0 0.2em 0.2em 0",
                        background: themeColors.primary,
                        boxShadow: "-1px 2px 5px rgba(0,0,0,0.5)",
                        top: "2em",
                      }}
                    >
                      <p className="m-0 p-0">{item?.certificationLabel}</p>
                    </div>
                    <div
                      style={{
                        position: "absolute",
                        width: "23px",
                        height: "20px",
                        backgroundColor: themeColors.primary,
                        filter: "brightness(100%)",
                        marginLeft: "-11.49px",
                        marginTop: "55px",
                        transform: "rotate(45deg)",
                        zIndex: 0,
                      }}
                    />

                    <Image
                      style={{
                        borderRadius: "10px 10px 0 0 ",
                      }}
                      src={
                        item.image?.url
                          ? item.image?.url
                          : "/assets/altCourse.jpg"
                      }
                      alt="careerfly"
                      width={350}
                      height={250}
                      placeholder="blur"
                      blurDataURL={
                        item.image?.url
                          ? item.image?.url
                          : "/assets/altCourse.jpg"
                      }
                      objectFit="cover"
                    />

                    <div
                      className="d-flex w-100 p-1"
                      style={{
                        marginTop: "-5px",
                        borderRadius: "8px",
                        boxShadow:
                          "0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)",
                        border: `3px solid ${themeColors.primary}`,
                      }}
                    >
                      <div className="w-25 d-flex justify-content-center align-items-center">
                        <Image
                          src={item.courseCardIcon?.url}
                          width={32}
                          height={32}
                          alt="Careerfly"
                        />
                      </div>
                      <div
                        className="w-100 d-flex justify-content-center align-items-center fw-bold "
                        style={{
                          fontSize: "17px",
                          borderLeft: `2px solid ${themeColors.primary}`,
                          alignContent: "center",
                        }}
                      >
                        {item.chooseCourseType[0] === "Placement_Program"
                          ? "Placement Program"
                          : "Skill Certification"}
                      </div>
                    </div>
                    <div className="p-2 m-0">
                      <h5 className="fs-5 m-0">{item.title}</h5>

                      <p>{item?.desc}</p>
                    </div>
                  </div>

                  <div className="p-2" style={{ borderRadius: "20px" }}>
                    <div>
                      <div className="d-flex gap-2 align-items-center">
                        <RxLapTimer size={20} />
                        <p className="m-0 fs-6">{item.duration} </p>
                      </div>
                      <div className="d-flex gap-2 align-items-center">
                        <MdOutlineHighlight size={20} />
                        <p className="m-0 fs-6">{item.insights}</p>
                      </div>
                    </div>

                    <div className="d-flex my-2 justify-content-between">
                      <div
                        onClick={() => {
                          setCcd(item?.curriculumDoc?.url)
                          setCc(item.title);
                          setQuoteOpen(true);
                          setRouteFrom("Curriculam")
                          setCourse(item.title)
                          
                        }}
                        className="d-flex w-50 justify-content-center"
                      >
                        <Button
                          fontSize={14}
                          title="CURRICULUM"
                          bgColor={themeColors.backgroundColor}
                          color={themeColors.primary}
                          icon={<BsDownload />}
                          border={themeColors.primary}
                          marginBottom="0"
                          boxShadow="1px 1px 2px 1px lightgray"
                          marginTop="0"
                        />
                      </div>
                      <Link prefetch={false} href={`/courses/${item.slug}`}>
                        <div className="d-flex w-50 justify-content-center">
                          <Button
                            fontSize={14}
                            title="KNOW MORE"
                            marginBottom="0"
                            marginTop="0"
                          />
                        </div>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            }
          })}
        </div>
      </div>

      <div>
        <Link href="/courses">
          <div className="d-flex justify-content-center mt-5">
            <Button
              title="VIEW ALL "
              bgColor={themeColors.white}
              color={themeColors.primary}
            />
          </div>
        </Link>
      </div>
    </Container>
  );
}

export default Courses;
