import Link from "next/link";
import React from "react";
import Button from "../../../components/button/Button";
import InfoDiv from "./InfoDiv";

function Eligibility({ data, align }) {
  const eligibility = {
    heading: data.homepages[0]?.eligibility.heading,
    content: data.homepages[0]?.eligibility.content,
    image: data.homepages[0]?.eligibility.image,
  };
  return (
      <InfoDiv
        imageWidth={670}
        imageHeight={470}
        align={align}
        rowAlign="row-reverse"
        directionColumn={"true"}
        url={eligibility.image.url}
        titleHeading={eligibility.heading}
        subtitleHeading={eligibility.content}
        button={
          <Link href="/career-counselling">
            <div>
              <Button
                fontSize="17px"
                title="BOOK COUNSELLING"
                IsCenter={"true"}
              />
            </div>
          </Link>
        }
      />
  );
}

export default Eligibility;
