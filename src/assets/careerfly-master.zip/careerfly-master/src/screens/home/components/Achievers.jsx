import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper";
import Image from "next/image";
import { useMediaQuery } from "@mui/material";

function Achievers({ data }) {
  const brandImage = {
    image: data.homepages[0]?.brandImage,
  };
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div
      className="mt-5"
      style={{
        display: "flex",
        flexDirection: "column",
        textAlign: "center",
      }}
    >
      <div>
        <h2 style={{ fontSize: isMobileScreen ? "18px" : "25px" }}>
          Careerfly Achievers Work At
        </h2>
      </div>
      <div>
        <Swiper
          slidesPerView={isMobileScreen ? 3 : 5}
          spaceBetween={30}
          autoplay={{ delay: 2000 }}
          modules={[Autoplay]}
          className="my-3"
        >
          {brandImage.image?.map((item, i) => (
            <SwiperSlide key={i} style={{ height: "auto" }}>
              <div
                style={{
                  borderRadius: "10px",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Image
                  objectFit="contain"
                  placeholder="blur"
                  blurDataURL={item.url}
                  src={item.url}
                  height={100}
                  width={190}
                  alt="careerfly"
                  style={{ marginTop: "-1px" }}
                />
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </div>
  );
}

export default Achievers;
