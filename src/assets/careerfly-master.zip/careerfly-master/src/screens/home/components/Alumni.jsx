import React from "react";
import { Container } from "react-bootstrap";
import { useMediaQuery } from "@mui/material";
import { Swiper, SwiperSlide } from "swiper/react";
import Image from "next/image";
import { Autoplay } from "swiper";
import Button from "../../../components/button/Button";
import Link from "next/link";
import { AiOutlineRight } from "react-icons/ai";

function Alumni({ data }) {
  const alumni = {
    image: data.homepages[0]?.alumni,
  };
  const isMobileScreen = useMediaQuery("(max-width: 991px)");

  return (
    <Container style={{ paddingLeft: "0", paddingRight: "0" }}>
      <div style={{ margin: "2em 0 0 0" }}>
        <div>
          <h2 style={{ fontSize: isMobileScreen ? "18px" : "25px"}} className="text-center">
            Success Stories
          </h2>
        </div>

        <div style={{ marginTop: "40px" }}>
          <Swiper
            autoplay={{ delay: 2500 }}
            modules={[Autoplay]}
            spaceBetween={30}
            slidesPerView={isMobileScreen ? 2 : 4}
          >
            {alumni.image?.map((item, i) => (
              <SwiperSlide key={i}>
                <div className="d-flex justify-content-center">
                  <Image
                    placeholder="blur"
                    blurDataURL={item.url}
                    alt={item.alt}
                    src={item.url}
                    width={350}
                    height={150}
                    objectFit="contain"
                  />
                </div>
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
      <div style={{ marginTop: "40px" }}>
        <Link href="/placement">
          <div>
            <Button
              title="VIEW MORE"
              icon={<AiOutlineRight />}
              IsCenter={true}
            />
          </div>
        </Link>
      </div>
    </Container>
  );
}

export default Alumni;
