import React, { useEffect, useState } from "react";
import Button from "../../../components/button/Button";
import { themeColors } from "../../../themes/colors";
import Image from "next/image";

const Counter = ({ item, target, url, title }) => {
  const [count, setCounter] = useState(1);

  useEffect(() => {
    const incrementCounter = () => {
      setCounter(count + 1);
    };

    if (
      count < target.split("+")[0] &&
      item?.heading.charAt(item.heading.length - 1) !== "%"
    ) {
      setTimeout(incrementCounter, 1);
    }
  }, [count, target, item]);

  return (
    <div className="d-flex flex-column">
      <Image
        placeholder="blur"
        src={url}
        blurDataURL={url}
        height={150}
        width={150}
        objectFit="contain"
        alt="careerfly"
      />
      <div className="d-flex justify-content-center mt-3">
        <Button
          bgColor={themeColors.white}
          color={themeColors.black}
          border={themeColors.white}
          boxShadow={`4px 4px 6px 2px ${themeColors.gray}`}
          title={
            item.heading.charAt(item.heading.length - 1) !== "%" ? (
              <span>
                {count < target.split("+")[0] ? count : <span>{count}+</span>}
              </span>
            ) : (
              target
            )
          }
          borderRadius="12px"
          fontSize={30}
          fontWeight={700}
        />
      </div>
      <div>
        <p
          className="mt-2 m-0 text-center"
          style={{ fontSize: "1.5rem", fontWeight: "900", width: "200px" }}
        >
          {title}
        </p>
      </div>
    </div>
  );
};

export default Counter;
