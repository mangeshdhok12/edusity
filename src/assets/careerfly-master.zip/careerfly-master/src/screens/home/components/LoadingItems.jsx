import { useMediaQuery } from "@mui/material";
import React from "react";
import Counter from "./Counter";

const LoadingItems = ({ data }) => {
  const analyticsData = {
    data: data.homepages[0]?.analytics,
  };

  let buttonTitle;

  const isMobileScreen = useMediaQuery("(max-width: 767px)");

  return (
    <div
      className={
        isMobileScreen
          ? undefined
          : "d-flex justify-content-evenly p-5 mt-5 my-5"
      }
      style={{
        flexWrap: "wrap",
        boxShadow: isMobileScreen ? "none" : "1px 1px 7px 1px lightgray",
        borderRadius: "14px",
      }}
    >
      {analyticsData.data?.map((item, index) => {
        return (
          <div
            style={{ display: isMobileScreen ? "none" : undefined }}
            key={index}
          >
            <Counter
              item={item}
              key={index}
              target={item.heading}
              url={item.image.url}
              title={item.content}
              buttonTitle={buttonTitle}
            />
          </div>
        );
      })}
    </div>
  );
};

export default LoadingItems;
