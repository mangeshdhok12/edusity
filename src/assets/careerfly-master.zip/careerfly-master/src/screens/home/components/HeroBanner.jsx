import React from "react";
import Image from "next/image";
import { useMediaQuery } from "@mui/material";
import { themeColors } from "../../../themes/colors";
import Link from "next/link";
import Button from "../../../components/button/Button";
import { RichText } from "@graphcms/rich-text-react-renderer";

function HeroBanner({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 991px)");
  return (
    <div
      className="p-0 p-md-3 p-lg-5 "
      style={{
        display: "flex",
        justifyContent: "space-between",
        flexDirection: isMobileScreen ? "column" : "row",
        alignItems: "center",
        marginTop: isMobileScreen ? "7rem" : "6rem",
      }}
    >
      <div
        className={
          isMobileScreen
            ? "d-flex flex-column align-items-center mb-5 justify-content-between"
            : "d-flex flex-column justify-content-between"
        }
        style={{
          height: "220px",
        }}
      >
        <span
          style={{
            fontSize: isMobileScreen ? "25px" : "38px",
            fontWeight: "600",
          }}
        >
          {data.homepages[0]?.heroBanner.heading}
        </span>
        <span
          style={{
            fontSize: isMobileScreen ? "16px" : "18px",
            fontWeight: "400",
            color: themeColors?.textSecondary,
            lineHeight: "17px",
          }}
        >
          <div>
            <RichText content={data.homepages[0]?.heroBanner.desc?.raw} />
          </div>
        </span>

        <div
          style={{
            width: isMobileScreen ? "310px" : undefined,
          }}
        >
          <div
            className="d-flex"
            style={{
              justifyContent: isMobileScreen ? "space-between" : undefined,
            }}
          >
            <Link href="/learnmore">
              <div className="d-flex">
                <Button
                  fontSize={isMobileScreen ? "14px" : "16px"}
                  title="LEARN MORE"
                  padding="8px 10px"
                  marginTop="28px"
                />
              </div>
            </Link>
            <div
              style={{
                marginLeft: isMobileScreen ? 0 : "1rem",
              }}
            >
              <Link href="/career-counselling">
                <div>
                  <Button
                    fontSize={isMobileScreen ? "14px" : "16px"}
                    title="BOOK COUNSELLING"
                    padding="8px 5px"
                    color={themeColors?.primary}
                    bgColor={themeColors?.white}
                    border={themeColors?.primary}
                  />
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <Image
        alt="careerfly"
        placeholder="blur"
        blurDataURL={data.homepages[0]?.heroBanner.image}
        src={data.homepages[0]?.heroBanner.image.url}
        height={350}
        width={350}
        objectFit="contain"
      />
    </div>
  );
}

export default HeroBanner;
