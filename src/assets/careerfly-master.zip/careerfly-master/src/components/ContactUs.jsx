import React, { useState } from "react";
import { themeColors } from "../themes/colors";
import { useMediaQuery } from "@mui/material";
import { RiCustomerService2Line } from "react-icons/ri";
import TextField from "@mui/material/TextField";
import Button from "./button/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import { ToastContainer, toast } from "react-toastify";
import { Box, Checkbox, FormControlLabel, FormGroup } from "@mui/material";
import Image from "next/image";
import Modal from "react-bootstrap/Modal";

const ContactUs = () => {
  const [open, setOpen] = useState(false);
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [terms, setTerms] = useState(false);
  const [error, setError] = useState("");
  const isMobileScreen = useMediaQuery("(max-width: 765px)");

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (fullName && email && phone && terms) {
      setOpen(false);
      setError(false);
      toast.success("Messege Sent", { theme: "colored" });
    } else if (error === "tcError") {
      toast.warning("Please accept terms & conditions", { theme: "colored" });
    } else {
      setOpen(false);
      toast.error("Some Fields are missing", { theme: "colored" });
      setError(true);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        bottom: 10,
        right: 10,
        height: "5rem",
        width: "5rem",
        backgroundColor: themeColors.primary,
        borderRadius: 50,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        color: themeColors.textLight,
      }}
      onClick={handleClickOpen}
    >
      <RiCustomerService2Line className="fs-1" />
      <Dialog
        maxWidth={"md"}
        open={open}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">{"Get in Touch"}</DialogTitle>
        <DialogContent
          sx={{
            display: "flex",
            flexDirection: isMobileScreen ? "column" : "row",
          }}
        >
          <Box
            sx={{
              width: isMobileScreen ? "100%" : "50%",
              display: "flex",
              justifyContent: "center",
            }}
          >
            <Image
              src="/assets/customer-service (1).png"
              alt="carrerfly"
              placeholder="blur"
              blurDataURL="/assets/customer-service (1).png"
              width={isMobileScreen ? "200" : "300"}
              height={isMobileScreen ? "200" : "300"}
            />
          </Box>
          <Box
            sx={{
              width: isMobileScreen ? "100%" : "50%",
            }}
          >
            <TextField
              autoFocus
              margin="dense"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              id="name"
              label="Full Name"
              type="text"
              fullWidth
              variant="standard"
            />
            <TextField
              autoFocus
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              margin="dense"
              id="email"
              label="Email Address"
              type="email"
              fullWidth
              variant="standard"
            />
            <TextField
              autoFocus
              margin="dense"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              id="phoneNumber"
              label="Mobile Number"
              type="text"
              fullWidth
              variant="standard"
            />
            <FormGroup>
              <FormControlLabel
                control={<Checkbox />}
                label="Accept T&C"
                onChange={(e) => {
                  if (e.currentTarget.checked === true) {
                    setTerms(true);
                  } else {
                    setTerms(false);
                    setError("tcError");
                  }
                }}
              />
            </FormGroup>
            <ToastContainer />
            {error === true ? (
              <p style={{ color: themeColors.error }}>
                Some Fields are missing
              </p>
            ) : (
              ""
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSubmit} title="SUBMIT" />
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default ContactUs;
