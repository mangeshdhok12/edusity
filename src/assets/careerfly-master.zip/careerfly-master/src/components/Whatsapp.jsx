import React from "react";
import { AiOutlineWhatsApp } from "react-icons/ai";
import { themeColors } from "../themes/colors";

const Whatsapp = () => {
  return (
    <div
      style={{
        zIndex: 10,
        position: "fixed",
        bottom: 70,
        right: 10,
        height: "3rem",
        width: "3rem",
        backgroundColor: "white",
        borderRadius: 50,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        cursor: "pointer",
        color: themeColors.textLight,
        boxShadow: "1px 1px 7px 1px lightgray",
      }}
    >
      <a href="https://wa.me/+918273466595" target="_blank" rel="noreferrer">
        <AiOutlineWhatsApp color={themeColors.primary} size={25} />
      </a>
    </div>
  );
};

export default Whatsapp;
