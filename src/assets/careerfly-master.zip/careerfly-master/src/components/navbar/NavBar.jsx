import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import Navbar from "react-bootstrap/Navbar";
import { useStateContext } from "../../context/StateContext";
import { themeColors } from "../../themes/colors";
import Button1 from "../button/Button";
import { FaUser } from "react-icons/fa";
import { useRef, useState, useEffect } from "react";
import { AiOutlineDown } from "react-icons/ai";
import OurPrograms from "./components/OurPrograms";
import OffCanvasMenu from "./components/OffCanvasMenu";
import OurProgramMobile from "./components/OurProgramsMobile";
import { GiHamburgerMenu } from "react-icons/gi";
import { MdCancel } from "react-icons/md";
import { useRouter } from "next/router";

function NavBar({ data }) {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");
  const { userToken, setToggle, toggle } = useStateContext();
  const navToggleRef = useRef();
  const ourProgramMobileMenuRef = useRef();
  const [dropdownAnim, setDropDownAnim] = useState();
  const [showBtn, setShowBtn] = useState(false);
  // const [closeBtn,setCloseBtn]=useState(false)
  const router = useRouter();
  const currentRoute = router.pathname;

  const handleDashboardHamburger = () => {
    setToggle(!toggle);
  };
  const routes = [
    "overview",
    "recorded-videos",
    "resume",
    "trends",
    "certificate",
    `test/[test]`,
    "testPerformance",
    "our-trainers",
    "live",
    "hiring-partners",
    "open-position",
    "global-updates",
    "placement",
    "analytics",
  ];
  // useEffect(()=>{
  //   if(isMobileScreen && (currentRoute.includes("student")||currentRoute.includes("trainer"))){
  //    setShowBtn(true)
  //   }
  // },[isMobileScreen, currentRoute])
  return (
    <>
      {[false].map((expand, i) => (
        <Navbar
          style={{ boxShadow: "1px 1px 7px 1px lightgray" }}
          className="d-flex justify-content-between"
          fixed="top"
          key={i}
          bg="white"
          expand={expand}
        >
          <div
            className={
              isMobileScreen
                ? "d-flex justify-content-between align-items-center"
                : "container d-flex justify-content-between align-items-center"
            }
          >
            {/* <div className="" style={{ marginLeft: "7px" }}>
              {routes?.map((route, i) => (
                <div key={i}>
                  {router.pathname === `/student-dashboard/${route}` &&
                  isMobileScreen ? (
                    <div className="">
                      {" "}
                      <Button1
                        onClick={handleDashboardHamburger}
                        // width="100%"
                        fontSize={isMobileScreen ? 12 : undefined}
                        title={isMobileScreen ? "" : ""}
                        icon={
                          <div>
                            {toggle ? (
                              <MdCancel
                                style={{
                                  transform: isMobileScreen
                                    ? "rotate(180deg)"
                                    : dropdownAnim
                                    ? "rotate(180deg)"
                                    : undefined,
                                  transition: "all 0.3s ease-in-out",
                                }}
                                // className="position-relative"
                                size={20}
                              />
                            ) : (
                              <GiHamburgerMenu
                                style={{
                                  transform: isMobileScreen
                                    ? "rotate(180deg)"
                                    : dropdownAnim
                                    ? "rotate(180deg)"
                                    : undefined,
                                  transition: "all 0.3s ease-in-out",
                                }}
                                // className="position-relative"
                                size={20}
                              />
                            )}
                          </div>
                        }
                      />
                    </div>
                  ) : undefined}
                </div>
              ))}
            </div> */}
            <div className="d-flex align-items-center ">
              <Navbar.Toggle
                aria-controls={`offcanvasNavbar-expand-lg`}
                ref={navToggleRef}
                style={{
                  height: "40px",
                  margin: "0 0.5rem",
                  display: isMobileScreen ? "block" : "none",
                }}
              />
              <Link href="/">
                <div className="d-flex flex-column justify-content-center">
                  <Navbar.Brand
                    className="d-flex flex-column justify-content-center"
                    style={{ cursor: "pointer" }}
                  >
                    <Image
                      src={data?.data.globalModels[0]?.logo?.url}
                      placeholder="blur"
                      blurDataURL={data?.data.globalModels[0]?.logo?.url}
                      width={200}
                      height={40}
                      objectFit="cover"
                      alt="careerfly"
                    />
                  </Navbar.Brand>
                </div>
              </Link>
            </div>

            <div className="d-flex justify-content-center">
              <div className="d-flex flex-column justify-content-center">
                <div className=" d-flex gap-2 justify-content-center align-items-center">
                  <div
                    className="d-flex flex-row gap-2"
                    onClick={() => {
                      if (dropdownAnim && isMobileScreen) {
                        setDropDownAnim(false);
                        return;
                      }
                      setDropDownAnim(true);
                    }}
                    onMouseEnter={(e) => {
                      if (!isMobileScreen) {
                        setDropDownAnim(true);
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (!isMobileScreen) {
                        setDropDownAnim(false);
                      }
                    }}
                  >
                    <Button1
                      onClick={() => {
                        if (isMobileScreen) {
                          ourProgramMobileMenuRef.current.click();
                        }
                      }}
                      width="100%"
                      fontSize={isMobileScreen ? 12 : undefined}
                      title={isMobileScreen ? "" : "OUR PROGRAMS"}
                      icon={
                        <div>
                          <AiOutlineDown
                            style={{
                              transform: isMobileScreen
                                ? "rotate(90deg)"
                                : dropdownAnim
                                ? "rotate(180deg)"
                                : undefined,
                              transition: "all 0.3s ease-in-out",
                            }}
                            className="px-1 position-relative"
                            size={20}
                          />
                        </div>
                      }
                    />

                    {isMobileScreen ? (
                      <OurProgramMobile
                        ourProgramMobileMenuRef={ourProgramMobileMenuRef}
                        data={data}
                      />
                    ) : dropdownAnim ? (
                      <OurPrograms data={data} />
                    ) : undefined}
                  </div>

                  {!userToken ? (
                    <Link href="/auth">
                      <div
                        style={{
                          display: isMobileScreen ? "none" : "block",
                        }}
                      >
                        <Button1 title="LOGIN" />
                      </div>
                    </Link>
                  ) : (
                    <div>
                      {!isMobileScreen && (
                        <Link href="/student-dashboard/overview">
                          <div
                            className="mx-4"
                            style={{
                              cursor: "pointer",
                              padding: "10px",
                              borderRadius: 50,
                              backgroundColor: themeColors.primary,
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "center",
                            }}
                          >
                            <FaUser size={20} color="lightgray" />
                          </div>
                        </Link>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <Navbar.Toggle
                aria-controls={`offcanvasNavbar-expand-lg`}
                ref={navToggleRef}
                style={{
                  margin: "0 1rem",
                  display: isMobileScreen ? "none" : "block",
                }}
              />

              <OffCanvasMenu data={data} />
            </div>
          </div>
        </Navbar>
      ))}
    </>
  );
}

export default NavBar;
