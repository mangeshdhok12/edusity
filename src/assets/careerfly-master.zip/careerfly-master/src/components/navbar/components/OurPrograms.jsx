import Image from "next/image";
import Link from "next/link";
import React, { useState } from "react";
import { Container } from "react-bootstrap";
import { MdExpandLess } from "react-icons/md";
import { themeColors } from "../../../themes/colors";

const OurPrograms = ({ data }) => {
  const [currentDomainHover, setCurrentDomainHover] = useState();

  if (!currentDomainHover) {
    setCurrentDomainHover("Marketing");
  }

  return (
    <div>
      <Container
        className="d-flex justify-content-evenly"
        style={{
          borderRadius: "4px",
          position: "absolute",
          left: 0,
          right: 0,
          top: 50,
          backgroundColor: themeColors.backgroundColor,
          border: "1px solid lightgray",
          padding: "15px",
          marginTop: "3px",
          height: "600px",
          overflowY: "auto",
        }}
      >
        <div>
          <h6>
            <b>OUR DOMAINS</b>
          </h6>
          <div style={{ marginTop: "18px" }}>
            {data?.data.categories[0]?.subCategories.map((items, i) => {
              return (
                <div
                  key={i}
                  className="p-3 d-flex mb-3 align-items-center justify-content-between"
                  style={{
                    backgroundColor: "#d6a9a9",
                    color: "black",
                    borderRadius: "7px",
                    width: "350px",
                    height: "75px",
                    cursor: "pointer",
                  }}
                  onMouseEnter={(e) => {
                    setCurrentDomainHover(e.currentTarget.innerText);
                    e.currentTarget.style.backgroundColor = "#ad4a47";
                    e.currentTarget.style.color = "white";
                    e.currentTarget.style.transition = "all 0.1s ease-in-out";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = "#d6a9a9";
                    e.currentTarget.style.color = "black";
                    e.currentTarget.style.transition = "all 0.1s ease-in-out";
                  }}
                >
                  <div className="d-flex">
                    <div className="d-flex flex-column justify-content-center">
                      <Image
                        style={{
                          backgroundColor: "#F5F5F5",
                          border: "2px solid #AE4B45",
                          borderRadius: "50%",
                        }}
                        width={60}
                        height={60}
                        objectFit="contain"
                        placeholder="blur"
                        blurDataURL={items.image?.url}
                        src={items.image?.url}
                        alt="carreerfly"
                      />
                    </div>

                    <span
                      className="d-flex flex-column justify-content-center"
                      key={i}
                      style={{
                        marginLeft: "10px",
                        fontSize: "18px",
                      }}
                    >
                      <span>{items.subcategoryName}</span>
                    </span>
                  </div>

                  {currentDomainHover === items.subcategoryName ? (
                    <div>
                      <MdExpandLess
                        style={{
                          transform: "rotate(90deg)",
                        }}
                        size={20}
                      />
                    </div>
                  ) : undefined}
                </div>
              );
            })}
          </div>
        </div>

        <div className="d-flex flex-column">
          <h6>
            <b>PLACEMENT PROGRAM</b>
          </h6>
          {data?.data.courses?.map((item, i) => {
            const industryIndex = item.subCategories?.findIndex(
              (item2) => item2.categories[0]?.categoryName === "Industry"
            );

            if (
              item.chooseCourseType[0] === "Placement_Program" &&
              item.subCategories[industryIndex]?.subcategoryName ===
                currentDomainHover
            ) {
              return (
                <div key={i}>
                  <Link href={`/courses/${item.slug}`}>
                    <div
                      key={i}
                      className="d-flex"
                      style={{
                        width: "300px",
                        marginTop: "10px",
                        cursor: "pointer",
                        backgroundColor: themeColors.coursePageBg,
                        boxShadow: "1px 1px 4px 1px lightgray",
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = themeColors.primary;
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = "black";
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                    >
                      <div
                        style={{
                          backgroundColor: themeColors.coursePageBg,
                          padding: "10px",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Image
                          width={90}
                          height={90}
                          objectFit="contain"
                          border="5px solid #AE4B45"
                          placeholder="blur"
                          blurDataURL={item.image?.url}
                          src={item.image?.url}
                          alt="carreerfly"
                        />
                      </div>
                      <div className="d-flex flex-column justify-content-center">
                        <div
                          style={{
                            fontsize: "23px",
                            fontWeight: "bold",
                            marginLeft: "1px",
                          }}
                          key={i}
                        >
                          {item.title}
                        </div>

                        <div
                          style={{
                            fontsize: "12px",
                            marginLeft: "1px",
                          }}
                          key={i}
                        >
                          Duration : {item.duration}
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              );
            }
          })}
        </div>

        <div className="d-flex flex-column">
          <h6>
            <b>SKILL CERTIFICATION</b>
          </h6>
          {data?.data.courses?.map((item, i) => {
            const industryIndex = item.subCategories?.findIndex(
              (item2) => item2.categories[0]?.categoryName === "Industry"
            );

            if (
              item.chooseCourseType[0] !== "Placement_Program" &&
              item.subCategories[industryIndex]?.subcategoryName ===
                currentDomainHover
            ) {
              return (
                <div key={i}>
                  <Link href={`/courses/${item.slug}`}>
                    <div
                      key={i}
                      className=" d-flex flex-row justify-content-start align-items-center"
                      style={{
                        width: "300px",
                        marginTop: "10px",
                        cursor: "pointer",
                        boxShadow: "1px 1px 4px 1px lightgray",
                        backgroundColor: themeColors.coursePageBg,
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = themeColors.primary;
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = "black";
                        e.currentTarget.style.transition =
                          "all 0.1s ease-in-out";
                      }}
                    >
                      <div
                        style={{
                          backgroundColor: themeColors.coursePageBg,
                          padding: "10px",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }}
                      >
                        <Image
                          width={90}
                          height={90}
                          objectFit="contain"
                          border="5px solid #AE4B45"
                          placeholder="blur"
                          blurDataURL={
                            item.image?.url
                              ? item.image?.url
                              : "/assets/altCourse.jpg"
                          }
                          src={
                            item.image?.url
                              ? item.image?.url
                              : "/assets/altCourse.jpg"
                          }
                          alt="carreerfly"
                        />
                      </div>
                      <div
                        className="d-flex flex-column"
                        style={{ width: "150px" }}
                      >
                        <div
                          style={{
                            fontsize: "23px",
                            fontWeight: "bold",
                            marginLeft: "1px",
                          }}
                        >
                          {item.title}
                        </div>

                        <div
                          style={{
                            fontsize: "12px",
                            marginLeft: "1px",
                          }}
                          key={i}
                        >
                          Duration : {item.duration}
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              );
            } else {
              return <div key={i} style={{ width: "300px" }} />;
            }
          })}
        </div>
      </Container>
    </div>
  );
};

export default OurPrograms;
