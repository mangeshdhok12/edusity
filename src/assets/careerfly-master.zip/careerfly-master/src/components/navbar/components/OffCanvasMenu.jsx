import { useMediaQuery } from "@mui/material";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { Nav, Navbar, Offcanvas } from "react-bootstrap";
import { FaUser } from "react-icons/fa";
import { useStateContext } from "../../../context/StateContext";
import { themeColors } from "../../../themes/colors";
import Button from "../../button/Button";

const OffCanvasMenu = ({ data }) => {
  const links = [
    {
      title: "Book Counselling",
      url: "/career-counselling",
    },
    {
      title: "Our Placements",
      url: "/placement",
    },
    {
      title: "Our Domains",
      url: "/courses",
    },
    {
      title: "Learn More",
      url: "/learnmore",
    },
    {
      title: "Contact Us",
      url: "/contact-us",
    },
  ];

  const isMobileScreen = useMediaQuery("(max-width: 990px)");

  const { userToken } = useStateContext();

  return (
    <div>
      <Navbar.Offcanvas
        id={`nav-offcanvasNavbar-expand-expand`}
        aria-labelledby={`nav-offcanvasNavbarLabel-expand`}
        placement="end"
      >
        <Offcanvas.Header closeButton>
          <Image
            src={data?.data.globalModels[0]?.logo?.url}
            placeholder="blur"
            blurDataURL={data?.data.globalModels[0]?.logo?.url}
            width={150}
            height={60}
            objectFit="contain"
            alt="careerfly"
          />
        </Offcanvas.Header>
        <Offcanvas.Body>
          <Nav>
            <div>
              {isMobileScreen ? (
                <div className="d-flex flex-column justify-content-center">
                  {!userToken ? (
                    <div>
                      <Link href="/auth">
                        <div>
                          <Button title="Login" />
                        </div>
                      </Link>
                    </div>
                  ) : (
                    <div style={{ cursor: "pointer" }}>
                      {userToken && (
                        <Link href="/profile">
                          <div className="d-flex">
                            <FaUser size={20} />
                            <div>&nbsp;Profile</div>
                          </div>
                        </Link>
                      )}
                    </div>
                  )}
                </div>
              ) : undefined}
            </div>
            <nav style={{ lineHeight: "25px" }}>
              {links?.map((item, i) => (
                <div
                  onMouseEnter={(e) => {
                    e.currentTarget.style.color = themeColors.primary;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.color = "black";
                  }}
                  key={i}
                >
                  <Link href={item.url}>
                    <p
                      className="fs-5 fw-bold pointer-event my-2 "
                      style={{
                        cursor: "pointer",
                      }}
                    >
                      {item.title}
                    </p>
                  </Link>
                </div>
              ))}
            </nav>
          </Nav>
        </Offcanvas.Body>
      </Navbar.Offcanvas>
    </div>
  );
};

export default OffCanvasMenu;
