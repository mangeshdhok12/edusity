import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Divider,
} from "@mui/material";
import { RxCross1 } from "react-icons/rx";
import { MdExpandLess } from "react-icons/md";
import Image from "next/image";
import { useState } from "react";
import Link from "next/link";
import { themeColors } from "../../../themes/colors";

export default function OurProgramMobile({ data, ourProgramMobileMenuRef }) {
  const [state, setState] = useState({
    right: false,
  });

  const [currentDomainHover, setCurrentDomainHover] = useState();

  const [expanded, setExpanded] = useState();

  const handleChange = (panel) => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  const toggleDrawer = (anchor, open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };

  const list = (anchor) => (
    <Box sx={{ width: window.innerWidth, padding: "20px" }} role="presentation">
      <div className="d-flex justify-content-end mb-3">
        <RxCross1 size={24} onClick={toggleDrawer(anchor, false)} />
      </div>
      <Divider />

      {data?.data.categories[0]?.subCategories.map((items, i) => {
        return (
          <div key={i}>
            <Accordion
              expanded={expanded === i}
              onChange={handleChange(i)}
              className="my-2"
            >
              <AccordionSummary
                onClick={(e) => {
                  if (e.currentTarget.innerText === currentDomainHover) {
                    setCurrentDomainHover(null);
                    return;
                  }
                  setCurrentDomainHover(e.currentTarget.innerText);
                }}
                sx={{ backgroundColor: "#d6a9a9", borderRadius: "7px" }}
                expandIcon={
                  <MdExpandLess
                    size={25}
                    style={{ transform: "rotate(180deg)" }}
                  />
                }
                aria-controls={`panel${i}a-content`}
                id={`panel${i}a-header`}
              >
                <div
                  className="d-flex mb-3 align-items-center justify-content-between"
                  style={{
                    color: "black",
                    width: "100%",
                    cursor: "pointer",
                  }}
                >
                  <div className="d-flex">
                    <div className="d-flex flex-column justify-content-center">
                      <Image
                        style={{
                          backgroundColor: "#F5F5F5",
                          border: "2px solid #AE4B45",
                          borderRadius: "50%",
                        }}
                        width={60}
                        height={60}
                        objectFit="contain"
                        placeholder="blur"
                        blurDataURL={items.image?.url}
                        src={items.image?.url}
                        alt="carreerfly"
                      />
                    </div>

                    <span
                      className="d-flex flex-column justify-content-center"
                      style={{
                        marginLeft: "10px",
                        fontSize: "18px",
                      }}
                    >
                      <span>{items.subcategoryName}</span>
                    </span>
                  </div>
                </div>
              </AccordionSummary>
              <AccordionDetails>
                <div className="d-flex flex-column mt-4">
                  <h6>
                    <b>PLACEMENT PROGRAM</b>
                  </h6>
                  {data?.data.courses?.map((item, i) => {
                    const industryIndex = item.subCategories?.findIndex(
                      (item2) =>
                        item2.categories[0]?.categoryName === "Industry"
                    );

                    if (
                      item.chooseCourseType[0] === "Placement_Program" &&
                      item.subCategories[industryIndex]?.subcategoryName ===
                        currentDomainHover
                    ) {
                      return (
                        <div>
                          <Link href={`/courses/${item.slug}`}>
                            <div
                              className="d-flex"
                              style={{
                                width: "100%",
                                marginTop: "10px",
                                cursor: "pointer",
                                backgroundColor: themeColors.coursePageBg,
                                boxShadow: "1px 1px 4px 1px lightgray",
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.color =
                                  themeColors.primary;
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.color = "black";
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                            >
                              <div
                                style={{
                                  backgroundColor: themeColors.coursePageBg,
                                  padding: "10px",
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                }}
                              >
                                <Image
                                  width={90}
                                  height={90}
                                  objectFit="contain"
                                  border="5px solid #AE4B45"
                                  placeholder="blur"
                                  blurDataURL={item.image?.url}
                                  src={item.image?.url}
                                  alt="carreerfly"
                                />
                              </div>
                              <div className="d-flex flex-column justify-content-center">
                                <div
                                  style={{
                                    fontsize: "25px",
                                    fontWeight: "bold",
                                    marginLeft: "5px",
                                  }}
                                >
                                  {item.title}
                                </div>

                                <div
                                  style={{
                                    fontsize: "12px",
                                    marginLeft: "5px",
                                  }}
                                >
                                  Duration : {item.duration}
                                </div>
                              </div>
                            </div>
                          </Link>
                        </div>
                      );
                    }
                  })}
                </div>

                <div className="d-flex flex-column mt-4">
                  <h6>
                    <b>SKILL CERTIFICATION</b>
                  </h6>
                  {data?.data.courses?.map((item, i) => {
                    const industryIndex = item.subCategories?.findIndex(
                      (item2) =>
                        item2.categories[0]?.categoryName === "Industry"
                    );

                    if (
                      item.chooseCourseType[0] !== "Placement_Program" &&
                      item.subCategories[industryIndex]?.subcategoryName ===
                        currentDomainHover
                    ) {
                      return (
                        <div>
                          <Link href={`/courses/${item.slug}`}>
                            <div
                              className=" d-flex flex-row justify-content-start align-items-center"
                              style={{
                                width: "100%",
                                marginTop: "10px",
                                cursor: "pointer",
                                boxShadow: "1px 1px 4px 1px lightgray",
                                backgroundColor: themeColors.coursePageBg,
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.color =
                                  themeColors.primary;
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.color = "black";
                                e.currentTarget.style.transition =
                                  "all 0.1s ease-in-out";
                              }}
                            >
                              <div
                                style={{
                                  backgroundColor: themeColors.coursePageBg,
                                  padding: "10px",
                                  display: "flex",
                                  justifyContent: "center",
                                  alignItems: "center",
                                }}
                              >
                                <Image
                                  width={90}
                                  height={90}
                                  border="5px solid #AE4B45"
                                  placeholder="blur"
                                  objectFit="contain"
                                  blurDataURL={
                                    item.image?.url
                                      ? item.image?.url
                                      : "/assets/altCourse.jpg"
                                  }
                                  src={
                                    item.image?.url
                                      ? item.image?.url
                                      : "/assets/altCourse.jpg"
                                  }
                                  alt="carreerfly"
                                />
                              </div>
                              <div
                                className="d-flex flex-column"
                                style={{ width: "150px" }}
                              >
                                <div
                                  style={{
                                    fontsize: "25px",
                                    fontWeight: "bold",
                                    marginLeft: "5px",
                                  }}
                                >
                                  {item.title}
                                </div>

                                <div
                                  style={{
                                    fontsize: "12px",
                                    marginLeft: "5px",
                                  }}
                                >
                                  Duration : {item.duration}
                                </div>
                              </div>
                            </div>
                          </Link>
                        </div>
                      );
                    } else {
                      return <div style={{ width: "100%" }} />;
                    }
                  })}
                </div>
              </AccordionDetails>
            </Accordion>
          </div>
        );
      })}
    </Box>
  );

  return (
    <div>
      {["right"].map((anchor) => (
        <React.Fragment key={anchor}>
          <Button
            style={{ display: "none" }}
            ref={ourProgramMobileMenuRef}
            onClick={toggleDrawer(anchor, true)}
          >
            {anchor}
          </Button>
          <Drawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
          >
            {list(anchor)}
          </Drawer>
        </React.Fragment>
      ))}
    </div>
  );
}
