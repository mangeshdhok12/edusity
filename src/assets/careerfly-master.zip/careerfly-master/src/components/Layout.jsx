import { gql } from "@apollo/client";
import { useMediaQuery } from "@mui/material";
import dynamic from "next/dynamic.js";
import Head from "next/head.js";
import { useRouter } from "next/router.js";
import Script from "next/script.js";
import React, { Suspense, useEffect, useState } from "react";
import { useStateContext } from "../context/StateContext.jsx";
import apolloClient from "../lib/appoloClient.js";
import Sidebar from "../screens/studentDashboard/components/Sidebar.jsx";
import TrainerSidebar from "../screens/trainerDashboard/components/TrainerSidebar.jsx";
import Quote, { Modal } from "./Quote";
import Whatsapp from "./Whatsapp.jsx";

const Layout = ({ children }) => {
  const DynamicNavBar = dynamic(() => import("./navbar/NavBar"));

  const DynamicFooter = dynamic(() => import("./footer/Footer"));

  const {
    toggle,
    userToken,
    quoteOpen,
    setUserToken,
    setUserData,
    currentModuleTest,
    setCurrentModuleTest,
    userData,
    setStudentEnrolledData,
    enrolledStudents,
    enrolledStudentData,
  } = useStateContext();

  const [data, setData] = useState();
  const [isEnrolled, setIsEnrolled] = useState();

  const router = useRouter();

  const isMobileScreen = useMediaQuery("(max-width: 990px)");

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem("CareerFlyUser"));

    if (!user) {
      return;
    }

    setUserData({
      name: user.user.providerData[0]?.displayName,
      email: user.user.providerData[0]?.email,
      phone: user.user.providerData[0]?.phoneNumber,
      imgUrl: user.user.providerData[0]?.photoURL,
    });

    setUserToken(user.user.stsTokenManager.accessToken);
  }, []);

  useEffect(() => {
    apolloClient
      .query({
        query: gql`
          query MyQuery {
            globalModels {
              logo {
                url
              }
              curriculum {
                url
              }
            }
            categories {
              categoryName
              subCategories {
                subcategoryName
                image {
                  url
                }
              }
            }
            courses(first: 1000) {
              title
              slug
              subCategories(first: 100) {
                categories {
                  categoryName
                }
                image {
                  url
                }
                subcategoryName
              }
              duration
              image {
                url
              }
              chooseCourseType
            }
            panels {
              admin {
                enrolledStudents {
                  arrayOfType2 {
                    text1
                    text2
                  }
                }
              }
            }
          }
        `,
      })
      .then((resData) => {
        setData(resData);
      });
  }, [setData]);

  const routes = [
    "overview",
    "recorded-videos",
    "resume",
    "trends",
    "certificate",
    `test/[test]`,
    "testPerformance",
    "our-trainers",
    "live",
    "hiring-partners",
    "open-position",
    "global-updates",
    "placement",
    "analytics",
  ];

  const trainerRoutes = ["overview", "videos", "classes", "privacy", "social"];

  if (!data && !userData) {
    return;
  }
  //  console.log("...",data)
  const enrolledStudent =
    data?.data?.panels[0]?.admin?.enrolledStudents[0]?.arrayOfType2?.find(
      (item) => item.text1 === userData.email
    );

  useEffect(() => {
    if (enrolledStudent?.text1 === userData.email) {
      setStudentEnrolledData(enrolledStudent);
      console.log(enrolledStudent, "vvvv");
      setIsEnrolled(true);
    } else {
      setIsEnrolled(true);
    }
  }, [enrolledStudent, setStudentEnrolledData, setIsEnrolled, userData]);
  console.log(enrolledStudentData, "hhg");
  return (
    <div>
      <Head>
        <title>CareerFly</title>
        <link rel="icon" href="/logo.png" />
      </Head>
      <Script
        src="https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver"
        strategy="beforeInteractive"
      />
      <Suspense fallback={`Loading...`}>
        <DynamicNavBar data={data} userToken={userToken} />
      </Suspense>

      <div className="d-flex">
        {routes?.map((route, i) => (
          <div key={i}>
            {router.pathname === `/student-dashboard/${route}` &&
            !isMobileScreen ? (
              <Sidebar />
            ) : undefined}
          </div>
        ))}

        {trainerRoutes?.map((route, i) => (
          <div key={i}>
            {router.pathname === `/trainer-dashboard/${route}` &&
            !isMobileScreen ? (
              <TrainerSidebar />
            ) : undefined}
          </div>
        ))}

        {toggle && (
          <>
            {routes?.map((route, i) => (
              <div key={i}>
                {router.pathname === `/student-dashboard/${route}` &&
                isMobileScreen ? (
                  <div
                    className=""
                    style={{
                      position: "fixed",
                      zIndex: "2",
                      backgroundColor: "white",
                      overflowY: "auto",
                      height: "100vh",
                    }}
                  >
                    {" "}
                    <Sidebar />
                  </div>
                ) : undefined}
              </div>
            ))}
          </>
        )}

        {toggle && (
          <>
            {trainerRoutes?.map((route, i) => (
              <div key={i}>
                {router.pathname === `/trainer-dashboard/${route}` &&
                isMobileScreen ? (
                  <TrainerSidebar />
                ) : undefined}
              </div>
            ))}
          </>
        )}
        <div className="w-100" style={{ overflow: toggle ? "none" : "auto" }}>
          {children}
        </div>
      </div>
      <Whatsapp />
      <Quote />
      {quoteOpen && <Modal />}
      <Suspense fallback={`Loading..`}>
        <DynamicFooter />
      </Suspense>
    </div>
  );
};

export default Layout;
