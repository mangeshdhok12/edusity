import Image from "next/image";
import Link from "next/link";
import React from "react";
import { themeColors } from "../../themes/colors";
import { useMediaQuery } from "@mui/material";

import {
  AiFillFacebook,
  AiFillInstagram,
  AiFillLinkedin,
  AiFillTwitterSquare,
  AiFillYoutube,
} from "react-icons/ai";
import { MdPlace } from "react-icons/md";
import { Container } from "react-bootstrap";

const Footer = () => {
  const footerIcons = [
    {
      id: 1,
      icon: AiFillFacebook,
      link: "https://m.facebook.com/careerflyofficial/",
    },
    {
      id: 2,
      icon: AiFillInstagram,
      link: "https://instagram.com/careerflyofficial?igshid=YmMyMTA2M2Y=/",
    },
    {
      id: 3,
      icon: MdPlace,
      link: "https://g.co/kgs/FuQng1/",
    },
    {
      id: 4,
      icon: AiFillLinkedin,
      link: "https://www.linkedin.com/company/careerfly/?original_referer=https%3A%2F%2Fwww%2Egoogle%2Ecom%2F&originalSubdomain=in.co/kgs/FuQng1/",
    },
    {
      id: 5,
      icon: AiFillTwitterSquare,
      link: "https://twitter.com/Careerflytweets",
    },
    {
      id: 6,
      icon: AiFillYoutube,
      link: "https://www.youtube.com/@careerflyofficial",
    },
  ];

  const policies = {
    id: 3,
    title: "Policy",
    subcategories: [
      {
        id: 1,
        title: "Refund policy",
        link: "/refundpolicy",
      },
      {
        id: 2,
        title: "Privacy policy",
        link: "/privacypolicy",
      },
      {
        id: 3,
        title: "Terms & conditions",
        link: "/terms&condition",
      },
    ],
  };

  const innerList = [
    {
      id: 1,
      title: "",
      Lists: [
        {
          id: 1,
          title: "Industry",
          subLists: [
            {
              id: 1,
              title: "HR",
            },
            {
              id: 2,
              title: "Marketing",
            },
            {
              id: 3,
              title: "Programming",
            },
            {
              id: 4,
              title: "BPO",
            },
            {
              id: 5,
              title: "Sales",
            },
            {
              id: 6,
              title: "Finance",
            },
            {
              id: 7,
              title: "Software",
            },
          ],
        },
        {
          id: 2,
          title: "Job Type",
          subLists: [
            {
              id: 1,
              title: "Work from Home",
            },
            {
              id: 2,
              title: "Onsite",
            },
            {
              id: 3,
              title: "Hybrid",
            },
            {
              id: 4,
              title: "No fixed hours",
            },
            {
              id: 5,
              title: "Part time",
            },
            {
              id: 6,
              title: "Freelancing",
            },
            {
              id: 7,
              title: "Enterepreneurship",
            },

            {
              id: 8,
              title: "Desk job",
            },
          ],
        },
        {
          id: 3,
          title: "Working Days",
          subLists: [
            {
              id: 1,
              title: "5 Days",
            },
            {
              id: 2,
              title: "6 Days",
            },
            {
              id: 3,
              title: "5.5 Days",
            },
          ],
        },
        {
          id: 4,
          title: "Nature of Job",
          subLists: [
            {
              id: 1,
              title: "Technical",
            },
            {
              id: 2,
              title: "Functional",
            },
            {
              id: 3,
              title: "Techno functional",
            },
            {
              id: 4,
              title: "Field Job",
            },
            {
              id: 5,
              title: "Target Job",
            },
          ],
        },
        {
          id: 5,
          title: "Shift",
          subLists: [
            {
              id: 1,
              title: "India Domestic (09:00AM-06:00PM)",
            },
            {
              id: 2,
              title: "US Night (06:30PM-03:30AM)",
            },
          ],
        },
        {
          id: 6,
          title: "About us",
          subLists: [
            {
              id: 1,
              title: "Who we are",
              link: "/learnmore",
            },
            {
              id: 2,
              title: "Book counselling",
              link: "/career-counselling",
            },
          ],
        },
        {
          id: 7,
          title: "Support",
          subLists: [
            {
              id: 1,
              title: "Get in touch",
              link: "/get-in-touch",
            },
            {
              id: 2,
              title: "Contact us",
              link: "/contact-us",
            },
          ],
        },
      ],
    },
  ];

  const isMobileScreen = useMediaQuery("(max-width: 990px)");

  function openNewWindow(url) {
    window.open(url);
  }

  return (
    <div>
      <div
        className="py-5"
        style={{
          backgroundColor: themeColors.backgroundColor,
        }}
      >
        <div className="d-flex justify-content-center">
          <Container
            style={{
              display: "flex",
              flexDirection: isMobileScreen ? "column" : "row",
              justifyContent: "space-evenly",
              alignItems: isMobileScreen ? "center" : undefined,
            }}
          >
            <div>
              <Link href="/">
                <div>
                  <Image
                    src="/careerflyLogo.jpeg"
                    blurDataURL="/careerflyLogo.jpeg"
                    width={200}
                    height={200}
                    objectFit="contain"
                    alt="careerfly"
                  />
                </div>
              </Link>
              <p className="text-center mt-3">Follow Us</p>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <div className="d-flex">
                  {footerIcons?.map((val, i) => {
                    return (
                      <div
                        onClick={() => openNewWindow(val?.link)}
                        key={i}
                        style={{ cursor: "pointer" }}
                        className="mx-1"
                      >
                        <val.icon fontSize={20} />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className={isMobileScreen ? "mt-4 mx-2" : "ms-5"}>
              {innerList?.map((val, i) => (
                <div key={i}>
                  <h5>{val?.title}</h5>
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "wrap",
                      fontSize: "14px",
                    }}
                  >
                    {val?.Lists?.map((innerList, i) => (
                      <span
                        className={isMobileScreen ? "mt-4" : undefined}
                        style={{
                          width: "170px",
                          cursor: "pointer",
                          fontSize: "15px",
                        }}
                        key={i}
                      >
                        <div
                          style={{
                            fontWeight: "bold",
                          }}
                        >
                          {innerList?.title}
                        </div>
                        {innerList?.subLists?.map((val, i) => {
                          return (
                            <div
                              key={i}
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                margin: "12px 16px 12px 0",
                              }}
                            >
                              <span key={i}>
                                <div>
                                  {val.link ? (
                                    <Link
                                      style={{
                                        cursor: "pointer",
                                        fontSize: "14px",
                                      }}
                                      href={val.link}
                                    >
                                      <li>{val?.title}</li>
                                    </Link>
                                  ) : (
                                    <li>{val?.title}</li>
                                  )}
                                </div>
                              </span>
                            </div>
                          );
                        })}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Container>
        </div>
        <div className="d-flex justify-content-center flex-wrap mt-4 gap-3">
          {policies.subcategories?.map((item, i) => (
            <Link key={i} href={item.link}>
              <div style={{ cursor: "pointer" }}>{item.title}</div>
            </Link>
          ))}
        </div>
      </div>
      <p
        style={{ backgroundColor: themeColors.backgroundColor }}
        className="mb-0 text-center"
      >
        © 2023 Careerfly. All rights reserved.
      </p>
    </div>
  );
};

export default Footer;
