import { useMediaQuery } from "@mui/material";
import React, { useState } from "react";
import { themeColors } from "../../themes/colors";

function Button({
  iconButton = false,
  bgColor = themeColors?.primary,
  title = iconButton ? "" : "tex here",
  fontWeight = "normal",
  color = themeColors?.textLight,
  onClick = () => {},
  icon = "",
  id,
  marginTop,
  marginBottom,
  marginLeft,
  marginRight,
  padding = "",
  width,
  IsCenter = false,
  border = themeColors?.primary,
  fontSize,
  borderRadius,
}) {
  const isMobileScreen = useMediaQuery("(max-width: 767px)");

  return (
    <div>
      {!iconButton ? (
        <button
          type="button"
          className="btn"
          onMouseEnter={(e) => {
            if (isMobileScreen) {
              return;
            }
            e.currentTarget.style.backgroundColor =
              color === "#efefef" ? "white" : color;
            e.currentTarget.style.color = bgColor;
            e.currentTarget.style.transition = "all 0.1s ease-in-out";
          }}
          onMouseLeave={(e) => {
            if (isMobileScreen) {
              return;
            }
            e.currentTarget.style.backgroundColor = bgColor;
            e.currentTarget.style.color = color;
            e.currentTarget.style.transition = "all 0.1s ease-in-out";
          }}
          style={{
            width: width,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: bgColor,
            fontWeight: fontWeight,
            border: `1px solid ${border}`,
            color: color,
            marginTop: marginTop,
            marginBottom: marginBottom,
            marginLeft: marginLeft,
            marginRight: marginRight,
            padding: padding,
            margin: IsCenter ? "0 auto" : null,
            fontSize: fontSize,
            borderRadius: borderRadius,
            whiteSpace:"nowrap"

          }}
          onClick={onClick}
          id={id}
        >
          <div 
            className={
              title === "VIEW MORE" ? "d-flex" : "d-flex flex-row-reverse"
            }
          >
            <div className="d-flex flex-column justify-content-center">
              {title}
            </div>
            <div className="d-flex flex-column justify-content-center mx-1">
              {!icon ? undefined : icon}
            </div>
          </div>
        </button>
      ) : (
        <button
          type="button"
          className="btn"
          style={{
            width: width,
            backgroundColor: bgColor,
            fontWeight: fontWeight,
            fontSize: fontSize,
            color: color,
            marginTop: marginTop,
            marginBottom: marginBottom,
            marginLeft: marginLeft,
            marginRight: marginRight,
            textAlign: IsCenter ? "center" : null,
            border: `1px solid ${border}`,
            whiteSpace:"nowrap"
          }}
          onClick={onClick}
          id={id}
        >
          {!icon ? <></> : icon}&nbsp;{title}
        </button>
      )}
    </div>
  );
}

export default Button;
