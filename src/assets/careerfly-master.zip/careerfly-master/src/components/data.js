export const data = [
  {
    color: "#EEDD82",
    img: "/assets/Screenshot_2022-10-26_at_11.39 1.png",
    course: "Graphic designing",
  },
  {
    color: "#eea782",
    img: "/assets/Screenshot_2022-10-26_at_11.40 2.png",
    course: "Web dev",
  },
  {
    color: "#8293ee",
    img: "/assets/Screenshot_2022-10-26_at_11.35 1.png",
    course: "DSA",
  },
  {
    color: "#C8F526",
    img: "/assets/Screenshot_2022-10-31_at_7.04 1.png",
    course: "Data analyst",
  },
  {
    color: "#00CED1",
    img: "/assets/Screenshot_2022-10-31_at_7.00 1.png",
    course: "Business analytics",
  },
  {
    color: "#F4ADAE",
    img: "/assets/Screenshot_2022-10-26_at_11.37 1.png",
    course: "Android studio",
  },
];
export const analyticsList = [
{
  title : "Marks VS Test date"
},
{
  title: "Topicwise Performance"
},
{
  title: "Class performance"
},
{
  title: "Test History"
},
{
  title: "Self improvement index"
}
];

export const analyticsHeading = [
  {
    mainheading:"Analytics", 
  },
  {
    selfImprovHeading:"You have scored x% more/less than the previous test keep learning and gaining knowledge"
  }

]