export const fonts = {
  heading1: "48px",
  heading2: "28px",
  heading3: "14px",
};
