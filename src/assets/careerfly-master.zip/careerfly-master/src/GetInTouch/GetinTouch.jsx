import React, { useEffect, useState } from "react";
import { themeColors } from "../themes/colors";
import {
  Button,
  FormControl,
  FormControlLabel,
  FormGroup,
  InputLabel,
  MenuItem,
  Select,
  useMediaQuery,
  toggleTheme,
} from "@mui/material";
import { RiCustomerService2Line } from "react-icons/ri";
import { useRouter } from "next/router";
import TextField from "@mui/material/TextField";
import { makeStyles } from "@material-ui/core/styles";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { toast, ToastContainer } from "react-toastify";
import { Box, Checkbox } from "@mui/material";
import Image from "next/image";
import { useStateContext } from "../context/StateContext";
import { RxCross1 } from "react-icons/rx";
import Link from "next/link";
import states from "../content/states.json";
import { Container } from "react-bootstrap";

const GetinTouch = () => {
  //   const { setQuoteOpen } = useStateContext();
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [terms, setTerms] = useState(false);
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [response, setResponse] = useState(false);
  const [disabled, setDisabled] = useState(false);

  const isMobileScreen = useMediaQuery("(max-width: 765px)");

  const {
    tcClicked,
    settcClicked,
    setQuoteOpen,
    quoteOpen,
    ccd,
    routeFrom,
    course,
    setRouteFrom,
    setCcd,
  } = useStateContext();

  useEffect(() => {
    if (router.pathname === "/terms&condition" && tcClicked) {
      setQuoteOpen(false);
    }
  }, [router, tcClicked, setQuoteOpen]);

  const date = new Date();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (fullName && email && phone.length === 10 && terms) {
      setDisabled(true);
      setTimeout(() => setDisabled(false), 3000);
      const form = {
        name: fullName,
        email: email,
        phone: phone,
      };
      const response = await fetch("/api/sumbit", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "content-Type": "application/json",
        },
        body: JSON.stringify(form),
      });
      const content = await response.json();

      setFullName("");
      setEmail("");
      setPhone();

      if (ccd) {
        open(ccd, "_blank");
      }
      toast.success("Messege Sent", { theme: "colored" });
      setResponse(true);
    } else if (error === "tcError") {
      toast.warning("Please accept terms & conditions", { theme: "colored" });
    } else {
      toast.error("Some Fields are missing/invalid", { theme: "colored" });
    }
  };

  const handleChangeState = (event) => {
    setState(event.target.value);
  };

  const handleChangeCity = (event) => {
    setCity(event.target.value);
  };

  const useStyles = makeStyles((theme) => ({
    formControl: {
      margin: theme.spacing(1),
      minWidth: 120,
    },
    selectEmpty: {
      marginTop: theme.spacing(2),
    },
    menuPaper: {
      height: 208,
    },
  }));

  const styleClasses = useStyles();

  return (
    <>
      {response ? (
        <Box
          sx={{
            width: isMobileScreen ? "100%" : "100%",
            height: "100%",
            display: "flex",
            flexDirection: isMobileScreen ? "column-reverse" : "row",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div className="mt-3">
            <div>
              <h3 className="fs-5">
                We Appreciate you sharing your Information with us
              </h3>
              <p className="fs-6">
                Your Placement Buddy will contact you in an hour !!!
              </p>
            </div>
            <div className="d-flex justify-content-center align-items-center w-100">
              <div className="d-flex flex-column  align-items-center mt-4 ">
                <Link href={"https://wa.me/8273466595"}>
                  <div
                    className="rounded-2 d-flex justify-content-start align-items-center my-3"
                    style={{
                      backgroundColor: themeColors.primary,
                      paddingLeft: "1rem",
                      cursor: "pointer",
                    }}
                  >
                    <Image
                      src="/whatsappIcon.svg"
                      width={30}
                      height={30}
                      alt="CareerFly"
                      placeholder="blur"
                      blurDataURL="./whatsapp.png"
                    />
                    <p
                      className="m-0 fs-6 px-3 py-2"
                      style={{ color: themeColors.white }}
                    >
                      Connect with us
                    </p>
                  </div>
                </Link>
                <Link href={"tel:8273466595"}>
                  <div
                    className="rounded-2 d-flex justify-content-start align-items-center my-3"
                    style={{
                      backgroundColor: themeColors.primary,
                      paddingLeft: "1rem",
                      cursor: "pointer",
                    }}
                  >
                    <Image
                      src="/callIcon.png"
                      width={30}
                      height={30}
                      alt="CareerFly"
                      placeholder="blur"
                      blurDataURL="./whatsapp.png"
                    />
                    <p
                      className="m-0 fs-6 py-2 px-3"
                      style={{ color: themeColors.white }}
                    >
                      Call us on +91 8273466595
                    </p>
                  </div>
                </Link>
              </div>
            </div>
          </div>
        </Box>
      ) : (
        <div
          className="w-100 d-flex justify-content-start align-items-center"
          style={{
            flexDirection: isMobileScreen ? "column" : "row",
            height: isMobileScreen ? "100%" : "100vh",
          }}
        >
          <div
            style={{
              width: isMobileScreen ? "100%" : "60%",
              display: "flex",
              justifyContent: "start",
              flexDirection: "column",
              columnGap: "10px",
              marginBottom: "1rem",
              paddingTop: "100px",
            }}
          >
            <Image
              className="mt-2"
              src="/assets/form image.jpg"
              width={isMobileScreen ? "250" : "450"}
              height={isMobileScreen ? "200" : "370"}
              alt="careerfly"
              placeholder="blur"
              blurDataURL="/assets/form image.jpg"
              objectFit="contain"
            />
            <h2 className="text-center mt-2 mb-1" style={{ fontWeight: "800" }}>
              GET UPTO 100%
            </h2>
            <h2 className="text-center mb-1" style={{ fontWeight: "800" }}>
              Scholarship
            </h2>
            <p className="text-center mb-1 ">
              Enrol in our placement & certification programs.
            </p>
          </div>
          <div
            className="d-flex justify-content-center align-items-center"
            style={{
              backgroundColor: themeColors.primary,
              color: "white",
              width: isMobileScreen ? "100%" : "40%",
              height: isMobileScreen ? "100%" : "100vh",
            }}
          >
            <div
              style={{
                paddingTop: isMobileScreen ? "30px" : "100px",
                paddingBottom: "50px",
                paddingLeft: "30px",
                paddingRight: "30px",
              }}
            >
              <h2 className="text-center mb-5" style={{ fontWeight: "800" }}>
                Check Your Eligibility
              </h2>
              <TextField
                required={true}
                InputLabelProps={{
                  style: {
                    color: "white",
                  },
                }}
                inputProps={{
                  style: {
                    color: "white",
                  },
                }}
                sx={{
                  mb: 1,
                  "& label.Mui-focused": {
                    color: "white",
                  },
                  "& .MuiInput-underline:after": {
                    borderBottomColor: "white",
                  },
                  "& .MuiOutlinedInput-root": {
                    "& fieldset": {
                      borderColor: "white",
                    },
                    "&:hover fieldset": {
                      borderColor: "white",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "white",
                    },
                  },
                }}
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                id="name"
                label="Full Name"
                name="Full Name"
                type="text"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
              />
              <TextField
                required
                InputLabelProps={{
                  style: {
                    color: "white",
                  },
                }}
                inputProps={{
                  style: {
                    color: "white",
                  },
                }}
                sx={{
                  "& label.Mui-focused": {
                    color: "white",
                  },
                  "& .MuiInput-underline:after": {
                    borderBottomColor: "white",
                  },
                  "& .MuiOutlinedInput-root": {
                    "& fieldset": {
                      borderColor: "white",
                    },
                    "&:hover fieldset": {
                      borderColor: "white",
                    },
                    "&.Mui-focused fieldset": {
                      borderColor: "white",
                    },
                  },
                }}
                autoFocus
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                id="email"
                label="Email Address"
                name="Email Address"
                type="email"
                fullWidth
                variant="outlined"
                size="small"
                color="warning"
              />
              <Box display="flex" gap="10px">
                <TextField
                  InputLabelProps={{
                    style: {
                      color: "white",
                    },
                  }}
                  inputProps={{
                    style: {
                      color: "white",
                    },
                  }}
                  sx={{
                    width: "162px",
                    "& label.Mui-focused": {
                      color: "white",
                    },
                    "& .MuiInput-underline:after": {
                      borderBottomColor: "white",
                    },
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white",
                      },
                      "&:hover fieldset": {
                        borderColor: "white",
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white",
                      },
                    },
                  }}
                  margin="dense"
                  value="India (+91)"
                  type="text"
                  variant="outlined"
                  size="small"
                />
                <TextField
                  required
                  InputLabelProps={{
                    style: {
                      color: "white",
                    },
                  }}
                  inputProps={{
                    type: "Number",
                    inputMode: "numeric",
                    pattern: "[0-9]*",
                    style: {
                      color: "white",
                    },
                  }}
                  sx={{
                    "& label.Mui-focused": {
                      color: "white",
                    },
                    "& .MuiInput-underline:after": {
                      borderBottomColor: "white",
                    },
                    "& .MuiOutlinedInput-root": {
                      "& fieldset": {
                        borderColor: "white",
                      },
                      "&:hover fieldset": {
                        borderColor: "white",
                      },
                      "&.Mui-focused fieldset": {
                        borderColor: "white",
                      },
                    },
                  }}
                  autoFocus
                  margin="dense"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  id="phoneNumber"
                  label="Mobile Number"
                  name="Mobile Number"
                  type="text"
                  fullWidth
                  variant="outlined"
                  size="small"
                  color="warning"
                />
              </Box>

              <FormGroup>
                <FormControlLabel
                  control={
                    <Checkbox
                      iconStyle={{ fill: "white" }}
                      style={{
                        color: "White",
                      }}
                    />
                  }
                  label={
                    <div
                      style={{
                        minWidth: 244,
                        minHeight: 42,
                        display: "flex",
                        alignItems: "center",
                        color: "white",
                      }}
                    >
                      <span
                        style={{
                          minWidth: 60,
                          display: "flex",
                          fontSize: 11,
                          color: "white",
                        }}
                      >
                        I accept the &nbsp;
                      </span>
                      <div
                        onClick={() => settcClicked(true)}
                        style={{
                          color: "white",
                          width: 140,
                          display: "flex",
                          alignItems: "center",
                          fontSize: 10,
                        }}
                      >
                        <a
                          target="_blank"
                          style={{ color: "white" }}
                          href="/terms&condition"
                        >
                          Terms & Conditions
                        </a>
                      </div>
                    </div>
                  }
                  onChange={(e) => {
                    if (e.currentTarget.checked === true) {
                      setTerms(true);
                    } else {
                      setTerms(false);
                      setError("tcError");
                    }
                  }}
                />
              </FormGroup>
              <ToastContainer />
              {error === true ? (
                <p style={{ color: themeColors.error }}>
                  Some Fields are missing
                </p>
              ) : undefined}
              <div
                onClick={handleSubmit}
                className="d-flex justify-content-center align-items-center"
              >
                {disabled ? null : (
                  <Button
                    style={{
                      marginBottom: "5px",
                      fontSize: 20,
                      fontWeight: 700,
                      backgroundColor: "white",
                      color: themeColors.primary,
                    }}
                    fullWidth
                  >
                    SUBMIT
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default GetinTouch;
