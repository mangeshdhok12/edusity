import { useEffect } from "react";
import { createContext, useContext, useState, useRef } from "react";

const Context = createContext();

export const StateContext = ({ children }) => {
  const initialOrderData = {
    courseTitle: "",
    coursePrice: "",
    courseRating: "",
    couponDiscount: "",
    courseDescription: "",
    courseImage: "",
    courseProgram: "",
    coursePrice: "",
    courseMRP: "",
    courseDiscount: "",
    courseBenifits: "",
    couponCode: "",
    couponDiscount: "",
    date: "",
    time: "",
  };
  const [orderData, setOrderData] = useState(initialOrderData);
  const [userToken, setUserToken] = useState();
  const [userId, setUserId] = useState();
  const [openLogin, setOpenLogin] = useState(false);
  const [openRegister, setOpenRegister] = useState(false);
  const [contactUsModal, setContactUsModal] = useState(false);
  const [quoteOpen, setQuoteOpen] = useState();
  const [quoteClose, setQuoteClose] = useState();
  const [tcClicked, settcClicked] = useState();
  const [cc, setCc] = useState();
  const [googleLogin, setGoogleLogin] = useState(false);
  const [ccd, setCcd] = useState();
  const curriculumRef = useRef();
  const [routeFrom, setRouteFrom] = useState("Get in touch");
  const [course, setCourse] = useState();
  const [currentModuleTest, setCurrentModuleTest] = useState();
  const [studentEnrolledData, setStudentEnrolledData] = useState();
  const [toggle, setToggle] = useState(false);
  const [trainerId, setTrainerId] = useState("");

  const initialUserData = {
    name: "",
    email: "",
    imgUrl: "",
    phone: "",
    address: "",
    enrolledCourses: [],
  };

  const [userData, setUserData] = useState(initialUserData);

  return (
    <Context.Provider
      value={{
        toggle,
        setToggle,
        course,
        setCourse,
        routeFrom,
        setRouteFrom,
        tcClicked,
        settcClicked,
        userToken,
        setUserToken,
        userId,
        setUserId,
        openLogin,
        setOpenLogin,
        openRegister,
        setOpenRegister,
        contactUsModal,
        setContactUsModal,
        quoteOpen,
        setQuoteOpen,
        quoteClose,
        setQuoteClose,
        userData,
        setUserData,
        cc,
        setCc,
        orderData,
        setOrderData,
        googleLogin,
        setGoogleLogin,
        curriculumRef,
        ccd,
        setCcd,
        currentModuleTest,
        setCurrentModuleTest,
        studentEnrolledData,
        setStudentEnrolledData,
        trainerId,
        setTrainerId,
      }}
    >
      {children}
    </Context.Provider>
  );
};

export const useStateContext = () => useContext(Context);
