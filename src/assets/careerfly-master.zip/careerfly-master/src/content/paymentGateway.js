import banks from "../content/banks.json";

export const paymentGateway = {
  contactDetails: {
    email: "",
    contact: "",
  },
  paymentOptions: {
    title:['Card','Net Banking', 'Wallets', 'UPI'],
    options: {
        card: {
          cardNumber: "",
          name: "",
          expiry: "",
          cvv: "",
        },
        netBanking: {
          topBanks: [
            {
              title:"SBI",
              image:"/paymentAssets/sbi.png"
            },
            {
              title:"HDFC",
              image:"/paymentAssets/hdfc.png"
            },
            {
              title:"ICICI",
              image:"/paymentAssets/icici.png"
            },
            {
              title:"AXIS",
              image:"/paymentAssets/axis.png"
            }

          ],

          allBanks: banks,
        },
        wallets: [
          {
            title:"paytm",
            image:"/paymentAssets/paytm.png"
          },
          {
            title:"amazonPay",
            image:"/paymentAssets/amazon.png"
          },
          {
            title:"mobiKwik",
            image:"/paymentAssets/mobi.png"
          }, 
          {
            title:"phonePe",
            image:"/paymentAssets/phonePe.svg"
          },
        ], 
        upi: {
          address: "",
        },
      },
  },
  orderSummary: {
    courseName: "Data Structure and Algorithm",
    trainer: "Mark",
    rating: "4.5",
    price: 360.00,
    convenienceFee: 42.22,
    counsellingPrice: 100.00,
  },
};
