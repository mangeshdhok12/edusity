export const dashboard = {
  video: [
    {
      id: 1,
      thumbnai: "/assets/studentdashboardAssets/Images.png",
      authorImage: "/assets/studentdashboardAssets/AvatarPhoto.png",
      title: "Lorem Ipsum is simply dummy text of the printing",
      author: "Lorem Ipsum",
      durations: "4 Minutes",
    },
    {
      id: 2,
      thumbnai: "/assets/studentdashboardAssets/Images.png",
      authorImage: "/assets/studentdashboardAssets/AvatarPhoto.png",
      title: "Lorem Ipsum is simply dummy text of the printing",
      author: "Lorem Ipsum",
      durations: "4 Minutes",
    },
    {
      id: 3,
      thumbnai: "/assets/studentdashboardAssets/Images.png",
      authorImage: "/assets/studentdashboardAssets/AvatarPhoto.png",
      title: "Lorem Ipsum is simply dummy text of the printing",
      author: "Lorem Ipsum",
      durations: "4 Minutes",
    },
    {
      id: 4,
      thumbnai: "/assets/studentdashboardAssets/Images.png",
      authorImage: "/assets/studentdashboardAssets/AvatarPhoto.png",
      title: "Lorem Ipsum is simply dummy text of the printing",
      author: "Lorem Ipsum",
      durations: "4 Minutes",
    },
    {
      id: 5,
      thumbnai: "/assets/studentdashboardAssets/Images.png",
      authorImage: "/assets/studentdashboardAssets/AvatarPhoto.png",
      title: "Lorem Ipsum is simply dummy text of the printing",
      author: "Lorem Ipsum",
      durations: "4 Minutes",
    },
  ],
  sampleResume: [
    {
      id: 1,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
    {
      id: 2,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
    {
      id: 3,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
    {
      id: 4,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
    {
      id: 5,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
    {
      id: 6,
      image: "/assets/studentdashboardAssets/Image 14.png",
    },
  ],
};
