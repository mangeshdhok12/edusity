// const withTM = require("next-transpile-modules")(["ky"]);
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
};

module.exports = {
  images: {
    domains: [
      "media.graphassets.com",
      "lh3.googleusercontent.com",
      "firebasestorage.googleapis.com",
      "localhost",
      "example.com",
    ],
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
};

nextConfig;
