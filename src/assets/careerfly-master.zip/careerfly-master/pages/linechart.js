import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

const linechart = () => {
  const data = [
    { name: "Page A", uv: 40, pv: 30, amt: 100 },
    { name: "Page B", uv: 30, pv: 70, amt: 200 },
    { name: "Page C", uv: 60, pv: 60, amt: 300 },
    { name: "Page D", uv: 80, pv: 38, amt: 400 },
    { name: "Page E", uv: 40, pv: 30, amt: 500 },
    { name: "Page F", uv: 30, pv: 70, amt: 600 },
    { name: "Page G", uv: 60, pv: 60, amt: 700 },
    { name: "Page H", uv: 80, pv: 38, amt: 800 },
  ];

  return (
    <LineChart
      width={500}
      height={300}
      data={data}
      margin={{
        top: 5,
        right: 8,
        left: 8,
        bottom: 5,
      }}
    >
      <CartesianGrid strokeDasharray="3 3" />
      <XAxis dataKey="name" />
      <YAxis />
      <Tooltip />
      <Legend />
      <Line
        type="monotone"
        dataKey="pv"
        stroke="#8884d8"
        activeDot={{ r: 8 }}
      />
      <Line type="monotone" dataKey="uv" stroke="#82ca9d" />
    </LineChart>
  );
};

export default linechart;
