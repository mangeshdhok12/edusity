import { GoogleSpreadsheet } from "google-spreadsheet";

const googleSheet = async () => {
  const doc = new GoogleSpreadsheet("0");

  await doc.useServiceAccountAuth({
    client_email: process.env.NEXT_PUBLIC_GOOGLE_SERVICE_ACCOUNT_EMAIL,
    private_key: process.env.NEXT_PUBLIC_GOOGLE_PRIVATE_KEY,
  });

  await doc.loadInfo(); // loads document properties and worksheets
  await doc.updateProperties({ title: "renamed doc" });

  const sheet = doc.sheetsByIndex[0]; // or use doc.sheetsById[id] or doc.sheetsByTitle[title]

  // adding / removing sheets
  await doc.addSheet({ title: "hot new sheet!" });
};

export default googleSheet;
