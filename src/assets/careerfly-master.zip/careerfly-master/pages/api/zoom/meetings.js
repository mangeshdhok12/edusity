export default async (req, res) => {
  const client_id = process.env.NEXT_PUBLIC_ZOOM_CLIENT_ID;
  const clientSecret = process.env.NEXT_PUBLIC_ZOOM_CLIENT_SECRET;
  const accountId = process.env.NEXT_PUBLIC_ZOOM_ACCOUNT_ID;

  const resData = await fetch(
    `https://zoom.us/oauth/token?grant_type=account_credentials&account_id=${accountId}`,

    {
      method: "POST",
      Host: "zoom.us",
      headers: {
        Authorization: `Basic ${Buffer.from(
          client_id + ":" + clientSecret
        ).toString("base64")}`,
      },
    }
  );
  const response = await resData.json();

  const token = response.access_token;

  const meetings = await fetch(
    `https://api.zoom.us/v2/users/me/meetings`,

    {
      method: "get",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );

  if (meetings) {
    const resMeetings = await meetings.json();
    res.send({ resData: resMeetings });
  } else {
    return res.end();
  }
};
