import { google } from "googleapis";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).send({ message: "only post request are allowed" });
  }
  const body = req.body;
  try {
    const auth = new google.auth.GoogleAuth({
      credentials: {
        client_email: process.env.G_CLIENT_EMAIL,
        private_key:
          "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjK3bWBBa/Ml+b\nSdVjKe3iQ2UM2xWCy2D7B45VOSfxDMZlpMWNm07A82tBznn9j9DpCDGA80wrK02g\nd88puteJiBcPnx2hMvtKaElL6gOsIy3wTV3+7ezMvsCEP8Pf9bkPMLGjptZ00NyY\nUTpPmMAl19cPES7P3W3Aq36DwHiIVhJrtgmqwYFLGr5nE9+/76/M68uJJAh77v6D\nhSn0b72W4tTH/r84ATkWhS4+DCU16EPhNQwb0uEn0ieMUIJhIQ5cAwE6g3tSnYfd\nRmoa2JnKdxRLc7J10htAyHVjU3HSqt+keAF2UNWslOz2hi2QOXbEaZpumJMtnodf\n73tY4ikRAgMBAAECggEAFyVUu6Ij2eZa4ovULbdma7i0rmCrifywmptlSNiNPmfa\nAtQfQ+maf8tn1RNlgZ7zewLzBsA8d0kyv0cPh3NeHL/Fya0ABnxVYiYt84tUDwiE\nfTh0U3PLqfWLGJd1ASF5qVp2cGj7teFk0WSAWYcpBpU6CASfd9QIvBJ3pVfZoTke\nbrfQ4p3TsXbw/tpbOpnRxQlkTFSKaPJXsTGGL5dxz21o/IFMtsSS8VuGuzgBgW3m\nHYhpCNnnotViwJ/4aMJyvsqp9olSNBUXDRVW4OS1IKnZ3ZxA5WSZagXvGTvlXhX2\nWwejwYxpLvdafOrvUie+16TKUQmP+urEK5KkwxTDMwKBgQDRRm02dH3y53rJrHuP\noH/dsirr/eE4Y8E9sv8FLP9413Cdfe4rFymuuu4vAXu8jDDoQJ04kZDFDDB68fvI\njjQh012AyOD0mzRVJGYfjFJo2uycQ4+xsROHnt29dXezvbGmJ6DKqLgq1ZHLr8RC\n6XbYB0y0lRDf/dL6xHh5hbNFlwKBgQDHmcmnu4ZIwNIoT9LJO5ehHqU+gAQ2zwho\nqrWbgLEYC23ai9RgTSQ2TV4hUikYwGxfbej6CzB1ciqu9P2/oMGtNIzc1u/C+Hku\nCTubFT9vAhoBhn1mKBlUu+qMxg2tsqECt18InjM9xKvhJgEKBxHmXbvmJMPh0lOw\n5FxwMCJrlwKBgEVgUYhB6hcCggQld/jPPlRiYjRFv8oP19n6Yux2VGLdGOo8+x2x\n2hGgyqEunrSMzRHRic1dBF8ugUvguJVt/v5Psaml7l1orlqjbG989zznhpTvGM3R\nZCYLlnreXEZr1l68uGM2t4cLsf+STz/XYZyQHu+mkyeOX8jeJQo0NpAVAoGBAIXz\n0X99vBrrPJ7NIzrlgVchx+fv5eQagRwtJH/dl/v4/5phqP+QBbNjrL5T8zynNpO8\noVPdWoIXQkn0JK8L5a6ly7sRjAqe0kRw8c2cLtwC3w0TAukiFA3npvsel2Nws9ms\n0lxoPx8+89K/vIbMQ9kEIuvK1KKikoPuXZL02sS1AoGAUcetKLhwevbKq0raWMZo\n0FRZ76zwXQwQs9PJFnccicuq1F41eKgw+Sv4b0Da//1w+K6Dy848Zw6z5+UVfaip\nVVdpyvfoyCTmNoniq90n3rS67sYrw62G5MBoo66hgpT4UcrnUEVxd6NMvVILw9NH\nLQEAy+nuvS2BCp3RGueFcDc=\n-----END PRIVATE KEY-----\n",
      },
      scopes: [
        "https://www.googleapis.com/auth/drive",
        "https://www.googleapis.com/auth/drive.file",
        "https://www.googleapis.com/auth/spreadsheets",
      ],
    });

    const sheets = google.sheets({
      auth,
      version: "v4",
    });

    const response = await sheets.spreadsheets.values.append({
      spreadsheetId: process.env.SPREADSHEET_ID,
      range: "Sheet1!A:H",
      valueInputOption: "USER_ENTERED",
      requestBody: {
        values: [
          [
            body.name,
            body.email,
            body.phone,
            body.status,
            body.qualification,
            body.state,
            body.city,
            body.date,
            body.source,
            body.course,
          ],
        ],
      },
    });




    return res.status(200).json({ data: response.data});
  } catch (e) {
    return res
      .status(500)
      .send({ message: e.message ?? "something went wrong" });
  }
}
