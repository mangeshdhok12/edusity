import React from "react";
import { Container } from "react-bootstrap";

const termscondition = () => {
  const termsData = {
    definatin: "Definitions",
    data: [
      {
        heading: "Interpretation",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              "Any reference in this Agreement to any provision of a statute shall be construed as a reference to that provision as amended, re-enacted or extended at the relevant time.",
          },
          {
            id: 2,
            point:
              "The headings in this Agreement are for convenience only and shall not affect its interpretation.",
          },
          {
            id: 3,
            point:
              "  Any reference to a clause or Schedule shall be construed as a reference to a clause of or schedule to this Agreement unless expressly stated to the contrary.",
          },
          {
            id: 4,
            point:
              " Any reference to a statute or statutory provision is to it as from time to time in force as amended or re-enacted.",
          },
          {
            id: 5,
            point:
              " Use of the word “including” is without prejudice to the generality.",
          },
        ],
      },
      {
        heading: " Provision of the Services",
        descriptioin:
          "The Company shall provide and perform the Services on the terms and conditions of this Agreement and will do so:",
        points: [
          {
            id: 1,
            point:
              " in compliance with all applicable laws, regulations, codes of practice and professional standards;",
          },
          {
            id: 2,
            point: " with reasonable skill and care;",
          },
          {
            id: 3,
            point:
              "  in accordance with the terms of this Agreement, including the timescales specified in Schedule 1 or any Statement of Works;",
          },
          {
            id: 4,
            point: " in accordance with good professional practice.",
          },
        ],
      },
      {
        heading: "Personnel",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              " The Company shall use its reasonable endeavours to ensure that the same personnel provide the Services in order to maintain consistency and build a relationship with the Client.",
          },
          {
            id: 2,
            point:
              " The Company shall use its reasonable endeavours to ensure that its personnel comply with the Client’s site regulations when the Company’s personnel are on the Client’s premises.",
          },
          {
            id: 3,
            point:
              " The Client shall not at any time during the term of this Agreement or for a period of 6 months following its expiry or termination employ or solicit for employment or engage on any basis any member of the Company’s personnel (whether employed or engaged on some other basis by the Company).",
          },
          {
            id: 5,
            point:
              "The Client acknowledges the cost to the Company of losing and replacing any such person and the Client agrees that if it breaches the provisions of clause 4.3, the Client shall pay to the Company by way of liquidated damages a sum equal to the greater of (i) £50,000; and (ii) an amount equal to the person’s aggregate annual gross remuneration package.",
          },
          {
            id: 6,
            point:
              "The Client acknowledges the cost to the Company of losing and replacing any such person and the Client agrees that if it breaches the provisions of clause 4.3, the Client shall pay to the Company by way of liquidated damages a sum equal to the greater of (i) £50,000; and (ii) an amount equal to the person’s aggregate annual gross remuneration package.",
          },
          {
            id: 7,
            point:
              "The Client acknowledges the cost to the Company of losing and replacing any such person and the Client agrees that if it breaches the provisions of clause 4.3, the Client shall pay to the Company by way of liquidated damages a sum equal to the greater of (i) £50,000; and (ii) an amount equal to the person’s aggregate annual gross remuneration package.",
          },
          {
            id: 8,
            point:
              "The Client acknowledges the cost to the Company of losing and replacing any such person and the Client agrees that if it breaches the provisions of clause 4.3, the Client shall pay to the Company by way of liquidated damages a sum equal to the greater of (i) £50,000; and (ii) an amount equal to the person’s aggregate annual gross remuneration package.",
          },
        ],
      },
      {
        heading: "Obligations of the Client",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              "The Client shall provide the Company with such information and access to such facilities and personnel as the Company shall reasonably require in order to provide the Services.",
          },
          {
            id: 2,
            point:
              " The Client shall make such decisions and provide such instructions as the Company shall require and at the time that the Company requires to enable the Company to provide the Services",
          },
          {
            id: 3,
            point:
              " The Client acknowledges that the Company’s ability to provide the Services and to meet any timeframe agreed for the provision of the Services is dependent on the Client providing that information and access and providing those decisions and instructions at the times required by the Company.",
          },
        ],
      },
      {
        heading: " Intellectual Property",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              "Any pre-existing Intellectual Property Rights of either party that are made available for use in connection with the provision of the Services shall remain vested in that party; the other party shall have a licence to use those rights so far as may be necessary to enable that party to provide or to enjoy the benefit of the Services.",
          },
          {
            id: 2,
            point:
              " All Intellectual Property Rights that are created in the course of the provision of the Services and in the Deliverables shall belong to the Company; the Client shall have a royalty free,perpetual licence to use those rights as envisaged by this Agreement to enable the Client to have the benefit of the Services and the Deliverables for use within the Client’s own business",
          },
          {
            id: 3,
            point:
              " The Company warrants to the Client that the Deliverables will not in any way infringe the Intellectual Property Rights of any other person and the Company will indemnify the Client and keep the Client fully indemnified in respect of any losses, liabilities, demands, actions and claims that the Client might incur or suffer as a result of any breach of this warranty. ",
          },
          {
            id: 4,
            point:
              "  If the indemnity in clause 6.3 is to be called upon the Client shall:",
          },
          {
            id: 5,
            point: "   promptly notify the Company in writing of the claim;",
          },
          {
            id: 6,
            point:
              "make no admission or settlement without the Company’s prior written consent;",
          },
          {
            id: 7,
            point:
              " allow the Company to have control over the conduct of the claim including any litigation; and",
          },
          {
            id: 8,
            point:
              " give the Company such assistance and information that the Company reasonably requires.",
          },
          {
            id: 9,
            point:
              " The Company shall have no liability under the indemnity in clause 6.3 where the alleged infringement arises from the Client using the Deliverables in any manner or for any purpose other than those for which they were provided.",
          },
        ],
      },
      {
        heading: " Confidentiality",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              "The Company and the Client may during the course of this Agreement and in connection with the Services obtain information relating to the other party which is not made available generally by that other party (“Confidential Information”).",
          },
          {
            id: 2,
            point: " The receiving party shall:",
          },
          {
            id: 3,
            point:
              "keep all Confidential Information confidential and not disclose it to any person (save as required by law); and",
          },
          {
            id: 4,
            point:
              "  use the Confidential Information only for the purpose for which it was provided and for no other purpose.",
          },
        ],
      },
      {
        heading: " Data Protection",
        descriptioin: "",
        points: [
          {
            id: 1,
            point:
              "Both parties will comply with all applicable requirements of the Data Protection Legislation. This is in addition to, and does not relieve, remove or replace, a party’s obligations under the Data Protection Legislation.",
          },
          {
            id: 2,
            point:
              " The parties acknowledge that for the purposes of the Data Protection Legislation, the Client is the data controller and the Company is the data processor (where “Data Controller” and “Data Processor” have the meanings as defined in the Data Protection Legislation).",
          },
          {
            id: 3,
            point:
              "The Client will ensure that it has all necessary appropriate consents and notices in place to enable lawful transfer of the personal data to the Company for the duration and purposes of this agreement.",
          },
          {
            id: 4,
            point:
              " The Company shall, in relation to any personal data processed in connection with the performance by the Company of its obligations under this agreement:",
          },
          {
            id: 5,
            point:
              " process that personal data only for the purposes of this agreement or on the Client’s written instructions;",
          },
          {
            id: 6,
            point:
              " process that personal data only for the purposes of this agreement or on the Client’s written instructions;",
          },
          {
            id: 7,
            point:
              " ensure that it has in place appropriate technical and organisational measures, to protect against unauthorised or unlawful processing of personal data and against accidental loss or destruction of, or damage to, personal data, appropriate to the harm that might result from the unauthorised or unlawful processing or accidental loss, destruction or damage and the nature of the data to be protected, having regard to the state of technological development and the cost of implementing any measures (those measures may include, where appropriate, pseudonymising and encrypting personal data, ensuring confidentiality, integrity and availability of its systems and services, and regularly assessing and evaluating the effectiveness of the technical and organisational measures adopted by it;",
          },
          {
            id: 8,
            point:
              "  ensure that all personnel who have access to and/or process personal data are obliged to keep the personal data confidential; and",
          },
          {
            id: 9,
            point:
              "  not transfer any personal data outside of the European Economic Area unless the following conditions are fulfilled:",
          },
          {
            id: 10,
            point:
              " the Company has provided appropriate safeguards in relation to the transfer;",
          },
          {
            id: 11,
            point:
              "  the data subject has enforceable rights and effective legal remedies;",
          },
          {
            id: 12,
            point:
              "  the Company complies with its obligations under the Data Protection Legislation by providing an adequate level of protection to any personal data that is transferred; and",
          },
          {
            id: 13,
            point:
              "  the Company complies with the Client’s reasonable instructions notified to it in advance with respect to the processing of the Personal Data;",
          },
          {
            id: 14,
            point:
              " assist the Client in responding to any request from a data subject and in ensuring compliance with its obligations under the Data Protection Legislation with respect to security, breach notifications, impact assessments and consultations with supervisory authorities or regulators;",
          },
          {
            id: 15,
            point:
              " notify the Client without undue delay on becoming aware of a personal data breach;",
          },
          {
            id: 16,
            point:
              " at the Client’s written direction, delete or return personal data and copies thereof to the Client on termination of this agreement unless required by applicable law to store the personal data;",
          },
          {
            id: 17,
            point:
              "  maintain records and information to demonstrate its compliance with these provisions.",
          },
        ],
      },
    ],
  };
  return (
    <div style={{ marginTop: "100px", marginBottom: "100px" }}>
      <Container className="py-5">
        <h5 className="fw-bold">Definitions</h5>
        <div>
          {termsData.data.map((item, i) => (
            <div key={i}>
              <h5 className="fw-bold">{item.heading}</h5>
              <p>{item.descriptioin}</p>
              {item.points.map((item, i) => (
                <div key={i}>
                  <p>
                    {i++}.)
                    {item.point}
                  </p>
                </div>
              ))}
            </div>
          ))}
        </div>
        <p>
          You consent to receive communications from us by way of e-mails, phone
          calls and SMS’s with respect to your transactions on our Website.
          Users will be required to register their valid phone numbers and
          e-mail addresses to facilitate such communication. We may also use
          your e-mail address to send You updates, newsletters, changes to
          features of the Service, and the like to provide You better Services.
        </p>
        <p>
          By submitting our webform, you agree to receive calls on the number
          shared, and such calls and SMS would be coming from a third-party
          platform.
        </p>
      </Container>
    </div>
  );
};

export default termscondition;
