import React from "react";
import { Container } from "react-bootstrap";

const refundpolicy = () => {
  const refundPolicyData = {
    heading:
      "Refund and Cancellation Policy Careerfly reserves the right to refuse/cancel any order. Careerfly at its sole discretion may cancel any order(s)",
    points: [
      {
        id: 1,
        point: "1.) If it suspects a fraudulent transaction or",
      },
      {
        id: 2,
        point:
          "2.) If it suspects a customer has undertaken a transaction which is not in accordance with the Terms of Use or",
      },
      {
        id: 3,
        point:
          "3.) For any reason outside the control of the Careerfly including causes for delivery related logistical difficulties.",
      },
    ],
    policyheading:
      "Refund/cancellation policies applicable in the following conditions:",
    policyPoints: [
      {
        id: 1,
        point:
          "a) However, the order once Completed cannot be cancelled in any case.",
      },
      {
        id: 2,
        point:
          " b) In case there is an option for online download of data than cancellation will not be possible",
      },
      {
        id: 3,
        point:
          "c) In case of failed transactions or double realization of account for the same order, the total deducted amount will be refunded.",
      },
      {
        id: 4,
        point:
          "d) In case of cancelled order/failed transactions, the bank/card transaction charges of the buyer, if any, is likely to be forfeited",
      },
      {
        id: 5,
        point:
          "e) In case of cancelled order/failed transactions, the bank/card transaction charges of the buyer, if any, is likely to be forfeited",
      },
      {
        id: 6,
        point:
          "f) In case of part cancellations, the amount refunded will be corresponding to the part cancellation",
      },
    ],
  };
  return (
    <div style={{marginTop:'100px',marginBottom:'100px'}}>
      <Container>
        <div className="py-5">
          <h4 className="fw-bolder fs-5">{refundPolicyData.heading}</h4>
          {refundPolicyData.points.map((item, i) => (
            <p key={i}>{item.point}</p>
          ))}
        </div>
        <div>
          <h4 className="fw-bolder fs-5">{refundPolicyData.policyheading}</h4>
          {refundPolicyData.policyPoints.map((item, i) => (
            <p key={i}>{item.point}</p>
          ))}
        </div>
      </Container>
    </div>
  );
};

export default refundpolicy;
