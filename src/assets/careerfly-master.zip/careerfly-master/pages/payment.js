import React from "react";
import PaymentGateway from "../src/screens/paymentGateway/PaymentGateway";

function paymentGateway() {
  return (
    <>
      <PaymentGateway />
    </>
  );
}

export default paymentGateway;
