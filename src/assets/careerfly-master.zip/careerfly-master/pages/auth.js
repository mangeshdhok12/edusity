import React from "react";
import Auth from "../src/screens/auth/Auth";

const auth = () => {
  return <Auth />;
};

export default auth;
