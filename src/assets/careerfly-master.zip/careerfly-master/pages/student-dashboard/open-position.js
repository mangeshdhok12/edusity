import React from "react";
import OpenPosition from "../../src/screens/studentDashboard/apply_jobs/OpenPosition";
import { gql } from "@apollo/client";
import apolloClient from "../../src/lib/appoloClient";

const Openposition = ({data}) => {
  return (
    <div>
      <OpenPosition data={data} />
    </div>
  );
};

export default Openposition;

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
    query MyQuery {
      globalModels {
        openPositions {
          image2 {
            url
          }
          link
          text1
          text2
          text3
        }
      }
    }`,
  });

  return { props: { data }, revalidate: 10 };
};
