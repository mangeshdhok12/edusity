import React from "react";
import Trainer from "../../src/screens/studentDashboard/Trainers/Trainer";

const ourtrainers = () => {
  return (
    <div>
      <Trainer />
    </div>
  );
};

export default ourtrainers;
