import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../../src/lib/appoloClient";
import Placement from "../../src/screens/studentDashboard/Placement/Placement";

const placement = ({ data }) => {
  return (
    <div>
      <Placement data={data} />
    </div>
  );
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        placements {
          alumni {
            ... on Type3 {
              id
              link
              text3
              text2
              text1
              image1 {
                url
              }
              image2 {
                url
              }
            }
          }
          banners {
            url
          }
          partners(first: 100) {
            url
          }
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};

export default placement;
