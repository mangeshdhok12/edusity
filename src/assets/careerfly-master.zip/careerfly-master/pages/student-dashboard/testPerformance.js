import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../../src/lib/appoloClient";
import Test from "../../src/screens/studentDashboard/TestsPage/Test";

const testPerformance = ({ data }) => {
  console.log(data);

  return (
    <div>
      <Test data={data} />
    </div>
  );
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses(first: 100) {
          slug
          moduleTest {
            name
            mcQs {
              options
              question
              correctAnswer
            }
            slug
           
          }
          computerTest {
            slug
            name
            mcQs {
              options
              question
              correctAnswer
            }
          }
          aptitudeTest {
            slug
            name
            mcQs {
              question
              options
              correctAnswer
            }
          }
          communicationTest {
            slug
            name
            mcQs {
              correctAnswer
              options
              question
            }
          }
          title
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};

export default testPerformance;
