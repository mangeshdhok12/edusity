import React from "react";
import Global from "../../src/screens/studentDashboard/Global_Updates/Global";
import { gql } from "@apollo/client";
import apolloClient from "../../src/lib/appoloClient";

const globalupdates = ({data}) => {
return (
    <div>
      <Global data={data}/>
    </div>
  );
};

export default globalupdates;

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
    query MyQuery {
      globalModels {
        globalUpdates {
          image2 {
            url
          }
          text1
          text2
          text3
          link
        }
      }
    }`,
  });

  return { props: { data }, revalidate: 10 };
};

