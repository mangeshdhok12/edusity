import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../../src/lib/appoloClient";
import Videos from "../../src/screens/studentDashboard/Videos";

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses {
          categories {
            categoryName
            subCategories {
              id
              subcategoryName
            }
          }

          slug
          playlist
          title
          subCategories {
            subcategoryName
          }
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};
const recorderVideos = ({ data }) => {
  return (
    <div>
      <Videos data={data?.courses} />
    </div>
  );
};

export default recorderVideos;
