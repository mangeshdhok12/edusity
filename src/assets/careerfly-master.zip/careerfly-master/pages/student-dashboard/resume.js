import React from "react";
import Resume from "../../src/screens/studentDashboard/resume/Resume";
import { gql } from "@apollo/client";
import apolloClient from "../../src/lib/appoloClient";
const resume = ({data}) => {
  return (
    <div>
      <Resume data={data}/>
    </div>
  );
};

export default resume;

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
    query MyQuery {
      globalModels {
        sampleResume {
          doc {
            url
          }
          image {
            url
          }
          link
        }
      }
    }
    `,
  });

  return { props: { data }, revalidate: 10 };
};

