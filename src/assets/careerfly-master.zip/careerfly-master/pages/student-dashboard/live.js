import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../../src/lib/appoloClient";
import Live from "../../src/screens/studentDashboard/Live/Live";

const live = ({ data }) => {
  console.log(data);
  return (
    <div>
      <Live data={data} />
    </div>
  );
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        panels {
          trainer {
            createAClass {
              text1
              text3
              link
              dateAndTime
            }
          }
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};

export default live;
