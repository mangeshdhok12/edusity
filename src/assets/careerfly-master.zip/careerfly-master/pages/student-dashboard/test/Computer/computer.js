import React from "react";
import { gql } from "@apollo/client";
import Quiz from "../../../../src/screens/studentDashboard/TestQuiz/Quiz";
import apolloClient from "../../../../src/lib/appoloClient";

const test = ({ data }) => {
  console.log(data);
  return (
    <div>
      <Quiz data={data} />
    </div>
  );
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses(first: 100) {
          computerTest {
            name
            mcQs {
              question
              options
              correctAnswer
            }
            slug
          }
          slug
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};

export default test;
