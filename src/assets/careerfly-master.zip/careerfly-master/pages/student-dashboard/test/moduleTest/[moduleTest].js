import React from "react";
import { gql } from "@apollo/client";
import Quiz from "../../../../src/screens/studentDashboard/TestQuiz/Quiz";
import apolloClient from "../../../../src/lib/appoloClient";

const test = ({ data }) => {
  console.log(data);
  return (
    <div>
      <Quiz data={data} />
    </div>
  );
};

export const getStaticPaths = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses(first: 100) {
          moduleTest {
            slug
          }
        }
      }
    `,
  });

  const paths = data.courses[0]?.moduleTest?.map((item) => ({
    params: {
      moduleTest: item?.slug,
    },
  }));

  return { paths, fallback: "blocking" };
};

export const getStaticProps = async ({ params: { moduleTest } }) => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses (first: 100) {
          moduleTest(where: { slug: "${moduleTest}" }) {
            name
            mcQs {
              options
              question
              correctAnswer
            }
            slug
          }
          slug
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};

export default test;
