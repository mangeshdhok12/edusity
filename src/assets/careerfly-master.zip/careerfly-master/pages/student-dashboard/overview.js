import React from "react";
import OverView from "../../src/screens/studentDashboard/Overview/OverView";
import { gql } from "@apollo/client";
import apolloClient from "../../src/lib/appoloClient";

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses {
          computerTest {
            slug
            name
            mcQs {
              options
              question
              correctAnswer
            }
          }
          aptitudeTest {
            slug
            name
            mcQs {
              question
              options
              correctAnswer
            }
          }
          communicationTest {
            slug
            name
            mcQs {
              correctAnswer
              options
              question
            }
          }
          slug
          title
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};

const overview = ({ data }) => {
  return (
    <div>
      <OverView data={data} />
    </div>
  );
};

export default overview;
