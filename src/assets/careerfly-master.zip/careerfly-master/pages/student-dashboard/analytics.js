import React from "react";
import Analytics from "../../src/screens/studentDashboard/Analytics/Analytics";

const analytics = () => {
  return (
    <div>
      <Analytics />
    </div>
  );
};

export default analytics;
