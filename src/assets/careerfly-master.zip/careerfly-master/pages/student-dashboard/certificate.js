import React from "react";
import Certificate from "../../src/screens/studentDashboard/Certificate/Certificate";

const certificate = () => {
  return (
    <div>
      <Certificate />
    </div>
  );
};

export default certificate;
