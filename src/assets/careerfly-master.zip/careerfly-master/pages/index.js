import React from "react";
import { gql } from "@apollo/client";
import apolloClient from "../src/lib/appoloClient";
import HomeScreen from "../src/screens/home/HomeScreen";

export default function Home({ data }) {
  return (
    <div>
      <HomeScreen data={data} />
    </div>
  );
}

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        homepages {
          alumni {
            url
          }
          brandImage {
            url
          }
          heroBanner {
            desc {
              raw
            }
            heading
            image {
              url
            }
          }
          eligibility {
            heading
            content
            image {
              url
            }
          }
          introSlider {
            content
            heading
            image {
              url
            }
          }
          analytics {
            image {
              url
            }
            heading
            content
          }
          placementProgram {
            heading
            content
            image {
              url
            }
          }
          successStepVideo {
            url
          }
        }
        trendingCourseCategories {
          category
        }
        courses(first: 100) {
          curriculumDoc {
            url
          }
          certificationLabel
          slug
          title
          trending
          desc
          insights
          chooseCourseType
          courseCardIcon {
            url
          }
          image {
            url
          }
          duration
          subCategories(first: 100) {
            categories {
              categoryName
            }
            subcategoryName
          }
        }
        globalModels {
          coursesBanner {
            url
          }
        }
        categories(first: 100) {
          categoryName
          trending
          subCategories(first: 100) {
            subcategoryName
          }
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};
