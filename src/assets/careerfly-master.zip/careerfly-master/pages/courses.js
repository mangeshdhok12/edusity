import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../src/lib/appoloClient";
import Courses from "../src/screens/courses/Courses";

const courses = ({ data }) => {
  return <Courses data={data} />;
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses(first: 100) {
          curriculumDoc{
            url
          }
          certificationLabel
          slug
          title
          chooseCourseType
          trending
          desc
          insights
          chooseCourseType
          courseCardIcon {
            url
          }
          image {
            url
          }
          duration
          subCategories(first: 100) {
            subcategoryName
          }
          feeStructure {
            text1
          }
        }
        globalModels {
          coursesBanner {
            url
          }
        }
        categories(first: 100) {
          categoryName
          trending
          subCategories(first: 100) {
            subcategoryName
          }
        }
        subCategories(first: 100) {
          subcategoryName
          trending
          categories(first: 100) {
            categoryName
          }
        }
      }
    `,
  });

  return {
    props: {
      data,
    },
    revalidate: 10,
  };
};

export default courses;
