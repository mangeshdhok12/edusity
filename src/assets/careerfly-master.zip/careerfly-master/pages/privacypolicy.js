import React from "react";
import { Container } from "react-bootstrap";
import { themeColors } from "../src/themes/colors";

const privacypolicy = () => {
  const privacyPolicyData = {
    heading: "This Privacy Policy applies to the Careerfly.in",
    descreption:
      "Careerfly.in recognises the importance of maintaining your privacy. We value your privacy and appreciate your trust in us. This Policy describes how we treat user information we collect on http://www.Careerfly.inand other offline sources. This Privacy Policy applies to current and former visitors to our website and to our online customers. By visiting and/or using our website, you agree to this Privacy Policy. ",
    descreption2:
      "Careerfly.in is a property of Careerfly Online Pvt Ltd  an Indian Company registered under the Companies Act, 2013 having its registered office at C04 Noida sector 63 UP India",
    points: [
      {
        heading: "Information we collect",
        descreption: "",
      },
      {
        heading: "Contact information",
        descreption:
          "We might collect your name, email, mobile number, phone number, street, city, state, pincode,  country and ip address.",
      },
      {
        heading: "Payment and billing information",
        descreption:
          "We might collect your billing name, billing address and payment method when you buy a ticket. We NEVER collect your credit card number or credit card expiry date or other details pertaining to your credit card on our website. Credit card information will be obtained and processed by our online payment partner CC Avenue.",
      },
      {
        heading: "Other information",
        descreption:
          " If you use our website, we may collect information about your IP address and the browser you’re using. We might look at what site you came from, duration of time spent on our website, pages accessed or what site you visit when you leave us. We might also collect the type of mobile device you are using, or the version of the operating system your computer or device is running.",
      },
      {
        heading: "We collect information in different ways",
        descreption: "",
      },
      {
        heading: "We collect information directly from you",
        descreption:
          "We collect information directly from you when you register for an event or buy tickets. We also collect information if you post a comment on our websites or ask us a question through phone or email.",
      },
      {
        heading: "Use of your personal information",
        descreption: "",
      },
      {
        heading: "We use information to contact you",
        descreption:
          "We might use the information you provide to contact you for confirmation of a purchase on our website or for other promotional purposes.",
      },
      {
        heading: "We use information to respond to your requests or questions",
        descreption:
          "We might use your information to confirm your registration for an event or contest.",
      },
      {
        heading: "We use information to improve our products and services",
        descreption:
          "We might use your information to customize your experience with us. This could include displaying content based upon your preferences.",
      },
      {
        heading:
          "We use information to look at site trends and customer interests",
        descreption:
          "We may use your information to make our website and products better. We may combine information we get from you with information about you we get from third parties.",
      },
      {
        heading: "We use information for security purposes",
        descreption:
          "We may use information to protect our company, our customers, or our websites.",
      },
      {
        heading: "We use information for marketing purposes",
        descreption:
          "We might send you information about special promotions or offers. We might also tell you about new features or products. These might be our own offers or products, or third-party offers or products we think you might find interesting. Or, for example, if you buy tickets from us we’ll enroll you in our newsletter.",
      },
      {
        heading: "We use information to send you transactional communications",
        descreption:
          "We might send you emails or SMS about your account or a ticket purchase.We use information as otherwise permitted by law.",
      },
      {
        heading: "Sharing of information with third-parties",
        descreption: "",
      },
      {
        heading:
          "We will share information with third parties who perform services on our behalf",
        descreption:
          "We share information with vendors who help us manage our online registration process or payment processors or transactional message processors. Some vendors may be located outside of India.",
      },
      {
        heading: "We will share information with the event organizers",
        descreption:
          "We share your information with event organizers and other parties responsible for fulfilling the purchase obligation. The event organizers and other parties may use the information we give them as described in their privacy policies.",
      },
      {
        heading: "We will share information with our business partners",
        descreption:
          " This includes a third party who provide or sponsor an event, or who operates a venue where we hold events. Our partners use the information we give them as described in their privacy policies.",
      },
      {
        heading:
          "We may share information if we think we have to in order to comply with the law or to protect ourselves",
        descreption:
          " We will share information to respond to a court order or subpoena. We may also share it if a government agency or investigatory body requests. Or, we might also share information when we are investigating potential fraud.",
      },
      {
        heading:
          "We may share information with any successor to all or part of our business",
        descreption:
          "  For example, if part of our business is sold we may give our customer list as part of that transaction.",
      },
      {
        heading:
          "We may share your information for reasons not described in this policy",
        descreption: "  We will tell you before we do this.",
      },
    ],
  };
  return (
    <div style={{marginTop:'50px',marginBottom:'100px'}}>
      <Container className="py-5">
        <h1 className="fw-bolder text-center">{privacyPolicyData.heading}</h1>
        <div
          style={{
            color: themeColors.textSecondary,
          }}
        >
          <p className="fs-6">{privacyPolicyData.descreption}</p>
          <p className="fs-6">{privacyPolicyData.descreption2}</p>
        </div>
        <div>
          {privacyPolicyData.points.map((item, i) => (
            <div key={i} className="d-inline">
              <h5 className="fw-bold fs-6">{item.heading} :-</h5>
              <p>{item.descreption}</p>
            </div>
          ))}
        </div>
      </Container>
    </div>
  );
};

export default privacypolicy;
