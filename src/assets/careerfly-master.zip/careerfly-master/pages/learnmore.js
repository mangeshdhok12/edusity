import React from "react";
import { gql } from "@apollo/client";
import apolloClient from "../src/lib/appoloClient";
import LearnMore from "../src/screens/learnMore/LearnMore";

const learnmore = ({ data }) => {
  return (
    <div>
      <LearnMore data={data} />
    </div>
  );
};

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        knowMores {
          description {
            heading
            content
          }
          video {
            url
          }
          knowMoreData {
            ... on BannerSlider {
              heading
              content
              image {
                url
              }
            }
          }
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};

export default learnmore;
