import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../../src/lib/appoloClient";
import Course from "../../src/screens/course/Course";

const course = ({ data }) => {
  return (
    <div>
      <Course data={data} />
    </div>
  );
};

export async function getStaticPaths() {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        courses {
          slug
        }
      }
    `,
  });

  const paths = data.courses?.map((item, i) => ({
    params: {
      course: item.slug,
    },
  }));

  return {
    paths,
    fallback: "blocking",
  };
}

export async function getStaticProps({ params: { course } }) {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        course(where: { slug: "${course}" }) {
          heroBanner {
            ... on Type1 {
              heading
              desc
              image {
                url
              }
            }
            ... on Type2 {
              id
              text1
              text4
            }
          }
          ourTrainers {
            ... on Type1 {
              heading
              desc
            }
            ... on Type2 {
              id
              image {
                url
              }
              text1
              text2
              text3
              text4
              text3
            }
          }
          programOverview {
            ... on HeadingAndContent {
              heading
              content
            }
            ... on Type4 {
              heading
              description {
                raw
              }
              youTubeLink
            }
          }
          curriculum {
            ... on Type2 {
              id
              text1
              text3
            }
          }
          careerInsightBanner {
            url
          }
          certification {
            image {
              url
            }
            text1
            text3
            text4
          }
          certificationLabel
          desc
          enrollmentProcess {
            heading
            desc
          }
          feeStructure {
            text1
            text2
            text3
          }
          latestTrend {
            heading
            desc
          }
          ourKnowledgePartners {
            text1
            text2
            image {
              url
            }
          }
          placementPartners {
            text1
            image {
              url
            }
          }
          slug
          syllabus {
            url
          }
          image {
            url
          }
          title
          duration
          coupon {
            ... on Type2 {
              text1
              text2
            }
          }
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
}

export default course;
