import React from 'react'
import Overview from '../../src/screens/trainerDashboard/Overview/Overview'

const overview = () => {
  return (
    <div><Overview/></div>
  )
}

export default overview