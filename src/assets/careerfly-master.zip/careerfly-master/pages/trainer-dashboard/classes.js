import React from "react";
import Classes from "../../src/screens/trainerDashboard/Classes/Classes";

const classes = () => {
  return (
    <div>
      <Classes />
    </div>
  );
};

export default classes;
