import React from 'react'
import Social from '../../src/screens/trainerDashboard/Social/Social'

const social = () => {
  return (
    <div><Social/></div>
  )
}

export default social