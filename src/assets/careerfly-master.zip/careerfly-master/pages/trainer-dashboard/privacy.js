import React from 'react'
import Privacy from '../../src/screens/trainerDashboard/Privacy/Privacy'

const privacy = () => {
  return (
    <div><Privacy/></div>
  )
}

export default privacy