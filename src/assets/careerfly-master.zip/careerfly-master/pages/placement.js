import { gql } from "@apollo/client";
import apolloClient from "../src/lib/appoloClient";
import React from "react";
import Placement from "../src/screens/placement/Placements";

function placement({ data }) {
  return (
    <>
      <Placement data={data} />
    </>
  );
}

export default placement;

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        placements {
          alumni {
            ... on Type3 {
              id
              link
              text3
              text2
              text1
              image1 {
                url
              }
              image2 {
                url
              }
            }
          }
          banners {
            url
          }
          partners(first: 100) {
            url
          }
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};
