import dynamic from "next/dynamic";
import "../src/style/global.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "swiper/css";
// import "react-multi-carousel/lib/styles.css";
import "react-toastify/dist/ReactToastify.css";
import "swiper/css/navigation";
import "swiper/css/autoplay";
import "swiper/css/pagination";
import { StateContext } from "../src/context/StateContext.jsx";
import { SSRProvider } from "react-bootstrap";
import { Suspense } from "react";
import Script from "next/script";

function MyApp({ Component, pageProps }) {
  const DynamicLayout = dynamic(() => import("../src/components/Layout"));

  return (
    <>
      <Script
        async
        src="https://www.googletagmanager.com/gtag/js?id=G-ZYPZ8STCSP"
      />

      <Script>
        {`window.dataLayer = window.dataLayer || [];
          function gtag(){
            dataLayer.push(arguments);
          }
          gtag('js', new Date());
          gtag('config', 'G-ZYPZ8STCSP');`}
      </Script>
      <Script
        src="https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver"
        strategy="beforeInteractive"
      />
      <Suspense fallback={`Loading...`}>
        <SSRProvider>
          <StateContext>
            <DynamicLayout>
              <Component {...pageProps} />
            </DynamicLayout>
          </StateContext>
        </SSRProvider>
      </Suspense>
    </>
  );
}

export default MyApp;
