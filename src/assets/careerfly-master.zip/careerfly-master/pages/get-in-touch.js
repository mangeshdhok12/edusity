import React from 'react'
import GetinTouch from '../src/GetInTouch/GetinTouch'

const GetInTouch = () => {
  return (
    <GetinTouch/>
  )
}

export default GetInTouch