import React from "react";
import Dashboard from "../src/screens/dashboard/Dashboard";

const dashboard = () => {
  return <Dashboard />;
};

export default dashboard;
