import { useRouter } from "next/router";
import React from "react";
import { useStateContext } from "../src/context/StateContext";
import ProfileScreen from "../src/screens/profile/ProfileScreen";

function Profile() {
  const { userToken } = useStateContext();
  const router = useRouter();

  return (
    <div>
      {userToken !== "" ? (
        <ProfileScreen />
      ) : (
        <div>
          {() => {
            router.push("/");
          }}
        </div>
      )}
    </div>
  );
}

export default Profile;
