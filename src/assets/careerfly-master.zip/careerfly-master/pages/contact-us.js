import { gql } from "@apollo/client";
import React from "react";
import apolloClient from "../src/lib/appoloClient";
import ContactUsScreen from "../src/screens/ContactUs/ContactUsScreen";

export default function ContactUs({ data }) {
  return <ContactUsScreen data={data} />;
}

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        contactuses {
          content
          contactDetailCard {
            ... on Type2 {
              id
              text1
              image {
                url
              }
              text2
            }
          }
        }
      }
    `,
  });
  return { props: { data }, revalidate: 10 };
};
