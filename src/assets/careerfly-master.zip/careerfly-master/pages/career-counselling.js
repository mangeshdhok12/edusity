import React from "react";
import apolloClient from "../src/lib/appoloClient";
import { gql } from "@apollo/client";
import CareerCounsellingScreen from "../src/screens/careerCounceling/CareerCounsellingScreen";

export default function CareerCounselling({ data }) {
  return (
    <div>
      <CareerCounsellingScreen data={data} />
    </div>
  );
}

export const getStaticProps = async () => {
  const { data } = await apolloClient.query({
    query: gql`
      query MyQuery {
        carrerCouncelings {
          careerCouncelingAdvice {
            advice
            adviceGiverImage {
              url
            }
          }
          careerCounceling {
            ... on HeadingAndContent {
              heading
              content
            }
            ... on Type4 {
              heading
              description {
                raw
              }
            }
          }
          heroBanner {
            url
          }
          youTubeLink
          careerCouncelingPlan {
            caardTheme
            planTitle
            planPrice
            planFeatures
          }
        }
      }
    `,
  });

  return { props: { data }, revalidate: 10 };
};
