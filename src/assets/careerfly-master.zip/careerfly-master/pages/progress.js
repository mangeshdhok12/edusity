import React from "react";
import ProgressBar from "react-bootstrap/ProgressBar";
export function Progress({ percentage }) {
  return <ProgressBar now={percentage} />;
}

const progress = () => {
  let percentage1 = 64;
  let percentage2 = 70;
  let percentage3 = 80;
  let percentage4 = 88;
  return (
    <div style={{ width: "40%", padding: "15px" }}>
      <h3>Targets</h3>
      <hr />
      <div>
        <span>
          <b>13 May</b>
        </span>
        <span style={{ marginLeft: "70%" }}>{percentage1}%</span>
        <Progress percentage={percentage1} />
      </div>
      <div style={{ marginTop: "20px" }}>
        <span>
          <b>23 June</b>
        </span>
        <span style={{ marginLeft: "70%" }}>{percentage2}%</span>
        <Progress percentage={percentage2} />
      </div>
      <div style={{ marginTop: "20px" }}>
        <span>
          <b>18 July</b>
        </span>
        <span style={{ marginLeft: "73%" }}>{percentage3}%</span>
        <Progress percentage={percentage3} />
      </div>
      <div style={{ marginTop: "20px" }}>
        <span>
          <b>10 August</b>
        </span>
        <span style={{ marginLeft: "68%" }}>{percentage4}%</span>
        <Progress percentage={percentage4} />
      </div>
    </div>
  );
};

export default progress;
