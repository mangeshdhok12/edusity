import Image from "next/image";
import { BsChatDots, BsBell } from "react-icons/bs";
import { themeColors } from "../src/themes/colors";
import LocalPoliceIcon from "@mui/icons-material/LocalPolice";
import CheckIcon from "@mui/icons-material/Check";
import StarIcon from "@mui/icons-material/Star";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay, Navigation, Pagination } from "swiper";
import ProgressBar from "react-bootstrap/ProgressBar";
export function Progress({ percentage }) {
  return <ProgressBar now={percentage} />;
}

const partnerdashboard = () => {
  let percentage1 = 64;
  const data = [
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
    {
      topic: "Topic name",
      points: "35 XP",
    },
  ];

  return (
    <div>
      <div className="d-flex justify-content-between align-items-center mx-3">
        <div className="">
          <p
            style={{
              fontSize: "18px",
              fontweight: "bold",
            }}
          >
            Hii
          </p>
          <p>Good Morning</p>
        </div>
        <div className="d-flex gap-4">
          <div
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              border: "1px solid #efeeee",
              borderRadius: "10px",
            }}
          >
            <BsChatDots size={21} />
          </div>
          <div
            style={{
              width: "48px",
              height: "48px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              border: "1px solid #efeeee",
              borderRadius: "10px",
            }}
          >
            <BsBell size={21} />
          </div>
          <div
            style={{
              width: "10px",
              height: "10px",
              backgroundColor: "red",
              borderRadius: "50%",
              position: "absolute",
              right: 5,
            }}
          ></div>
        </div>
      </div>

      <div className="d-flex mt-5">
        <div style={{ marginLeft: "35px" }}>
          <Image
            alt="placeholder"
            src="/assets/studentdashboardAssets/Placeholder_Rad.png"
            width={100}
            height={100}
            placeholder="blur"
            blurDataURL="/assets/studentdashboardAssets/Placeholder_Rad.png"
          />
          <br />
          <button
            style={{
              backgroundColor: `${themeColors.primary}`,
              color: "white",
              fontWeight: "bold",
              padding: "5px 15px",
              margin: "15px",
              borderRadius: "5px",
              border: "none",
            }}
          >
            View Profile
          </button>
          <button
            style={{
              color: "gray",
              fontWeight: "bold",
              padding: "5px 15px",
              margin: "15px",
              borderRadius: "5px",
              border: "1px solid gray",
            }}
          >
            Edit Profile
          </button>
        </div>

        <div>
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            Nishant
          </p>
          <small>Area-Vikash Nagar, Lucknow</small>
        </div>
        <div style={{ marginLeft: "50px" }}>
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            Franchise Owner
          </p>
          <p style={{ color: "gray" }}>Status</p>
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            20
          </p>
          <p style={{ color: "gray" }}>Days/Weeks</p>
          <p
            style={{
              fontSize: "18px",
              fontWeight: "bold",
              margin: 0,
            }}
          >
            5
          </p>
          <p style={{ color: "gray" }}>Program</p>
        </div>
      </div>
      <div>
        <div className="d-flex flex-wrap ">
          {data?.map((item, i) => {
            return (
              <div key={i}>
                <div
                  style={{
                    backgroundColor: "lightgray",
                    padding: "10px",
                    margin: "20px",
                    width: "350px",
                    borderRadius: "15px",
                  }}
                >
                  <h4>{item.topic}</h4>
                  <Progress percentage={percentage1} />
                  <span>64%</span>
                  <p>{item.points}</p>
                  <button
                    style={{
                      padding: "5px 28px",
                      backgroundColor: "white",
                      border: "0",
                      borderRadius: "10px",
                      color: "blue",
                    }}
                  >
                    View
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      <div>
        <div
          style={{
            marginLeft: "25px",
            width: "300px",
            padding: "15px",
            boxShadow:
              "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
          }}
        >
          <h3>To do list</h3>
          <hr />
          {data?.map((v, i) => {
            return (
              <div className="mt-2" key={i}>
                <input type="checkbox" />
                <span className="mx-2">{v.topic}</span>
              </div>
            );
          })}
        </div>
        <div
          style={{
            marginLeft: "25px",
            marginTop: "20px",
            width: "300px",
            padding: "15px",
            boxShadow:
              "rgba(0, 0, 0, 0.07) 0px 1px 2px, rgba(0, 0, 0, 0.07) 0px 2px 4px, rgba(0, 0, 0, 0.07) 0px 4px 8px, rgba(0, 0, 0, 0.07) 0px 8px 16px, rgba(0, 0, 0, 0.07) 0px 16px 32px, rgba(0, 0, 0, 0.07) 0px 32px 64px",
          }}
        >
          <h3>Nearest Awards</h3>
          <hr />
          <p>
            <LocalPoliceIcon style={{ marginRight: "10px" }} />
            Top Performer 1{" "}
            <CheckIcon
              style={{
                borderRadius: "50%",
                backgroundColor: "green",
                color: "white",
                marginLeft: "45px",
              }}
            />
          </p>
          <p>
            <LocalPoliceIcon style={{ marginRight: "10px" }} />
            Top Performer 2
          </p>
          <p>
            <LocalPoliceIcon style={{ marginRight: "10px" }} />
            Top Performer 3
          </p>
          <p>
            <LocalPoliceIcon style={{ marginRight: "10px" }} />
            Top Performer 4
          </p>
          <p>
            <LocalPoliceIcon style={{ marginRight: "10px" }} />
            Top Performer 5
          </p>
        </div>
      </div>
      <div>
        <h2>Reviews</h2>
        <Swiper
           className="pb-5 d-flex flex-wrap w-100 m-0 px-0"
              style={{}}
              spaceBetween={40}
              slidesPerView={3}
              pagination={true}
              modules={[Autoplay, Pagination]}
              autoplay={{ delay: 3000 }}
        >
          <SwiperSlide
            style={{
              border: "1px solid brown",
              marginLeft: "35px",
              padding: "15px",
            }}
          >
            <h4>Manoj Kumar</h4>
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <p style={{ marginTop: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim
            </p>
          </SwiperSlide>
          <SwiperSlide style={{ border: "1px solid brown", padding: "15px" }}>
            <h4>Harshit Negi</h4>
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <p style={{ marginTop: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim
            </p>
          </SwiperSlide>
          <SwiperSlide style={{ border: "1px solid brown", padding: "15px" }}>
            <h4>Shivam Sharma</h4>
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <p style={{ marginTop: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim
            </p>
          </SwiperSlide>
          <SwiperSlide style={{ border: "1px solid brown", padding: "15px" }}>
            <h4>Raman Sharma</h4>
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <p style={{ marginTop: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim
            </p>
          </SwiperSlide>
          <SwiperSlide style={{ border: "1px solid brown", padding: "15px" }}>
            <h4>Hardik Sharma</h4>
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <StarIcon style={{ color: "yellow" }} />
            <p style={{ marginTop: "20px" }}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim
            </p>
          </SwiperSlide>
        </Swiper>
      </div>
    </div>
  );
};

export default partnerdashboard;
